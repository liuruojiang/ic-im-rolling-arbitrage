# poe: name=IC-IM-Momentum-Sleeves-V1-2
# poe: privacy_shield=half
# /// script
# requires-python = ">=3.11"
# dependencies = [
#   "matplotlib>=3.8",
#   "numpy>=1.26",
#   "pandas>=2.1",
#   "requests>=2.31",
# ]
# ///
"""Poe-native research query bot for the IC/IM v1.4 research signal.

This is a read-only research surface.  It explains the rolling core, momentum,
independent grid, Put and Call legs separately, then reconciles current and next-
session aggregate positions.  It never creates orders or claims live authority.
"""

import base64
import calendar as month_calendar
import contextvars
import hashlib
import io
import json
import math
import re
import sys
import threading
import time as time_module
import types
import unicodedata
import zipfile
import zlib
from collections.abc import Iterable
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from email.utils import parsedate_to_datetime
from typing import Any, ClassVar
from zoneinfo import ZoneInfo

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests
import ic_im_daily_valuation as daily_valuation
import ic_im_chinabond as chinabond
import ic_im_fear_grid_v1 as fear_grid
import ic_im_quote_snapshot_guard as quote_snapshot_guard
import ic_im_option_maintenance_notice as option_maintenance_notice
import ic_im_signal_evidence_v1 as signal_evidence
import ic_im_evidence_adapter_v1 as evidence_adapter


def _evidence_http_get(*args, **kwargs):
    url = str(args[0] if args else kwargs.get("url", ""))
    reader = signal_evidence.current_reader.get()
    if reader is not None:
        archived = reader.http_response(url, kwargs.get("params"))
        replay = requests.Response()
        replay.status_code = archived["status_code"]
        replay.url = url
        replay.headers.update(archived.get("headers", {}))
        replay.encoding = archived.get("encoding")
        replay._content = archived["body"]
        replay._content_consumed = True
        return replay
    wire_kwargs = kwargs
    params = kwargs.get("params")
    if (url in {"https://hq.sinajs.cn/", "https://hq.sinajs.cn/etag.php"}
            and isinstance(params, dict) and set(params) == {"list"}
            and isinstance(params["list"], str)
            and re.fullmatch(r"[A-Za-z0-9_]+(?:,[A-Za-z0-9_]+)+", params["list"])):
        # Sina treats percent-encoded commas as part of a symbol. Keep the
        # exact logical parameters in evidence, but serialize safe symbols
        # literally on the wire. No provider response is reconstructed.
        wire_kwargs = {**kwargs, "params": "list=" + params["list"]}
    response = requests.get(*args, **wire_kwargs)
    session = signal_evidence.current_session.get()
    if session is not None:
        try:
            body = None
            if kwargs.get("stream"):
                maximum = (MAX_CFFEX_DOWNLOAD_BYTES if url.startswith(
                    "https://www.cffex.com.cn/sj/historysj/") else MAX_QUOTE_RESPONSE_BYTES)
                declared = response.headers.get("Content-Length")
                if declared:
                    try:
                        size = int(declared)
                    except (TypeError, ValueError) as exc:
                        raise RuntimeError("存证流式响应长度标头非法") from exc
                    if size < 0 or size > maximum:
                        raise RuntimeError("存证流式响应声明大小超过下载上限或非法")
                chunks, downloaded = [], 0
                stream = iter(response.iter_content(chunk_size=65536))
                while True:
                    _bounded_timeout(5)
                    try:
                        chunk = next(stream)
                    except StopIteration:
                        break
                    _bounded_timeout(5)
                    if not isinstance(chunk, (bytes, bytearray)):
                        raise RuntimeError("存证流式响应包含非字节块")
                    if len(chunk) > maximum - downloaded:
                        raise RuntimeError("存证流式响应累计大小超过下载上限")
                    downloaded += len(chunk)
                    chunks.append(bytes(chunk))
                body = b"".join(chunks)
                # Preserve the ordinary Response API for the provider's own
                # validation. The network body was read only under its bounds.
                response._content = body
                response._content_consumed = True
            session.raw_response(url, kwargs.get("params"), response, body=body)
        except BaseException:
            response.close()
            raise
    return response


def _fear_score_evidence(signal_day: date, mode: str):
    return fear_grid.fetch_score(signal_day, mode)


def _fear_reference_evidence(signal_day: date):
    return fear_grid.fetch_jiu_reference(signal_day)


def _collect_quote_batches(fetch_batch, batches):
    """Keep two jobs in flight; join writers and charge shutdown to the deadline.

    A running requests call cannot be killed safely. Executor shutdown can have
    a tail beyond its configured socket timeout, but that tail never grants a
    new deadline or permits publishing an over-budget successful result.
    """
    results = [None] * len(batches)
    pending, next_batch = {}, 0
    with ThreadPoolExecutor(max_workers=2) as pool:
        try:
            while pending or next_batch < len(batches):
                _bounded_timeout(1.0)
                while len(pending) < 2 and next_batch < len(batches):
                    index = next_batch
                    future = pool.submit(contextvars.copy_context().run, fetch_batch, batches[index])
                    pending[future] = index
                    next_batch += 1
                done, _ = wait(pending, timeout=_bounded_timeout(1.0), return_when=FIRST_COMPLETED)
                for future in sorted(done, key=pending.__getitem__):
                    index = pending.pop(future)
                    results[index] = future.result()
                _bounded_timeout(1.0)
        except BaseException:
            for future in pending:
                future.cancel()
            raise
    # Includes executor shutdown/writer completion in the original budget.
    _bounded_timeout(1.0)
    return results


def _prefetch_mo_replay_verification(quotes: pd.DataFrame, clock: datetime) -> dict[str, Any]:
    """Record all Put cross-check variables in bounded batches, without selection."""
    symbols = set()
    for contract in quotes.attrs.get("listed_instruments", quotes.instrument.tolist()):
        match = re.fullmatch(r"MO([0-9]{4})-P-([0-9]+)", str(contract))
        if match:
            symbols.add(f"P_OP_mo{match[1]}P{match[2]}")
    if not symbols:
        raise RuntimeError("MO原日复核存证缺少挂牌Put标识")
    ordered = sorted(symbols)
    def verify_batch(batch):
        response = _evidence_http_get("https://hq.sinajs.cn/etag.php", params={"list": ",".join(batch)},
            stream=True, timeout=_bounded_timeout(6), headers={"User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
                "Referer": "https://stock.finance.sina.com.cn/", "Cache-Control": "no-cache"})
        try:
            response.raise_for_status()
            raw = _response_with_size_limit(response, "MO原日复核报文")
            try:
                signal_evidence.sina_mo_quote_variables(raw, batch)
            except signal_evidence.EvidenceUnavailable as exc:
                raise RuntimeError("MO原日复核报文返回标识不完整；不能承诺自动恢复") from exc
        finally:
            response.close()
    with _network_budget(SIGNAL_PRODUCT_NETWORK_BUDGET_SECONDS):
        _collect_quote_batches(verify_batch, [ordered[offset:offset + 64]
                                           for offset in range(0, len(ordered), 64)])
    return {"day": clock.date(), "symbols": ordered, "state_decision_made": False}


def _resolve_gov10y_evidence(market_day: date, clock: datetime, frozen_rate: float, anchor_day: date):
    return chinabond.resolve(market_day, clock, frozen_rate, anchor_day)

try:
    from fastapi_poe.types import SettingsResponse
except Exception:  # noqa: BLE001 - Poe may expose a partial runtime module.

    class SettingsResponse:
        def __init__(self, **kwargs: Any) -> None:
            self.__dict__.update(kwargs)


class _CompatStartMessage:
    def __enter__(self):
        return self

    def __exit__(self, *_args: object) -> bool:
        return False

    def write(self, value: Any) -> None:
        data = str(value).encode("utf-8", errors="replace")
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()

    def attach_file(self, **kwargs: Any) -> None:
        name = kwargs.get("name", "attachment")
        data = f"\n[attachment: {name}]\n".encode()
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()


if "poe" not in globals():
    try:
        import fastapi_poe as poe
    except Exception:  # noqa: BLE001 - local CLI fallback must survive partial installs.

        class _LocalPoe:
            class BotError(Exception):
                pass

            query = types.SimpleNamespace(text=" ".join(sys.argv[1:]), attachments=[])
            default_chat: ClassVar[list[Any]] = []

            @staticmethod
            def update_settings(_settings: Any) -> None:
                return None

            @staticmethod
            def start_message() -> _CompatStartMessage:
                return _CompatStartMessage()

        poe = _LocalPoe()


def _install_poe_native_compat(poe_module: Any) -> Any:
    required = ("update_settings", "start_message", "query", "default_chat")
    if all(hasattr(poe_module, attr) for attr in required):
        return poe_module

    class _PoeNativeCompatProxy:
        def __init__(self, wrapped: Any) -> None:
            self._wrapped = wrapped
            self.query = getattr(
                wrapped,
                "query",
                types.SimpleNamespace(text=" ".join(sys.argv[1:]), attachments=[]),
            )
            self.default_chat = getattr(wrapped, "default_chat", [])

        def __getattr__(self, name: str) -> Any:
            return getattr(self._wrapped, name)

        def update_settings(self, settings: Any) -> Any:
            fn = getattr(self._wrapped, "update_settings", None)
            return fn(settings) if fn else None

        def start_message(self) -> Any:
            fn = getattr(self._wrapped, "start_message", None)
            return fn() if fn else _CompatStartMessage()

    return _PoeNativeCompatProxy(poe_module)


poe = _install_poe_native_compat(poe)

BEIJING = ZoneInfo("Asia/Shanghai")
_RUNTIME_CLOCK: contextvars.ContextVar[datetime | None] = contextvars.ContextVar(
    "ic_im_v1_3_runtime_clock", default=None
)
_HISTORICAL_REPLAY_DAY: contextvars.ContextVar[date | None] = (
    contextvars.ContextVar("ic_im_v1_3_historical_replay_day", default=None)
)
_OPTION_CHAIN_REFERENCE_DAY = contextvars.ContextVar("ic_im_option_chain_reference_day", default=None)
_SINA_OPTION_QUOTE_BATCH_SIZE = 6
_IC_QUOTE_QUERY_CACHE = contextvars.ContextVar("ic_im_ic_quote_query_cache", default=None)
_COLLECTION_CLOCK_ANCHOR = contextvars.ContextVar("ic_im_quote_collection_clock", default=None)
_VERIFIED_DISPLAY_ANCHORS = contextvars.ContextVar("ic_im_verified_display_anchors", default=None)


@contextmanager
def verified_display_anchors(anchors: dict[str, dict[str, Any]]):
    """Keep the committed display head separate from a recomputation anchor."""
    token = _VERIFIED_DISPLAY_ANCHORS.set(deepcopy(anchors))
    try:
        yield
    finally:
        _VERIFIED_DISPLAY_ANCHORS.reset(token)


@contextmanager
def collection_clock(clock: datetime):
    """Advance only quote validation time during collection, never strategy time."""
    if _COLLECTION_CLOCK_ANCHOR.get() is not None:
        yield
        return
    token = _COLLECTION_CLOCK_ANCHOR.set((clock, time_module.monotonic()))
    try:
        with fear_grid.observation_batch():
            yield
    finally:
        _COLLECTION_CLOCK_ANCHOR.reset(token)


def _iv_observation_clock(clock: datetime, collection_started=None):
    if _HISTORICAL_REPLAY_DAY.get() is not None:
        return clock
    anchor = _COLLECTION_CLOCK_ANCHOR.get()
    if anchor is None and collection_started is not None:
        anchor = (clock, collection_started)
    if anchor is None:
        return clock
    start_clock, started = anchor
    return start_clock + timedelta(seconds=max(0.0, time_module.monotonic() - started))


def _now_beijing() -> datetime:
    return _RUNTIME_CLOCK.get() or datetime.now(BEIJING)


def _beijing_clock(clock: datetime) -> datetime:
    """Normalize aware entry clocks before any calendar-day/time decisions.

    Helpers retain their existing naive-clock interpretation; runtime_clock
    continues to reject a naive public runtime override.
    """
    return clock.astimezone(BEIJING) if clock.tzinfo is not None else clock


@contextmanager
def runtime_clock(clock: datetime):
    if clock.tzinfo is None:
        raise ValueError("运行时覆盖时钟必须带时区")
    token = _RUNTIME_CLOCK.set(clock.astimezone(BEIJING))
    try:
        yield
    finally:
        _RUNTIME_CLOCK.reset(token)


@contextmanager
def historical_replay(day: date | None):
    """Select an explicit completed session for audited catch-up only."""

    token = _HISTORICAL_REPLAY_DAY.set(day)
    try:
        yield
    finally:
        _HISTORICAL_REPLAY_DAY.reset(token)


import ic_im_quarter_roll_v1_3 as quarter_roll
import ic_im_v1_4_policy as v14_policy
import ic_im_put_execution_v1 as put_execution
import ic_im_sse_contract_identity_v1 as sse_identity
import ic_im_adjusted_put_migration_v1 as adjusted_put_migration
import im_put_policy

BUILD_ID = v14_policy.BUILD_ID


def _report_build_id(mode: str, clock: datetime | None = None) -> str:
    """Use the producer identity effective on the report's signal day."""
    if mode not in {"intraday", "close"}:
        raise ValueError(f"unsupported signal report mode: {mode}")
    current = clock or _now_beijing()
    try:
        signal_day = (
            current.date()
            if mode == "intraday"
            else _latest_completed_exchange_day(current)
        )
    except CalendarCoverageError:
        # Report metadata must not prevent the verified snapshots below from
        # being shown when the next calendar has not yet been installed.
        return "未核验（官方交易日历缺失）"
    return v14_policy.identity_for_signal_day(signal_day)[0]


def _im_call_current_text(
    call_contract: str | None, no_call_signal: bool, call_finished: bool,
) -> str:
    if call_contract is None:
        return ("规范化0张（已核验空仓）" if no_call_signal
                else "规范化0张（已核验空仓，等待新D10/IV26信号）")
    if call_finished:
        return "0张（旧Call已到期）"
    return f"规范化空1张 {call_contract}（只覆盖0.5倍核心袖）"


def _im_call_finished(
    contract: str | None, expiry: date | None, signal_day: date,
    close_confirmed: bool,
) -> bool:
    return contract is None or (
        expiry is not None
        and (signal_day > expiry or (signal_day == expiry and close_confirmed))
    )


IM_PUT_POLICY_REVISION = im_put_policy.REVISION
IM_EXECUTION_FIX_REVISION = "im_put_execution_guards_20260908_v2"
IM_PUT_EXECUTION_REVISION = "im_monthly_reset_20260907_v1"
MOMENTUM_DEBOUNCE_POLICY_REVISION = "ic_im_mom120_abs20_2d_plus1_20260915_v1"
MOMENTUM_DEBOUNCE_EFFECTIVE_DATE = date(2026, 9, 16)
IC_MOMENTUM_POLICY_REVISION = "ic_csi500_ma105_mom24_w16_abs40_static_navdd6_20261008_v1"
IC_MOMENTUM_EFFECTIVE_SIGNAL_DATE = v14_policy.IC_CSI500_EFFECTIVE_SIGNAL_DATE


def ic_momentum_policy_revision(signal_day: date) -> str:
    return (
        IC_MOMENTUM_POLICY_REVISION
        if signal_day >= IC_MOMENTUM_EFFECTIVE_SIGNAL_DATE
        else MOMENTUM_DEBOUNCE_POLICY_REVISION
    )
DATA_CUTOFF = date(2026, 8, 14)
V13_HISTORY_DATE_INDEX = {
    "IC": (date(2005, 1, 4), 5250, "beddc7d6e25a7cb87f1397fb605f3a8fd58c10536a95fb3097ba2ac38e70a56d"),
    "IM": (date(2014, 10, 17), 2877, "02a7c85e361550e11d01f540974ab8b59f54c7791d32ed311464819efc652125"),
}
CASH_DAILY = 1.03 ** (1.0 / 252.0) - 1.0
SIGNAL_NETWORK_BUDGET_SECONDS = 90.0
SIGNAL_PRODUCT_NETWORK_BUDGET_SECONDS = 45.0
# Generic queries stay on the verified ledger through the settlement window;
# an explicit close-signal request may try fresh, fully validated data at 15:00.
SETTLEMENT_SNAPSHOT_CUTOFF = time(15, 30)
QUOTE_OFFICIAL_SOURCE_BUDGET_SECONDS = 4.0
QUOTE_VENDOR_SOURCE_BUDGET_SECONDS = 8.0
QUOTE_FALLBACK_RESERVE_SECONDS = 10.0
PERFORMANCE_NETWORK_BUDGET_SECONDS = 45.0
MAX_CFFEX_DOWNLOAD_BYTES = 8 * 1024 * 1024
MAX_CFFEX_ZIP_MEMBERS = 128
MAX_CFFEX_ZIP_MEMBER_BYTES = 8 * 1024 * 1024
MAX_CFFEX_ZIP_UNCOMPRESSED_BYTES = 96 * 1024 * 1024
MAX_QUOTE_RESPONSE_BYTES = 4 * 1024 * 1024
EASTMONEY_FUTURES_TOKEN = "58b2fa8f54638b60b87d69b31969089c"
PRODUCT_NAMES = {"IC": "IC 1.4 / 中证500", "IM": "IM 1.4 / 中证1000"}
ACTION_CN = {
    "HOLD": "维持",
    "ROLL": "展期",
    "ADD_GRID": "增加网格仓位",
    "EXIT_GRID": "退出网格",
    "RESIZE_OR_ROLL": "调整或月度重置",
    "RESCUE_NEXT_LISTED": "触发5%救援",
    "OPEN_CALL": "建立新Call",
    "WAIT_IV": "IV不足，等待",
    "WAIT_IV_OR_CHAIN": "无有效候选，等待",
    "CLOSE_CALL": "买回并暂停",
}
EASTMONEY_SECIDS = {"IC": "1.000905", "IM": "1.000852"}
TENCENT_SYMBOLS = {"IC": "sh000905", "IM": "sh000852"}
TENCENT_OHLCV_HISTORY_URL = (
    "https://proxy.finance.qq.com/ifzqgtimg/appstock/app/newfqkline/get"
)
TENCENT_OHLCV_PAGE_COUNT = 1000
TENCENT_OHLCV_PAGE_STEP_YEARS = 3
TENCENT_OHLCV_TIMEOUT_SECONDS = 8.0
# The Tencent newfqkline daily index endpoint reports volume in 100-share lot units.
# This is a fixed property of that endpoint, not a cross-provider estimate.
TENCENT_OHLCV_VOLUME_TO_SHARES = 100.0

# CFFEX/SSE official weekday closures for covered years. Weekends are always closed even
# when the State Council designates them as make-up working days. Keep the
# covered years explicit so later years never masquerade as a formal calendar.
# TODO(calendar): add the official 2027 CFFEX/SSE closure schedule immediately
# after the exchanges publish it; 2027 contracts are already listed in 2026.
# Historical years are backed by annual SSE/CFFEX notices, all four full
# official futures session sets and 48 observed futures expiry dates. See
# tests/fixtures/icim_historical_calendar_20261022 for source provenance/oracles.
# Unknown years (including 2027) retain the existing strict execution gates.
_OFFICIAL_EXCHANGE_CALENDAR_YEARS = frozenset({2022, 2023, 2024, 2025, 2026})
_EXCHANGE_CLOSURES = frozenset(
    {
        date(2022, 1, 3),
        date(2022, 1, 31),
        *[date(2022, 2, day) for day in range(1, 5)],
        date(2022, 4, 4),
        date(2022, 4, 5),
        *[date(2022, 5, day) for day in range(2, 5)],
        date(2022, 6, 3),
        date(2022, 9, 12),
        *[date(2022, 10, day) for day in range(3, 8)],
        date(2023, 1, 2),
        *[date(2023, 1, day) for day in range(23, 28)],
        date(2023, 4, 5),
        *[date(2023, 5, day) for day in range(1, 4)],
        date(2023, 6, 22),
        date(2023, 6, 23),
        date(2023, 9, 29),
        *[date(2023, 10, day) for day in range(2, 7)],
        date(2024, 1, 1),
        date(2024, 2, 9),
        *[date(2024, 2, day) for day in range(12, 17)],
        date(2024, 4, 4),
        date(2024, 4, 5),
        *[date(2024, 5, day) for day in range(1, 4)],
        date(2024, 6, 10),
        date(2024, 9, 16),
        date(2024, 9, 17),
        *[date(2024, 10, day) for day in range(1, 5)],
        date(2024, 10, 7),
        date(2025, 1, 1),
        *[date(2025, 1, day) for day in range(28, 32)],
        date(2025, 2, 3),
        date(2025, 2, 4),
        date(2025, 4, 4),
        date(2025, 5, 1),
        date(2025, 5, 2),
        date(2025, 5, 5),
        date(2025, 6, 2),
        *[date(2025, 10, day) for day in range(1, 4)],
        *[date(2025, 10, day) for day in range(6, 9)],
        date(2026, 1, 1),
        date(2026, 1, 2),
        *[date(2026, 2, day) for day in range(16, 24)],
        date(2026, 4, 6),
        date(2026, 5, 1),
        date(2026, 5, 4),
        date(2026, 5, 5),
        date(2026, 6, 19),
        date(2026, 9, 25),
        *[date(2026, 10, day) for day in range(1, 8)],
    }
)

# These compressed CSV blobs are generated only from the frozen real-path `date,ret`
# columns and are verified at runtime before use.
_RETURN_BLOBS = {
    "IC": "eNpcnVkO5TiORf97LREP1iwtp4HKDTRq/2geWhycNWVFSM+WNVAcLi//87///efP//3z3/+pTxl/n/63zD9/n9/zPG33M3otc64hf3xKdFl/pEdde+zSzi511T28tT60liF/fcp4+ljPmtFaaO2jtTXqM1bfo/ezor3q6+WPqzx7P6fu2s450aHxgOfMIY8vrew1n3FOjw5dOzBm+eV85vPM83nCer9w77bl6bscedB6nvSI/fZozymzP62u0cc+Z0ePox/5lF3Hlr/bXYbpre25Q5AXd3nyrGM8x7+SPvqCUmWQ+1n1mX3MGs1Df9+bTE1/5jyzrxGtU1tl9Hsc+Xz5gvZ9+rs+fZwm/z2lzyZjKdF+P28+a5x1mizGZHzbe5TyvmLKQuwq09yOfEF6RKnaoZ5ZZH5K70P+KX+ODu8yVVmc/nR5tgyhxipIh3eZ6pinyQzW1Rlr7jB8Edp42qqy4Ot8BvF+R+Hl+8hHFFnKNARdIxnd7vK7Obv8u+Q32E4dY8/RZLP2Mma0lncWd3l633vLTDDCaJedun+9yC4bs5cj0yTf8Y80RRddR/lTnbPJw5999mcAupK1LF3oM9rDdMYH1mUDbKXMPXuV3RCt+12kU9aQ1vGMKet0Uodz17ltWb0qCzHbSYdp/n30G1s58nVylmSX7DmfFu26zGXN3adsODlzHKcS7e2ugJyE3lor8iFl5g7vRpdzSI8xeVNZ0fxu9CVTK+vMDMtExydM26ptyffL5y15gUxUNL/HsA1ZOtl/p9a6YvRF17c9a9UpR03kiUxxtN49LluUjcwp2XJWR3R4P363ypfrTk1Tc7dnWWvvuRnZHnP4GZomSCs7SD6qyyTOetLcvGK0yMhkXmWHrpZWptgZrXKGZenmWkvmMA/g/XaZ776qfKAsQPfG+i7M0xHOsm3kCI018tLXfnvotnlGkx2EPIrx1fuFrc4uiyNvEFmYXvGKIZHi55FtrcLsnDQBr4yUr+8yPBGBTHLeXCIlX1HPT0VUy/6U3edDXHd3ltpqW6vJMlX5nmjV5ZG7g63be5OVkF+vaFcJhFxaIoNPlQPaY32Wi9GN7OenskLp+5eJUdkAIlzrkNOxXAov25n1DJEbR8TDEFE38ujt9A3ZNktkTJEV7iEjF/vzPT1nzjm2nB4R1PGA0u4bZPZkmxzZZaPVNMByD1dbu8n3T5HRq570ieWVPyJ+ml62ckJ3S0O8W7QgIWR3yESJlFr5De9V2abctUvOgZxzWdD0hno/QS6KcsqR4cshbekJIkV1FgaDl8fIfSYiKM/CvfEL98OYslvX6SWW8b3vRfCtLasry3h0n0X73ceb4yNCfIri0HuehXvfyybjBhAZILOZXr/fUzjXXvKzibax8vNtGXsdFfHVJjvV9/GyfSwKkygrck4fBtKj+d3FImgGDZPhxS7fLkNbl00gOpVISS6K1KG/QpjjKT+XLrOGjN0mRMtZcgnKRSNrNGe0vtt8yu6X5ZWXyE5cT/75ehUq2WdyFsbhJtuhTuwrRmUPiRyo6HxyIkp6QCl3AevUNZhdbqoWzdXuiKH/keNc8tPv58vrRZkRpVKXIj/+LjA3ICqpnGZRufIXvIJUdoCoRLJ+0ktuq5Nm0ITpqXJBzi0qiQitGffMRpjek7DRGEUiyhq09IhXV6icP3mMyBx5R83tr7Ygu1hkoWziwn98l2/fpiIC6ulyoYtMite/igIi4pEplplcbeQt8Mpaub3lC+SsbdF+T0szcLe4XC/SJCJtzr1Wevz9fhECsotEUTj6qvSAd5M+yLCFrJcrT+bIN/m5slhEiWhDIgpkq4t67yM8SOP3GIoM05uEtRSRvaLHK07lkIvK2dG55d7MT7hX/RBZKlt18R115Q7vGqEDNVXr5WEz9NpzN6r8ddc9IJdG7/XkUd6tKrMg17IsZj+s05Of0a+4QeQueZGsaPF1PFekiqxkoapc63Izdxc2x0RqXw2lRrQaWTNRvmIir/EkLSLVNxdTe2Ye4r1XZCc20czYRHs8qUO9SyU2lKjfU2VezHK1dZAtVsUIW6g0I5qvXoC9UOTGW1WUJ1mMEwO0nSo7TRQXeQpX485zZIqBnCQZvGxnmYWVF8L2m9hNItFEeRSR9aSb6bhUFUn4iPkiup3I7Jjla0Cxg+ScNGZrhOJZHjaLfqVci6J1yuOXTJR/BR1e7aii8cp+ELnml4q0XtXuQenjIIr+8PT0+Gu9DI44HRYXoMsLOtxJatg+MgqZjHXS81+RPNhAcjGJ+iS2Q7ROm54jm0h2ehO1N1qvKOKuV9VRhGavaXD1WpdyCMVEHLJNR48PvwZ2xTiUCxNx9Ligov3dIDIiNGYRZgUD1nY4Hd5vl3bZ3+01PGQTPTH+Os2A7k3kwFjyCJYnpsdMbLkTZeHkGIqOuEocRbq8K3hQSuW0LfwN+9PhNd9kZmWHsUXlU+aTN0Ez/amgOR5UzO1rVK6CKNa1eChU2MhyLtc86NBsp1d8ALIQItN3NL/3bnvU6JiifrtqROu7xIiQLkKgVzFRwkSmw/xzdSuRuTLFspFKi9ZXORYnh+gjMjq+v6RfiyyrP/TJebVzscGTcUmPe+2KTcbIZQAy0vj6e+2KmDkd7Q4VXr4lfX4xWSD2n6jGMoejjWTF0+VVHmQnikQVA0OuaD9FxbRDURu3mD8ySXWeEp4IeryLLNtxICNkmbl6P2+4q1zVUyBmOnpQ2ijFtrscItGf5FoWyVieT4f7HWd3eYicU/FX9PHpcU/rwYKTbVZEKPGhsRzvBSyzLFpOU4VbrtD0IbblZYaLqIHyJb2U8h3nej1bMgXYueiqOD68/ZVpYh/LNIuWIsqYnCsTiaVyw756oDxB1lw+RZrjAdWuWFSMh0tyHi7jaPZpEHEqh050BOxN3zHVjHE5JK2qpVBwb8RqVO7o8hP9lttDHiRvkBOedl01wbvk9hFVGL+WLNrnEVeyi1wQPVBsE9S2mXtcsweNTk7F4BYUZSGa7/0mN6jIpiYisu0kGKrL3oPJ0XArNPc/0jxsV6KgoGvJ5gtdhh4mf0W0yMeik5UWOjE9Xo1SXi92B54TuSfTG67fSRTmg1HecZt4672fHw7dFG/HfhDF+QPqK5hEU8I1JXdUV69MbIUrgheK5uZkd93yMUeuTeLeE+klZ7wi5dMohq213EwVNUIWTA5WfIVf0ni4REpv/AD7MwxTitG9EfSy1jFH947enNwq84C+Eb8VhfJv/al0XENMQtmM8gzbSniernzdjF2WeXBFy27b0W4eFqZ3iGWwbJ+8zXcVRdUqaHPiJtlYWCt6vKqWzBx+bLmJZCpGfsGdARGhIt2PmNEi/6c3l+t+kB2KIol/6onXXw8o6oU8Xj5PR5/e/uoQ8vOG31KWGI/5uwve9usDLmgmcpC45Hd6/nh/fjCcUAJxc+Sfv3aryCIxyWQFmIB7gbztV7B2aRKBKKt3DmIzBnht94cDIrJXXI9iHK1Pj3cryxkWOVBZoWfYUXw73Eumi6IgCrOsgEjGk6fJ9qF8n3yCOFBYzHNP49tjXh+guBhE8G3uqfl5yesnEweA3FQy1oV2G606D7xYdqfoWrIFZs+/tk0sF8jkXyIT++MdXO6KhiJXnHjRzhChsO9pe3uETj3RuDEOVo+vDNmLjihTxTDVH5Z6dFO8RSxqu1y2hFV6dLlef9kpYrrIJXXWk2Y7JNtEJSrq0R3dPL5vDz8T4tgX5VC0Hrm6Y7ar39kst9xD+DtwD/qpqOnOVuVb9PoVAZS3h3u2xOAX6S56RW+fZ9i+QLsnNiLbGIMozYdpmbJthljlFWsotZoNImJP5KdosGLLrWh+/VoEZbhaMGTyj6dfhAvP2cALaurp2+O6jftWAfrguLHPa34Ri3Ulm0lMRRFArUfzPfgdl5bsSI1MxKe163gUhYjQQ62of/nnJrrFvhNXD85dec/n9+/lo7a6nJuJdm1679vhXSGRC3LDTCzI0dO5bVe5fDjP4hTCvyoyIHe4lnIl9lZFfZUpeNISNzeU5Q4SrycqD+G2J3ZSswCOmp943ERRXTUP07arfIO4gNWQLbqTRnS5SyXzhGNEtEg5Pqn5nQmMBLYqTsRazBR5e+wbh5LdjntaNPjx5A8x/yNavDycYFpvT+zVdm9jEcPIDrnmMBhiudxgXqIxTc69+HpnNJtzSu5q0dvEi69GTB7AuPa8CBZ8a+zYtXKH+wnioSNIImLh8/53KSs6utiCIh3lRd5qrkeRaTgaJNZacMSmp1/HTkMFEAkuocyZpWt38YdqLDo8flRRIKP5FUqiUYoyIgq2dNktWqc5lsQKlvt7I9dq7LTOZn5HyCDF67QQOPszgKtNiQhnYeQuflZqvuqgzHtBFah1q1WeOlRTB9G8RZJw560bEX57vAeyYDigcBVcDtHqnjnRf0RBwP3GLqvRQ5aw/+RW4QoWXVMkisiNpMt024e4x4hyHGzudGa7y0wCyk1PjYy3h1DyuLl8o8R05Sxo5Cg94V7G+COI2FZkYjpMHjrHHJO3DJwbo++4HvqVmwQc8WY0dIosurqLThG7E7tQron6tDzb72Us+qKo/2J2o5vX8XmEBa7khkFyYm3V2A9m1Tc+ULb8LjHAcUWnxpVFsZJ54BHpOI2rNMrcyBpJ0FBCo6enq2eY1ijCTzRa0Yxw0+4k/Dx+vtQ8Eo89wxifR9zg/sM3Njn3ctkPbzXzRTxGhL1lnPKPmX/vwlOGKAd2Esfv8Qm2YSv3uFw8opbN2qLZXXSIZzkWc2tIIb/AlkkM1o5PHh0xWteV/gLd0FMnpz7pZB43R9WQ20lcyZUt+X3D+bN/IrL3FL15DVVxV9rxI7RHcZMX/DwiQUVxSvNsV7w4rCdWuZhyMhtxKIZLz4fYhGxGdtUzvl2G3RCilG1CyNhdeUe4NwoVT7YDSAM+vEePdR1BKG6Y1SJoRn7ENWVkrjtDwe7uMYRXhMppFEfZUXVF5t1/PV2CSlhLdJiGo2KsHR8xXYHEEVwJ1qpfLIY4bePjwZIoxoNDxk2daTuW+JWsEwdrhzft7XFvShxV4FokLDpXtF6VTnQwuSkPWhFfcKLHKyJlTLJrCHcTL19+2U8TkuL076hFfapOlD7xXvZyxaAly49FzpWdRmh7lu+TS0jcll3hGPGVpprKbiHWVBAvqPVpmq4vaMtMyFSIbnX6SJrddONbDJXKlpksRbRejyCCrXP4RLU9IX+mbdlJpEU0aHnC2jEJF1kky88nYBLvtfMqmNuzMb1qq+xnlk8PO3oLc2sQCT0IHxfj013j2OIN70p944HxELv1ZZtLwBjlVaTkjuO7fEuKZY0L/YCe2DO25DI5ioSXwwA2JWTQcuemfAB6gdgjEwX/RIeJec+pFHjFQCeQO6slAWHhc9Ec5NfiUiN4uZN8WLYrwS3ITIkPBrdUfonJUbkqRAWum1U9yapaLkpFwxQZvQvhkJHsnWWefJBk4kfXADgfkh7RzQEpRoJMJO6Y+uSpus58zgXhTxmLSM3POLd5Y0Szk3CRGD0iOT+POLZiHTjKFp0aTTStWDURxNZbOFpXmkv3KSHK+6P+9h6tdqGIDiy2PlHA0FFXMsHl1BFWkttKzNy0En7to7qIAMANfj6faEikqmAmXNUrLUM1IBZIi0KAWbyTaQBXh+2cHJk8tnOLj983uPg0BbsQXZcF6jF/2wUoKB2wLqIZrJH0Eo+icwXIPlpE11p+gN00m4jLwM9D9C/OvofRZeHkSn8UOtPaE7ttu78IRwEB5M58Z7tpozoM0RRl+WSSRQ4jKWo6FtuDlFxVciSKwlo+r7kar8YEHrzEU2Ox8TG263EMyang1nnqZzbulpVLtbPVKhCVHoJ0hwZxcA6Jy11mY6ZBmigmirqBziTX2xtPLz/kqOxnAYUIcEFUpe9nHnuC4jBlpPio0p2zTRpXFkREucwHEa30nWZ7iXmJJ3qrwvzkNbsSGU+EWLi4oze2dPrQalDKgn+OkKk6qNJL7t2Kv7wDFKzE/T/jvNsXiBRKmVgIWdpuUx9E2p6l1pM4smItzAIrYGXF/FEMSozAQuugJ0Q3IS6/uXtzh+pyUJZL5Je40XaSlMeVXpbqKM6lKWy2R49p1rp4p+RiWzito9UgsYVbgpioWgguJj06z10AoleOlxzBErPg4XmxYMTv/3AMZUHjI66/VI7vIiz94DpPW/I4EOR542HiOAXwEM1X8RfTRMRPR9CO9GOLJ4snBMc/pk/5TJHpq9iIAAIfwmormu+hI1QoX4at607GiKqLRwV/GEJEwV7x9bJX5USI/rjwCBX1Lc10Io5tNKKIbABZY3HrR6upDl0n9+CTXTF75iQQCJdsdPGTyOzuvEeqh13wX4jqwko/eQIspt5Becrq8g0hNAg8W1xGxE3DnSEThdvIvpIudiMT4arqdcgXxRtZv7YPunAnclwV+Luii0GDwS5WVVlPiVZz/SHfCeeJb2iOzyvMpVC3GpncpuP5DHP/mb+hwg+wihipRcVTGsN7pmUeF0AW2QnblvuNsF/pKK6nqijrbfftG2J/TVzRLsWtLWEwdHaXS/R4N6tcUtgchYu3lDwHbtYQnRDBpOi0nb/S5JLcAlUdBvjOo9XnAECQuEgbuzbPgWmaohS9rkh5CfMYz2iuXg0giCLTCuhf21QEqe+hqNwPmy1dk9x5Q+x3yxDeEPNGEWJpyxS3bGSz49B+UDCeTwe/mtESD9Gog0vBlLhigRzUHlEckK/ixWmfcZh0QmPFmBXcS6vRbKJJPScbV9gyL9oba39/jZ3bCIV3jeXE8++VjIKEPj65KHq0um9fA2myaV7pedIrrkKNwk9mhKhBp/mlnyLtIvjULpBNM3qeJvOFbgAFaGhDIbFPeoepJ3JqBk5leVCNN7gnVHzOrOPG8f15hV3IKKZiu4GcLita27UYOHS4VtA1o9WOrYRONgYkCKXPRrAt3xBc4tGWTbnb+vSweByBHvFJCxyytPQKk/Eb5Y99tDn4ab9eEYdgJfZKvK9ETC5i7MRYsAzJnVhABVKPdw5EkxUjdeNqmI6pfTu4fwkPELJ+9DJjKas7RVtRBBhRNxGjMc4aTlEspzdGM5/+eYsFZzfwLJlwuZVaaJopzi7iXgSsaHhigT3n0+WinAaxO1F58W/2ltsN/4Jo6jiv8Tx8nmA+/qGzUAjD9mg1w6JogAC8Ub5zcqQdj+LWGGB3xMHbQz7j/A5CA11Rj0ZLvlXC0BfvBHRCnInLTfI32H5xWBrJ37Ua6nKmSDtz29AwgW+uJFo8DiV+SADqD8jGNaPVxi8HXjZT15B+y0tp/tCmuQ0c3rN7noJq4bRN+FdWnCjjk6fA9nVBYZe9JFFozO70DHfzc+PJXOFym7pZlsax7zoS3VYfOSfLvPDrhtqvaOAzOfi4F6LZIjX498m7kl3yfuPKkfaCCbzQe6Sf2WdvD9uME9uWq53jZ1+pXVy7mBquwxU42ArvQq8bcL8BIzm3YnZUvGjbNuS6UXeHzoEs3LjI+6fHXdCisHhRtXBvRusLyqogcEW+oMDioIn2ZZ7VgWHzbL0c86eap19VAzncIOhmtBqcCXAPfl/RgWMOTK8gLw1HBgk9/cmjN5NH7idFkSOJaqy02TuyDjj2NW/EXcPrxtvvLMtef32iq3wWwhQLIIIiAdWktw+ISDbJOGJuPLhM945m2Qrjx+tFnoAk5u1u+b1dbAoVE4bDUI5mtO6bGke6jcS6JKzm8vXtcK0tnUPptUroHNrBDGi9H7aifHZqvepGw1mBMo5UjM8P9FDTnD6AIdymscLV72q5xkXN1lVc8zMCxw8BahFlnhyTFc1XJABhEnTq1hh6fsEVaBJ8YSdgkoo2n8doEN9KtkMB7AyY/JVaK8fXRX8e2I2obvvJY7SNNIib8S0NZfnT48p2OUSgoDvn7fuI+x2gIUgewku38lK5M1MUgQXKRxq2Q/PXjaW/p3GzoridekutN5QuQkmWUm5auZTL5+fm1TnEDsH1c5WFZGtu16rk5TgNhZTu6HB1R7YsWLSKsvx5h4HjH2K/m9geVmbuYR5ZtkIhgtuAgfhUtRBugxwL9emy6/NAi2G6ZMOojQpS/uLj142nvz4uwi3i7tRwxrfHuMgDPR1y+smM+gzDfBmi3OE6ks0dAfeVIuooL4vg29hxOJvLJ1IRD24d6VHi/dXls0DFiERIvDTQfyuC6Y9CNBXDTvJmtFpWGpOD3sT5twDguvH0m7xb2VAvTD9/ot+3RFpwf53iIcyVw+l4etmzchGM8nnCcWzJwIbDTCyf1TQ1UrY1EgJkwKx5lGY5kYoj2wpJQWKDP8LD5uRLdryAApRZ5dPBAKUDm2ErAFnt5B1drsYvd+omer2QKU+Ige7bTvFd3BbnWePJr3GDnSPWsQt2j8Z7/JgtkQIih3ueiB6hSGxc2bSDCFdqvhKEwFcjPVXc6+lo9bhN0YRxz4my6pvRg+YdQUeEQrAqO/34uL0AIBatiU/wpe6+XRvKAGJyaywyDcD85hIqRzFCkJ7+meR3w4mraGrGjcSVWj35CYYmBam9uK5EzSt5EUxHJM8QLCl4mV4/71h+7Ys6QKqhiNTnM063fDqZQSpjtu23kRyADUFW2JdzxQNGxA9FwdRsCVmwHa1XbcDxJSMYBJZ2OreWcS7gBXKcgYnKU9LvX6whWttDhlUHrJXffgzCsQmfFDysfiEOSyATF0ZnbkkCrcO32UhxHlL/xNFBzHvkz5Oden5ymGTqEYwkBu2sdYxki8j9AByeqz1aby4uTjs50KLIE6TJQ7Al2gTzAYFgxX6GcPMVCIY9YEiGqmgxScXV+KruBZXdT36E39obxQHX1rPiCyz2SBbjQwB0KTggxugmtvhNpU39dOPkIbzKHzkxJIXjMKqu+6ZAuag7qtMM0unjghmeBVY0kZRQD+kj/gLLF8cYFVDCRuw9rntZtjhhIAC1KpzzNp/hpt64rB5NjJnr8wKzneWoFugdJMriF4iFuQECVY4iMMiZWq+pJUYkeaQbV2z5DuBVLgdBwPGo6ttPHGbL+SZbE5SmnESReun+mSESpwYD5C0iels6Sx4rx9Ut4lDs9kLMK+6PGdQGROFFskFm4bnXK0fLCVCrc7GQzvPpcdxDIMKxaibW/AzV1EyxUzpO+S3ZBuvTwa6xRSC8A6DSy7RHj3qTdIBdydnENVbyfNmNDrC2aCaWBiHSir7mBnkVBbVD1cidvsOEoyaXkItOttsKzSnFzEXNls2A7+8JRpKVY+Z4goHJ4efYIw/DYjQCLpPwA2HOF3Rvi7Jc18T18+bEqaHt87XcisZsE/krV8XsI1pNOwOSgzNhFnfxLYuZvyvGlS/ONTGPejpeK/ycovkAIiZvqHmrK5mShEzigvhs9fenR5fwz4sjk0jLOc/I3+D++fdonqYGUNJUV2xxER8yj4vUO4Wapaf0i0AlG1osLHAK5dPhhd4fINnAImtXBoZoN9DfAI9HrEDUqNR8jUBQGIQp5Cz1nZ9fPVZBp6MRnTM/Y3TXEMlzwMfBqKZdE6nj2AbgF8hBbDHf7rAEmjqRBQ9A5vyKaSGVhq0qvcaODXVV1aImiWp4s8VuML8QXiM5mJrf1D8fcKWxbKYNuYR4xncWEjsh1wEvaiKq2iUjelTHpQOXAfjUHXewctycJDjBwYG7OQE3Xjl2rg58rH7ZEtirLXqE12RhzFYcE+XzDFdwwMdXzZscaS535A3JlmvAF4GEJ3Vv+/7f2BWaQj2Uu2NFj3s9DYCJ5I0McJQxCpfM3JDiRlc02cqjMMksVxc4VVmRCbIkP+PaWPNtkrt8tdR611z9uvAFIL6j1fNi2UwTB8CcPb//Kqy456YmWC7EclovR9aLpMY4AyM6Tp4m0yNARgLekT7ZeolUdM4Dc42kw0OaeljQnNsHfyayKO6FbZtX7MAN38Ez1SbOw7wHWKyG0TX9N8g11o2Z33gBSpkIGunSzqeH6+5yOFGHzvpsTA+ci89ZBGXD7t/PjtZu8EMS9gBQz5ml2HHiBML1QMPBZNRotdxHWQzub+nztM/PPWSrpjBQtNbLp8c2exqLHaIjMZLS3XZsx4oqIoCeqviinp9gPEsD1oCF+FG+qvhKc3fKFOHQkhPeyucjA94MSgoHsmhO6fcm5EROM8mTzPuRZ9kcnngVyEY4xAs+HRzcRE65WFHqFs2DNHATAQ+xdxfeoJkH6Z4F9DJy8fAlrc9iO8gJjKRsJ4lP7Scm0rbsJidEfl16xEvWDb8bnRSauUgxrrbPG5YxUg3StSBqOLEdDOOEAMWMkkN3jFVr3Qj8/UhBxUDOdW7ax4p8dEWobtio8CvG+N7o++tL474tCuffyVRNwfdGToeq5xKuDb9hCr6DHkMEdyL49fMWi8YuNG8uz9Lm5xGXEob1Aa4lJ+uUNAaT9JUbDeaCveIjTb5pwBjt2fPeVwq645ipGkwgPz5/oRv0spWIAXS8Fp/hmb4JCkQMRW6Z0eIN1T0SpE0TRlScbfr9dY8DBFokvTxKhJF7XPlOIGmTmSqbunxWyjVWjhPcZViSJfcwqMVRnH8BcDs+j/DQO3nGTclz1hOX3Rt6/3vRkaIviyGFShtXVaS3N/L3dTETTHSlyHtBIyWFHNKYOLgl4jqEKTc5+CDeSoRk3si7nxo53CQz9SQF39D7qwrKTEojubQzPLQp+P6QcECOfMd4f/JALB0JAQm2Rh3anw627BjWcBeofPn0MGm/SGMnR0fU8O9LrrSXw7MUYHj2+nyJ21xyqYkrWd7w9LzyFoMHfaDZUJA6mSiNRHUQtxs06npzF1IHX1PYjIAI7pk0uojAA/0bMNn0Wv14eQQe/hZFSRDlf/Kmudt/aaoMah7Aj2i9MHhiwQhz9RZ9fn6pRwYmZSWay20Tzff4Et3r0PrJG2r+vrvt24uCJztwz/BGvuH3G/yRiALwgq7Qnh0dbk4sEkTka1+vG6ZEB1vErp5jUUUhjssdbBHlfBObAerZZjRfGa9sDOIdqPB2xBxE4F18IJNcKZlB3K+pR3EMAZwKosRy425XnzzuLlJMLrqhOLfPVozAO0eStN+HcGtq7oIlk2tYQs1gTQDv1OTteiPv0gOlAc4kuOFkqr89rnmhOJEC65am+ufvsHOJrqvJQhIB6p8ubmXJjVOg71KILwIjuhjgXrOSCnEFaH982+VY1eTKE7laSzLmUq46ZG6d/NtK7v93JIaGIkNh4fpPsPmVA/GA+puCOUkxSpPupJ4og7gjlL7mM47jziekaQU9MgxvvjXObbSXRPzkZlKY4X3EvqH4m7GIprQgfgk9ZH9C8QM3IN5oHFE2YzuH42VNCrgtQgRzfR5ixiMaJVuc3OloNYUMEKbMWFF2uTsX+wbjb1QAU0t+vJsD/XbkvgNP7gRI4CpYz6eDIe9hOKhbXS7Of7JTAvvE4T3RivD/53bzm7etWd2kyjoIZt9g/JuHK/tPVhToV4/Gm/9eQShvjaq9u2HnOLx8FKaBcshwz0/vcUWtaPw8m8FDwvneWzuH4mVHTaAnj5JP5lW4sYMCmUcdCvYrMQTb1Qc/DjJVNOt68gyYSgqn26OsWEj1vN98RzJ9cr7e/Kg8R2ZHyY1QoX6Tt6hiGbvp2lFqd0/cNeIjm/EIk8oo59xFm63QR7QajwxJAWhW3IszpiHy1gnZgf4QsTzM4NwXNKBMjHDQEda8Ua9oN4UKiBExczFSCMmnHs5YC1UtREHE22KmDDbQUVCwlvZ+2qf97teGOivgEsgYas+zEPDjiqEFGWDdqdlhqZ1jSz91YEQPZy4GcyD3Jrl9xtO3U0geQiXktUQ2ISOI5puWyG7dEBnAG5I/wVMvJ3c3indPv97kqEJjJfaTmEBi+ov/wa6EnfLacXByN4OqH63EQrVwF6F5kK53Errm7WFhFlGyCESIvahcO+kZV1Kr4CTOC0eUSep9I/IGXnhBYaS09mg2OY2SgKZRONmfQdz0dlDqc2nCy7NjKZpdwLI+gO0FqCiKfjrbHozHqQgdoMKdZsx1BOOxyOHdaLA8rTwIM5whF8FLOYAk7TjeHo0HWTuIyVSI/z4dXDOW491p7GoFpC5+A0OfKccOVPT0cMO+UfnXqpKzBceCmI2tfJ7holpJBUCgnvp9RLvsR6gJaH/9sey/t914QkXLx6EDxLWmn3uYlywRTGfkcp6suHurGhsi7Ujvy0M4N8SohKkEJEpt6QnuL9IsSCjRSF6ORe8hqMSkUh4OEo3Srdc/vk4MxwOeuEYzateD6CAw1YCV951OUA9TBugolFximtWRpjJC8rClAj/qbMMdc+EJ7QX7mLt/loAX7RSWLwTyIIcgab9Fq9GzNcguxQIV5/c4cQK7eyjJcoTYq+j2+7zhpuYVEJckCPWb77pvWN7g0CTdqnNq9M/vXcGYKogFIhf62o5k9keVPRJfJGa9Tl4Lv13hIHzJd+HQSS/xbMsHBiUu8lWfvOCOoT/wo4mWAsvx83nJ9c+LDi67CvhDGbGa5u8pysglG/t8lLlh2p5S6AC2k3NVRlKTIuwOjwifCkXR8+ng2l7XEBlBpe7AoH3Z2m94i0jDJkw2/eyNJA4P4kHzcvv+DNNw0UWDXuhqmG++IyJlvWr8TNSs85R8eTnhe1UlgBDaAPycXmJsRU0jkguRKqLX5zoC8Er4DIhK1LKThdmwjdlJVZCxKjpxfV7iuGgUDTlgQMLO5xGW1UCmMbAzuURQG7r3EHHYfiKFYL5WCKPIy5JOcYThNUJH3iksZam5XU+i3K/sSWiP25NWJKDuFURyg5pi1zzKyO4AW3QUsjvbp8dFKaGcQj0pcqTHPFxLG4AUJKAToOCTh/Ba2uR7KpOsksXt9PgEUBL5os4+6in4EyyS/1J04oaSYMueSUg4dbt6CaqidXGZxKaJcL4mg4rDQ+INH3UhEtfJ7VeXINrT8xlHJPPInqBmwdP7+bxlO5ek0tWJXvQygMRr7u6F4Alq4gqodH86mGNUnd9yyNajWabxFk9KwnmBX1iSgWOUxbKlF4OorOle0TpMCig3HxGP+pmG1xrBupmak6CECandbnnR2JCoYGD6TvpI5LUXgvWYO6JUxQCMQltOZcGQ2aRQpObhiqMcK8i8du2fpxuNC4o7ewFdIO3oabKSUCUCBIqsrH9Pp9EGcyHfSNQy//wYYyw+ACb49QHfDkbmXlhAtfIr9ky0GroJnANhSjTLaL2ZgRujnvgJSZhPfvjlsIH6WyLFD5lM49PBIvMkxQ181qgXsT2CzB2N9cD0D4j+eLM572UAIHXJIP/s4ojMN4V7QHzyrJ028bJsDfxOJJXs+RK2Rfu9+DuVKqCNPWA14iytKN2CCgepx8bbGc1x1ESJhGx9Rybqzons+h0NRDDUqd9ROnGvYP1OVV7duuOy8Ux2aNDgoezoUmm3GaO7rKZqkRsnV4uPuEZ1U/chn8o8RWvcMnKBQCZEQvtnhL6ZxX9JKBohj77bo4cbIJBwkitZW5/5GW5VHyW1B0wK0Zbf2sslLKx0sqXk1CgiI+wcz2qH8gMrBGrzuqP1nln1L3aUKMkDTM2Wl4LrY2ia4EwX8g76QyZZPnRft3qNHtffC/pUorjQN84R+yWC8vCqwr5wcIwn18A2Sws6FGzF8sKU0jsck4Kbc2nq1Qn6hH0J3q8SRoKzuGVl68QkObs7NGIKMRRfys4faooF5FKLejvXjkqDsH3fFVUMMU+KMOwUlyfEgOgTm/D08+nhlhb+VnBvxJfKt8td0A4Au3dlQvlXj+oAZ3wxFWlZauwbj87jUT1cRYRC92dKHZXSFelHiGF/l96EcVcGOM3uBwgRy+bYEkxjblQ8nNFqQEWSDzidMCWs/AI3tshSgRJeCzV9ehR3MW44qqG9cBz21ti3B6bhH11k48w0Vx6fZ0kbh0g06JJah2fqAV6DY4RD4jN5QmhPReBoWtlOnxEBeijnCQwT9HXM5r6M8ddmfBR8TEZSKXmUJreFawWKZtJpqcLj0uS4bsHlRUZh1WBcNJvYJrme/AUohM9nEOZroAjQhFNqTE/m2Jcz/iKRCtkyi7DqjNarSz4EBOQlZMp9lsLirpM8D/l119BOGoHnJam0bXqCx7fHNVqXWtaPknTWPEQLrB6AyQit582/j2FeY6wAEjhQSpdw50b+O1gnTUx9iVPzG/ZFq5M7AKwHEmQf48sJf2lYQAhSDUV0pBXNxlpZKdslOx+Qb+gwEYKXEQ7yH2DU9nJJ+0bgy+9MzZIDJyHCaMGKNaOH2e7cT0ON+BEjNFr4SXbGVFhLiQFe80hLcimlrcBJQl7n4DtAMM33rn3Fbn0D8Lf22qaSBRnZa+YPuHqYFpwhV+Uo71Y84JIh4r8EKYIvMX5tNvtW18ILqp8tz+C12cV+xLlJ/K3PHq1+eVOwaUG7NrKalKLvLzC2K4Pm+PYwTWwyBZykscrMq2RhSAJf42WU3SU/wmDOMOAfDbPKDexHOvLewcvj+WO29golw4PvihySS1OcNF2LzkS7m0ZQJ22ltVn184R7HDD2iexT3qV8Ori6Jmo9iHsmM4zInPXeNO2Tm6v0bw/3MMIxDRhurCx9SvEk4U2KvuS5DBBd6RGXPJF6IzrXgK5jpkx2AeuVT4TtqZplFDH3c154MVT8/fHgRKS9Q31PkEgjnvvT4URuvqjeciBYtjxPVoKIKgFyEZAtM6w0y85hd/xdVXPExOkbn8CdPX7QXwHSBgcBnWp4DIJhHr+86FEwwfWSzlWK5Ii/Ta3Pqkx1fjJK6Jxwp4l8lWnudX2+4zKrH3IMHuZbWepmdDABhrYF9KgoX05aK7u3lbMccE3Hc5a6VLuWyeWZGMKypDPcqG8I/nofNwmyMK6e+nnC8OR1mAnJbpzl+447G/J54pbblCGsydZJCfCiHcC5fJRAbOdn+M3cNMVT1M9ysbU7B+EZZgHor7rM5wEWqiW2NlUUjP7p0AwKIF5r7uaX4bZGB4cHE/oT27NT9SZ/RtAkEY5ZCt5rqXkHKR/hN9hDy/N5hdW4YHbwro/xjM9MXWsKshYKnMHKfJqrQSkDHuLQqjWiZJ5K/lDLqevYz53bhXTMNAqXyzJ+vXmn8sh8njF9+6LtUcRgJ4fuG3+/RpVqxfCZBB3B/gTgKe8EG/t6DVgdyLnhdWfpwkPTlWLLvKUn57oDr1GqpHWV1x1dLLGVGN2L2u49WpcRPMhFq05nhcilN2wP0HNLTjWqnKn75AB70boApJrPGy45OdWd1MNVNHt3uFw+KbzOvYQJTjGksj6v8HgjnhhKCZ19PH5+Ir5OvSnpg0rIpZvnIVhCK2nCygHf0+89Kw1Jha3TNBE6lsNJbRWpVOHgK58hXK0QM0dgIRSq01yYeILZQwe5P6kfCU3FhVWeG2W/TniUWojs0V3yI4z3acIX1bWczYzW4bTq8CYNZTZxf8C5BPGWPKfEmgSp8xOOz9KjWUVqsuSvdKkqx0NEkYyEiqGf1TJzaKIWikXFnnB2rJOC7CSnoW+8kTwfpVe9oOLDG/CpKjNHdDBQkTwYm1K+YZRovZzjuJ7Ucy/WWI3Wm64BUAiVUvzlZ8X4g8lDLjau8QMzQEunwmQZNaEo8CZu8+aFPk/mhFdyU4m6QiNxPl9odVwoNkBBhzYVAhtT5JKMHDzQ97IeK/2+3oIHIuPEvuFY7hatehrYv1jcBKfJRYrxeQEX4ivUyymQZZ/PAK1OICywlAXryviWnmHnoSolcIE/IH2iZ7tDZnuqas96onp0eJ1beCAIGwBSHTtahxX6Q/2vSmi+onWah3VWjQxAtBOtL1ZmQhCHWCOTMo6RR9XxE3Wyi0Z5keLe4SLRScehpil3+oyfW8EsqM+ULkpCGiv/2ooYwlW/SLt+SIAs0eHGj8BtqyXfKCwczTf/dILMUwWujfT2u/lk10P0ScSn5Hk3Ni9FS00tiFWHt3pWO1iEjktyFi+KcCKEDq+bGsjAdmdPgzdiJCwfRVfP7uxrJ5G8Q86EJ2HBH+fZ/SeF0CsKxMByREWs+RGG7thcGrCXfORYxNCpqYbLdJCFn5rPW5S7anAa3DQYOnt+twJ+wFblXInsWNvid+eGzy9/HEUJAOCcsaL1qo2g9+HxJFtgxxR2u3S1IrjIYb34rDTFSTTvzws6Hyx/5DCfG11/L1Xi2uVilr31Guc4g8hTB1zuLqmTUt2LoodQTKdaHamD4SDghJFblat1f8YYpYM4R7DTKUPvk0Yx7ykRKbsA28B5lr7B+BVESuLcW1rlJ3+ku9jJQSXEjy3gmOtzo+s3jZWSAuBLiejkhzjT+0tmtrV2WcnL4dSZRMwanGGNXe3S1sPrREL0SD03Vfik0DplXbvWf5ufveIp7+Q4EFhZM82RBXuKkiYhCTA+08/tQkVx57pS97Y1DzMfcL9s2FM20LftCzk8C3iS2AfEAsjUkx5w9W7ynqhXgGWw01mKkDm0VoP7CnDMjvvOctaL3jPo02SjFf/IYGkHKf4i/GEGfXKPa0gtNtqjFIQxxCvvtLzJ0BLlsFXHAL3wmtj8AGuX4up8+TxUjqJN5iMs8nPG792bTSiTa+RZL63xiC43WU70GRDbC1U6tVqeGVkmZBYB333isIzYYiCoNVNTa4emdXB6d9BupNJBl91OnubLK6zVI+QjqaI8e5oHV95QXqFWWFr2Mk1EPUFCA9fGWBpnyCvRnNYEdMZbNm3EEzwZA4aIQdFPvK/xITMKBR74vx5F5ftcRaScMtNFLw8xzHvMldc5xzVJhBLAiUKwevSYDg6cGCyQhZXlzcWg9ZPIMsRHu5xovQz1jTMn4g/Ox9TqRZpk7Fo5qKq1Ed9npjDyAlcVTqAkLCKlnfCOMrMTgF4hcKyYOXo8l7uo6RI0GnHktKD5+GmVc1GhBTgoGqbDE08EyeHwmJpTIxlM06IaJ5O/L5wFcrVRksvqfJwUJJ9Ybsrk1sjyODGLviGVlEWxtgjwvA5Oln1UHWjkDs6eJ8v82FBwLBT1VOrjpFg5GVTQDmOHrvHpsD1K1FEI5IvrTPLJK58PcCUdmJoIwBWt1cGJ+LqHwvzb5/fG/kSSBCQJWhUlpiJy2RvMUBzfNVb/PsOi5kUz5ciJ36n15opo9bZNDaHlZa3PjZi/t5gG0kAV71HTPEU+u7jaj7J+o7GPPAT38rBfCpQdQCii+XI1UhJcTfCqdNMtOljxGgFVUDRbtsysnw7T0lRhUBzgvJx57+SYueisYhOJpATtXb6f4Ume0FPJPJU30yK9xRQbaD+pBkfai7d6xV5MPgTLQbM7J95giCSsb2pt1RlY1BMx8zekQAQUITtiVy+LzhQYfMQigbli9c8T7qZekB9AkkBmXv5KN5Op6giIU8I46QXX544EnFSEbZp8nNbK4+VaTw/mKGi900RGOjtZuAVk1NTTlXt48jOKJtEfAvPRbFYsNRGO5oC1me4sD5pDd6bBaJnHukY022pTA6hTEHBo/qGv5Y6iBX2ojCbSlQYYwMhGIHpVJdHzu2jbnlUTfUEXTfwhDIUd7Auol0gOoqNZRu0w57UWCCytpX07XEASkHv1XxblRtjR4SLx4LBBknE19M8wDY6rZGMHY7DHZ7p2MYZ6pUQ3wOTO82TGfH3zZMQh8tRske4MwzsYbKDSR/kM04PlmrgIuFhDfmlBI6sXOVWoMKClwdNYr0aOK5rSKIP6I5+RbovIEzel+pSS0OUe5ttomnU6Yd7N+mQEzJXaDRMPejVb02PRIk1uUt+rMpCcaPdKvE0zTfrNoM5dzL7aiFtS2jUktaPDrRe5NcRA4s4ljjw5WE7GKjl1Gz9RGuC73OrWJTtRBET81suqU7EOEG1/yUNq9CiRHPFwDVAMKD3gwvHVRb8gt+vZFvGi6UD+kV9HC0eVzxvMN9MuWQAe/5rmJ6oWwgYgPtESMvYEn8hS+Op75cQu8Qx18oapAYLryZmDTy6cDrxLK1iMl6E8PiIclUwE9W2CruCksukgRwCYTLCna+VFdugS0USKtzwIsc8wrCIet1ClCHD/uAlOYDcAkhG/wVsW2l6Kk6OiwWgLHdgJZ0Ukq6OuHpLozqMYL/vYCJUjoA9szKiUM7/EAcV4jEXSUwyjR2t3Eg1ILPCngvN9Ug+LMoEUINpGbLJ83jCjfu2bkZpCl+fGy6+slgO5tBbQjI/0ZHWRGqjzpPvEB7ozErvovOWOn9CPPFQOEyEPkPBkXePbwYuCvhXez5PYrs4Nl88foE3le6RErpzKUIojXx132dlK+boc9HBSGXWoaPHiU/btfKYp6A7xXiuhj1KTRQ83j8h3x3daqEzmpy+lq0Nm1ZSMWt5nY/BwORRAwGsLYerwz3kldYhhgAUKFm0/JXTqKKbelQRqoQPtE0I6paqTQqZMykrEFxsmxXXIRFUzUBNRa3RwzwtiDlIU3Hhxm6SS6o8yQMEPA8AifUjgiI9yB5DcNFt+i/FxVBICKf9ZZ42ZMsZEruXNSoJIitbhcSMsPM0gS5PkrqND2dbFkT0zaSdRTV2+HxOLcudrfCbakT5sV0FwDs1UieYSAU1yccmRfsqTP9CziYqCz4lFzxqhghIUxIs0mqpUWKOfTw/LyyAwtbXy8lM+w1wBmiInqitV3KeH+3hQkrr6U08SUZ6ujuZ+KEXG3Zw09+B6ByTHptTScekEe7CcJHWY4ABzjPN5ghewq2C+N7LUPAuRrY43Fooq2Q+n7s8LpqfUV8quaImaTwfj0ZmP5mUWGBDyCK4gHlqyHkDBU2vcGClSjguNYDwlDp6V38Gm3r+N1dyB+6n/YyUx5LFyMAtbK/5pxcMTX3r9og9sGUoS2kdLPzcvT6Vu3NEFqXkEXogb2BY+z/KU9Al2HS0yNye5/0GEenKi+qD01UKBqZG1fy7P+9+LcwGdDpJthdMwouTKvoILhhWpnycEeknrJW0NHUfzRW9tMuTwma2oEX1ygBzfk0ZIFoXjn9zFSqqDEpyQ++6ZoohvVfXLx695HUr1wM/rE9npZI1THggpcvS+u63GjD00TQg1Upfgtl6LgMwe8kvPWQYWvh3eIyn2cdOSKOLq4j7u0cHjE7hwFM4xrerw7XEuw+VU4w8yUEuofjsEjTL3nRgVU6kRXq/l7dIuDeeCfoUEH61nO6NDt6C1esZVVSyflzh+RYk4CVj1lZo9UCg6oEjSRS3tmIaImivXIQKuG2322+OqkuC1txZF79DZnPgEE7LMsxKUw4e2Po+4RqKmYWppdS9wczu8u7m9rn/QcnBZ+hOcxl0DkZC6TMoObF8Lg/ng2xa/NuZIMW6Y236RW/DniEagXtURre9xJwg0FAHU1w0Q3HZjaSYhG3qssX0rucxCv9VKBGKvYMvM6GCkEpBfEMB479DbeCdHzvfW1Ft0zyc/vrnpSXUgaF4IK570CHdMAxBcigo4dpPeLq/IIsNYlAA5b2qR1GjfBjJEWdesWPNV3A4OvRu33C+VVJ/c5e4U/KFHy18Tln/BEbdDsUq1MA/gmxrm17kd3s1+lPkYyrkXZZieYIUcCQJ1JToc8ZGW16thrIJ3Si6x1OyYNc4heYfnrcJ+m98DL48kPiNXS1EV3b7P6N3llFPWgkgQdBY+h8ruPn+UqMSnTK0n/BD33rk9DIIlzh5RxjDd69zR/Nq8A08RibSjqOIZ7dONNiYfn5aWRZvR410l2SXg4SpOQqLL8YobB8KdXzXhF6UwfaNdrwfeESIp5+VGb9HjJnoowdJ6w/v18whLhZ3qMjoa9ipP7nGDx2AkIYIoOOlXHuVyo08wU6Nr9cj0+21UFKR3AYdXZNZJg7QadwSqpsqFp+ch2A0LUu5R/hboKJ+0mg6SRGbg5QATlb/TimI90B8fEiA0ShLLdTerAsPgaJYLwDJabgezj1Uoq4WgxaRW9FgRXgUkIYdy73zqIpNcng5cVIGca+dN4eYOfhQiAe3NG/AJj6rpRZ37mJfrndXoYRltZJRVGIl3Sb9vnhDf4THGsWRZUrfHMg8caUNVFcfln/HG09cP/lQqui1NCGw1nR4PqJPnjuttUDN75ncUJw+B2msgjEkV8n0RDPAi5yFvB7buE2UE8OVRMgh45NoTE1CMau1NaoBf1d17t8dVmahpSrj8/QxfTY+mNxx3U1WqERNwpedU/DMfMDX3Okbn9MbjxZwsKO6TTtP9noVgBhi4HF7DFNwOZsIvCK81hLFrjO/Gk6j2J58PLgKlKpot6QhWQ9AAhHHP5/nbEy87nKZV+S7yHFUvh0LRiUXS3ncNbyowzkXFKw2ldrd2q3ZOcjqUBXgo3wJHt9VrLrO/SJ8EWHxiETyaLkv0nLdeDkU2fJsl+vZK4qaW5hqG7Lo9DIsLydSmtOI53w43wsFdrUWVO1UVfKVG5MgoNyPwq6UlcE70uC6EiWggH59g0ecRHkrW8hNNeahHSIZhQlB2q2pMeOBKj+s2ouqTqj5wBmNSjjzbXhoQfBNZ37ozPz2qBe4PsXclBSox26lKGjVqqaFx5vcVZmrt1/ivXl3mti/DIpKJX5mQ00ueCa82MEGm4qwlBhnNl14FbkjBlWgZpXRsnAUebxFFSh4QgXHtOg88iW2HZF8cBTXtey93zkdozQBl9Pl0cA1tapobEraN5zMKyziSuVYIAtdmkvSROa6UnORsd82vzq+5/pKhLGld6eZ37mC+7w0uCrKOpt5EPx4z7f4BbImLos0kyZ1THpsHt5TyTNT8Je73EX11KqJ+vfH72/wuuJZtVU1HyeBTu0lJkKVDqQ9Wz/NgdTZ6UyqeiX29Yl/PtPEnSRQY598R1mAN19ztMzTTPb3jhmqa+uc0ilCNfOV28CKJZEDIKGlYybZLLO4ImgUXZOkx0a+gwzGu6dvzUXeFvWB5GV34PGSt8becJCk9xxxKIJghNvHazwOuabne+jmwPFrM/HbQhWhqE8imF6d2LZ/26+YoeJPEMAWG2aL1ytEBQhgEBnVpXkay2+ENwpAuKTpDUZ/48nX2JPOmie7Kl1Z72u+WIS6PVnQJ4ebV8gQ4BlNZCo7qFifPgG1E8iEWsDPoX+obGbg9Xg2sQSzDVieMnGy7CJgPCFnIXcYKjyG8lzaV1tEkO9Z7eroBONBFMOzOawPH060egWY6Tq0EYlmnt4Nd2ITQ8YI2BEyepLsPqVDJNj0UAxcVcEcHt3qIycOE8mit31gIy0SEflHzpfubjnlbXyCmbC8Ki3UqY41o9fBMV2rBDmqs9vx0y06juJl4fyBUImRop9VSw3HnN3KNOKp7RmuQ2pOwDbChWebZ7XHpIJAFS6uyn9k/HaZBN7A5SYSs7n29PWyVNVb2ZhGvnZ/hfkl8dWIsEFRNis12uUl9WxLHyNU4Jb/EnO3gZSkgAAH4aZ8ezmZMaSFObfcD52HyTbnSoyyD04hcbgdzaSGsKsUcVPiv6HAF5wI+uV9W5SRSoso5BREhXcAZrSSX3sOpPcRxq3WVt5ZueWIijL+L3PUKh5eYqDvPlBEhUfAQ2hJQai3PtekMSt99NIUOOzI/YgYcFN5SLsLyfHpYmFwzOTCNWkzUJfeoWgsB7Nl5kuSMbHAtOq3wjbemhA3RqdpZbaD11I6tM22pE2RLVCEeWhGvZ3MhouSAVeF3oQjlTtb8SaWEiUtCPCVPq+mOSZXORXuhvJkYoZBD+qIfk9NtvqoJpk+tn5FefCsgGhALBHLTG7xMAcXmgDwuYkSxJ46Ta7JflAH60ZpLMVvmw0SHBKx4YL7KQzBlt2suctWU5P15gnMZ6+kjXk0MIT9iXeMLDr43Q27XPJnm4SInHO8h5kfzVq+uobqZnE9x4uzPNHmgSKQYPhGS89cJQXaCCKTrZS5z6ZSKt4PRAcNtTfIPNnbMtAWagDZTTgWGrP7ZVJ5yRsaGBssp6xkn2Fnbua0aqbgDKrI8BncXAFQ+SquoCvedCo+Ww6aoCdkUPmrdWy2/tr6MxjobJ1ovwgUHIDxolC4+setzPfRHSwPI3T5Okg85VD40YAdG/2npFQauQPHjZMmxsvsiUsLFMIRSXqt09xEfZ1a2mIYihSfsXnX4NkmBcrQ+qlKjg5/66WEECWTWUtiUkxOtXry2AmggYRQd90k9bC8/W4l7K4Ua0+PXH+fa2lBKY5b5JogQedMCJuiHMx+3N0R+yeq21nTW8mV5hpulGFdMDWL5sATd5mAFXhDNNEIjPY/AQy9oVVASUCx49GjtTqOltJpD8xs+v79ocQgNZYIL+bA1t5tfrKE6kTuG5IrmY1WzAMahMjw1P94kVqcyEZwi7MS45yIwztwUMptkDSD390NgaeQERLp6ksnWS1fAh8N9cOLJVdv1+fSYhjjF2UTsxZPobgcniUBTILahpc7yI7ZnL4N/Abh2vh0MCUTQF8WHZCFvNRjQUkIA/nc9I0+EUbB3WH3FNuUmXnkeavDZKJabCHxNv7+JFRgOUAJXqOPyUnrFadKUAGvh9ZrRbBWiMCWB3cg44+M8sYIqHWR9trmSwykY2PH0wA91qJsaMrkE3S9hcy38hMlaotngDfLDqrGpMdKP771Ftir4IrLUVrQuhy3DFCzeg9P7d3R39fh0UgIUpxE7NYqei8cUWABlOPQLt/eIEKKcAeq5HnX7f7oYykPBtk016R7vMHQlbOhgzV8whMszrw9c0ChJzwGpn34+vXADWlZ/tHZN/ghj32T7ybUGNUQP/0oOh+OJotxHAT2QJ+rmbihLoXKEAwyOVlOcDyWSuY5epv4RPZoVqIAKTsCMrfSZx2jbWHJKYAHAtbiNdvb2uNgGGMDgOlX+vs8jDBeNqTpBNov4/0yEp25okBHxz64NDTwi4tgHzKRK4JOHYUWyiL8BLAAMYupcSdng1O85L7jpaWbtlMu2fgmL0SFQIaYmD97WC4xuTWE3ZDdoYuJtvVoz8lY0HCp3+nkriaidOtKK1hNf2LvQJRU85z5kKwyO1Iwfu+OoA6niTKhYLtGheS3rBbQBWoiTHt8jVl3UIiXj7c5eybHwg3dcSXU1ZHxSj31lMsT6lcI2fcXkOjsHJtKAI2xrWYjtPawohrLdLgpPNEu0uh3erVy1NqlIO3ZL+rnpDhg9oEOxLWqeYYdlgJnQLHklIM5f6YUvyYwh7C7njS7pNddTT0psVRDs9MS/28O8x+oz5SJezvBxexwrT9a1iqkWNm8xly58MSU7KikuFPMvl8y1rlc9bk+g9CWam9Nzg/+kqHDtqbkHJwYhc2Wj3DFXUT1D2XaVauTeTSWVZn80F4JsrWemoVmAsAPxeavK1PxsQ4RSaItIaVOCwNzhPl4uVbLBSCA6Bua+Pe47lIGZaC6kdt5qtVFw8IGUnFryO73AKYWxQdGiylutMj3C7ImjqTPAuSWiGs2W+8M5Vkcr0cE4cJFFDlCZKqZaK+XEfvcUcArwgtAbcMClMbTEp78IjImArrU+nx5GQDsh6ueKU2t+RYceTNe7akZ2P/MzCquGddSTKsbjdM9GySTrS1GKrCgI1sdlUxQ9x22hMJpdnTno7eGswqSEaIR8veC322zMaWD34Mss0OF/HmCHm0RYyifgcUzNwykWKQTbtSJVN2u+pMA4CkGDBYpM1ABylFTxvGg1mqVZmO7LKjk4/oBfIGW3AI//vsYvKsUYywWj5JX3Ri0pRRxo6cErBnyq5Y91ADnAVbhmnhdGHwNxDzlMkLW9KXjjMxCHVoJIBmy/tUpZfs00ImflGBjwfH0+1xN5cJhp0aj10ou/zVYnteqiQZmnTub0AHf2VDzswC52t4px9OgJD7yR1g9JEStaq5XmeLRMMMEjo1e5PaZVQRJFkaxTnAyfFziUTm4EzYAhepPmoZswY6XA5FUITPanw3F0NtoFeV+lfXp43qRokHrMlVMpD9RzdWQ54KomxLtjmMWK2asvGFlRrMDJ7TCsaBVh/K3PqE/+UktQUzpYLnjpMKP1Oi+IG+PtRaPceYBWeK9hjJFWiaoWMrMnzo0BpZ6YZezgaK7OVU9UA1b857PUlpr24IPSajLFSkrcDqYOi0GknHLKmPMZgoegqaWwNWsyYmzlhslfJQLMXXvJET8LYbX3cNFCQz37W3vLOziHC+HYQ4FBYMNJ7A7fdfXRYmgH/tgVrV6jhCwlOAxAoXizxQlJBBcNA//myx4bPQxUolAGZTZ6yw/N6PLONgnjB3TLgosj9ktKOidSVzSBDC7fE8O8iIxCGXny9Gb/tF7LgztnAU4cb85kdDCGEwAdB9TITI12YgDQFsQpGSyxG0bikYQzrynNwzjR7D7Dphtdgdfz84CbF0JJYYG0UTdAMx3jE6zEeYVRCQbJk4XocALBovUZZaFEVatJJbeUc0x4MADYVqd+JsHD42BsiY/M/Rab8h4WoqEENBhW1VRiL2mEHEg1AP5GCAbm8uXQtnKD5MahQCZTUX9J/Tykebk4SmviL+4e/yg3Sn5RXxxQXEN1nk+HZSXANzGMuuJ+jfB4ha1lw4eh11L+ufGqPBSaJLxyRnxBcaAr/viX+H/mn3v67oGOl3oaIy6CCHtPra2i7O56ZmKEVoxSqVka5r4Y5Sear/WFkwIAaRmvuR4dtiXOivYBSlXUh5FHeGMvFFZiu8CKN0ZsNy+Ajk2AW1TL8n0W6QrArXSYCwT+nOfzBDPCOkYB5gOe8mgeNx8U2hpyFPAHhP6Sqp+DFKHEE1jc/ny+wuLmlTQAcb5ATbryKK0gpdxAsEcVktdtmpaD2RaFm0hKU/34uCUZGecDOgpcatAwzzgSUf0ct1VT7pO50hsiTRM2QHn0CCdvSaXPd1HcHjBMzaJOHXbwPHSy0bFG82XpKeeDbBAN8ndgjE8Mw1iMRGRC9A49ySnpI643Xh20arMeBSav6OBlgWQGC+THKECxZT3lnPzHB0JJmKw+gzRmDxE7pDnj7Z7l84TjTs6h3B4wNMbv7UqHKKyRUFaVUDc+wkpIk7s0Xv8MQP0RHYxJrEKYj1xo2SMSQXQNqlRqSTUtR5AGcQ+mZnEr7zj4uWg2CBLOaMxJAnE9T6RV0yVeQqmujq7X8xuuz1qeS6oWNvmOhTQtldFjcJPvYK3bNMz1VuY4yjkyYop34vNgGoBGA/6N5gtUJeKjvv6tPosZHZwwUeyzrWEXCpp8ulxtQssNboKVinYp0cGgR6CryYUgcps7GBuxaJXY23Jyn5ks7u1VL8ijIiTQqGT3ecK1SeREDZityJ15Ph2a1brtoKdhAvzs1qBWJwOAXG9iTO6SLTeI/m4FhbhTHB5wXe7g9aPFdJoKjnJ7YwfwmK2krCuhQUf0nGSXo8whfZySJ+HK37c2t7jHgKSNMMw8ek5eN1m5RxPFQ7BEsXN1hJNH+VbrTh28IvCG1W7BkF0/s2QqRaNwwwO9CfFQ3+7b9itGqHShV90xB81oFIkLaMRYy6LaRx4X0E1zwGCDVFpTH4FnmFOPmTjjgENt5yc4LgYEPnzFtbuX02udTyqWYktRibDFHByDNhH3WlQ5xPnV8vu3ld/WcwzPbz+fB1xTBSoCah2ynXfuYEkhXcMyCwbFMuMiTJXO8SKjClDoLM+ScxFXrVWKt7g78LGksHmFUgmzWPOs8jSawoFbvzBDA6smdzDaJY1eQHtA0oA3G6AYHO0amqDFmY0RGEwOlkfym5RvI0STh7wf8jiWFmwT6ZyalxF4b5jeKMrZW/4CKywEphr+iKrFjtMsGTsXp42qdlMp6bzZiDyGQt9hg8SNaQNM2eOyzbUaTCdtYZ/cxdJ3RKDAgghtVHZxRaHyAjgMO2ETMfJ5jrg4KtNW3lIKjPpSRgY56AfevjQM+BnEMDwJfkj8Psrsb/egk6WTVojPX9ZRzPt/9bBCgzhUxUsGB1W8wVkwmtaBogqVVviy2cxZ5Ar/Jm5a14xrIAXHZbZJvaO+tea5x1yZfGpHmQHJgklu0xQfJ1NgFdVJlAEmTUaULK/gaKnF1p7xGakhJQ6FxodmYOQHHKuWig5K5dyZTMvIAVenM4GKqsXj/AXB7TuAOGGgvtpyfsQ9GxCUImdlB68wLyONXK71jR2AkzlPd7Cuw7CqJJOrR6i7pGrlWvm54gROrz9etRm4V3uBCunp7u/shJY7tnVNvt3itL5DQ69U6EHg59cbieskSQY8GsUUYqFKImKFu4m0wRrQn5KrlIveAUAJRIKzAd0e1+iDjJIi5JzPzzzKxj+/szQPZ8F7QJA5jNOUR44TE1yNQM2tLMbbwdyd3InKbP2WAY0PuYKuwLaq+bhztv15gnk7kR/UJwFKnnyZESzHB/lmRb3U0vkh5l1iq+BIp6x5ar72q3LTEEOVBf3MhOmRCGEy5Y9SvMcYomQ5/g6y39ZUjs8aHdxLiG6yycFQzqASPa5VQdlNrRT8tPXtML2iuLhcSPDr1FZwaRehc8VAiheNaag9mq34FoVnQehAzZlfcEyaihVdVEC0J3+lua/wK4l8eUgvS62WOUxtWdIZxM8QE+A06ez7oThLLd9wooe5OWFFbkrttuPbjItItjtE07B+x8gdTkwknIwH/cI8eQ6wpDx0ISz0ZsDHAM3IB2iL6gbp0pPH55GlopWxNK00xmdXNig96jPDh9Y+PzejUPRsCJlQb3r59FhSN4QSNpSR0pMgllE6cE4trIX0II5ZSyO1+TuDpxrJIR4RgnvebEUv2ssqQabgjhU0DRPbm0gy1S5Nv6ufquRLw174CXSfv3uw5qrkcBhoOR1NpLnKTb2x8ps6vTTxmUhhcW9IvQHzv0YFAhMI4JLX31w/CeBUWCH5FvJOY9e7XUwXro/eyBS7XGaC1xQ2by+BGJbLNSlqjpmLTGiqE8BU3D+/d8SdpoCrmjlnNJuyz/wvFJgzDIVab8j8RnHxILAEmxjb3RD1EzefGm4iozRiKPXGzf8aR8ZQ+Ofu8XvTK8TqRaUmQ1yWPJo77kdpJEIjW5K0P/c+1hQ11yR8sclkLUGjRrPH1QCXwMzZTxrb8uImlMp4uRJ6NHvFUrYq2NXeXCLWXPB7NI0YgAXS6iIzelzcBOZeLXqq8jZwkaagQVxSlMCq+QkBBJrQ8wD523G/1JtmbhXoWaMKw71D5WtOFCcfl3QqdeiuaL72RNdKWUT7QQakUV7ZVpQ+bUPAI18crRd1AB4R/v6OeZjOnMfMVc0gwRyut88LZCOcHxZRJ/NwIDd2SysdYCCiLhpGhT+nfp7RjMgIZnxsw2klQW4HFw4HNFrHejt5QzsaqGh1V3hYRWVIDzAXwOACpZ6Nl2ejQ5Qml6YJk67sxmoUYbdHNQ5F5DtkUI8vhIbMm7ZWZXA7GhdJ05Bi5jrFXNJPMB7UXJZcNJ6lxFrkNESrbOr5G5jnVNeCj+pfL7BUAFxz8hZoozj13Xv4JQtXFKVZpsJQfRabe3RI6Vtg6MkYDTHdPKVBUw+1PPyZ69PhupMhI1hEsWSo5Sbw1BQxp7z2gSCQhXpGmga7cQlGQr+Kj++ZeSlKVCQGAqLJZO66qpdP3bxG75ZU0pRo9rj/1OIuYvTsGTNprH9d665gh5eRr6KIlOMbGzC1AWxKDzB9Q4QmXHxrv4igNEArmTbBolIabs/66XBkQ+E/xX24GKCYfp/1tgsXhqXJUq/iun79xMklsqCsxiCU7Rs8SF70TGMUEtKMzdDDZ07tYIWWtdhNPZWHUl4BbMuz04YOxvX25mRgvJLz7rulR0ySbAzgW+q6ePJDoqCZfOXQJ/Sehxl8ldieFHXGZft8XtOjrIs4XhragW/JnmivRMIS7y/q18jvMKutE6MngFp9v0Q1cqWnEA0PXFRvnxH4bdpgOBpEN1a+b7vXdmykbMHQSOXQz0x4DiTXNayepI808xfURJvONUAMReTHowGE6HDT5+rUouJFSwEWP1uWMo5tCn0/ltfNaKo5XZzP3KQbwMJjEa8agXClTxv4AWXZ4a277cOR5MogSUVN0SRntFqRggMGfsGittaI5mPXnUhZom5LwSHFOxQrSw20eZH3e77tt84CfpJNCF40xOnTMxxxoTPMftMw0tXlaySKK3S3wHarYPxo9dKvAFOUPXnupOd6BJyKqYhhLu3n+QzRQoYUlKlUh9N6SzFHRuaL0gL5DsVS4gtufiMzgzEB/qr1aL3occLalbqxL9tXfMAVbETvJ5QiDfb3lWbIULdaLqsANujPyeN/ndXifaHO02ALdrw10W63HOB2UTtIiVFyaO9hJFRQyuCMJsmwxnm16HeDKAr8EVyANaTzDB7f1009SQvp69Oj3mIyTZNwX/p3/wgrG96IvQMNg5lhzWg1wMgb1VHl8nhOXb2h7etmhakLgsVy0uOtGjWh/UmWpRYtOd7h3ceiykGORD5vzZM4vdqJnD7Km6JYkXwUbzDkD/f3GBqX91ThGiXDyf0kKarPN20mPsCuabimqfOIS/9Z+Q23uK8WsZkUo57ub6uJLV0hzxj0uOTjC+4NTXLqBDm0OYup+T2I/JEGLHalZI0O7d0DjYJ4mt2vfuxof3EopMJojWZY1WZuv6mX2KLQuYugQJuJRX5vaJFeIEFgrRRd5ckPuGuIzU8xjvL6vKPDTReHpaFqTAgLy9sj6K0QGJgaX7JjX2WrKy5ihpi/WlnDYgE1hbyvClbU55hajbESziW0TVF1shLiIe9ORVMYYqjpMkPURMi7kh8g3n7VOmceorMPAREhgkVBi55fUsLtutWUxcmVtuJKIDaw8Vsp+EbW7penREBg/KZUagw9RupQzYqrj4A1tn80X6EKOZFcLTDSpEbjaaxa6Pooxu7JX2k18OClQ+RpBYc8PnezQ5MP+SDemvR7izaArwDuMmHdyb/3EtMNvX9ScaStPI0GqxxalXHRq7fPGJchLMhzxr5Y2bxYgeNQyl1C7kURnmklwsXzUI1kKj4y2aM7vOwkEtebjBVv8dA3LiowOzKaMeeng6XbcYPuF0OxkgkRCeTkahwl+ADpEM2XpIn7jRAd3rjvG65ujXK/tpbJWefzAlvwlyAUIFo5T+5RIo9JPoN6EjgBovmWqsJ5QyUg8kbSj2vUPKVSLaHGmfez86PDHiCTRBwDCqbPCGy9oQUj+PQoudCODsZwh9dQDjmXac/T4HQzXHCbulJ19vbpYbAdOY4qA+AWSXbONsfkmzkPclGBeWmYNajuRAZThuG0svJLzFSipJtW3RIhA6vEiB62+UkOAXIo1mlJY7DoN8p7wXU7SnajbE+f1ATf/pa9WHm6PS1NRUuDyGT0kkfp9fNIxJ+UH9YCyv6SCIEXrWCAko/HP96iIfC/5UcRe5zjYo3JpdrPrc58uxgbHuE86uWO0tLe9Tg4cVny+7h33WSzIDjVkTHL0T2edj4/d0ppUcqG4kZm1oA9DC7Dr7r3J0cwf6dnSS6gpmBMe7jeUq1wdr/YUrI56/h8whXFSt0zANgAS0jNRr3boPMjh6OemafRdyV09xpSVIijiynnSq9aHRaI5HqyuXaiLCQELEq+U0//dLAjipVBmRWgWuvJnxHk2eK4EvuWpN9RPw/xkqQbBjHmarXPZHtmMNJciUI+TsSTiJDknFPnAL6L8nnJiWK3jbAiMtlbfWMjyJRWiny9t/klSb+uFE315ztUDs3okYgToCbD+Z9arSQbNUPwsa63qMBttex5Uk2gMFHmKxt7hMjBRm3FkvWTvEnBj67p2losh4Sa59PDcnbAfw/1VO8eJm9KHwdoe7TU1ZufFcMIymkotRmFJg7kHmZ7c+4J0jxv1fDbaveRGO7w1pb+1kMr0cO0j62cL0on3WIarwQDfHrec//sz0RZ6T3En5xZuPZW+vmtdMPw0IwWZeFWev0NriDTmtaguElVNeLimBqalliU3c3Oe+SOH61KLRo6VcCbB1UiKg7Id6uLub+B9RM9Xj1Va85gtWG/bx9fxFwAGABPIuCard7EjQ5hDJXxRriqbhXxrWyzZGqS2S1fkLxhOTZO/VO2wtby8OkVVuCUnNKiN+Hp2y+7Tylx2KHwprWaJqpYfYsJ/XOHWunsNAslIKZE4AgY15k2c2SP64uXUt0pCUp+iSUga9UmrrGnxysCzXHekiW4m1v+SM+8xXeDM7wPRRz36NEMdDI1n1OABuN8ltMw8FTqgua4zZbjFiku3pSou2qedz+fcRivIM4wuXRR5FrMxAVXUscRLwZpHWWkIZhcg3IG9UxR1SHBIyw+leRIXAikh3w7VGckRadg+yvrZ+pxEcNqlxVQeV7a4HZw3geJUmmWPJTQ0WzL2eAjRHFfLT3dd7T4cCgyQZJ2j2ajfNA8KI1C1emtpkLieCB2t1mEUFhK4hiWZdRqa6Uoc0eMPm5qZe3RiqK9fp5h9CUVwUaqVqIvqTmXXBu1sj1Owc9bjL2DxNoXoD+dMqumAuLQIDWibPuWhB/Ro3gpsIe4haokMVVXCUV7g44f9MH+DtPvajCkBXc6N100my4NZvoyHqa3r6h3pDrH0Tqrn0/YDnB63jIaoG5P3kxG9q+FswgnNM7gSe/xDCBUL/JvwVUbi3xtiSEdr6my1MMr6qK2fcLkm+h3g+x9BzNsS+nklXAi2UC4kNrnGaZQUzqK8gWoYN+3HKdRAOzO/4nnWxQJ8BBnSwzZSHduOUJOSBPWE+qanZFfYGQdpPfJh4iuSoL4XdKWaNaVCLiicwMi+va45K1UI3w0gUMZwNJAl6EA8XAXdCsAna8sbLm++FZg72RnOIC53TD5JXyirAjEoM0qlL8dnK+jKuvJYGvGejpKvPBmEXQyHfHwZiTjhL+BEWilm5uy1VK+tph/WqETAeeR03bztV/1D05kTTVqb1yi5XRtqn9qoHsmUd8ujfqtCIShKQrAgAPs6trtRsrPT6Q3lCQw15Ds5CS/7UbKr5KpiUoUkaBSqU9SdfoXyjJtK3XnrX5zH82NAxJ7agzRgJgTJiq206ruYGqptnjVEN9UXn6rg3o7OLtlVaqIgyY8o9nxbGTuwZ8jtttnlu3ehnlANxk05SXPo5EMTOJ1VJdZCmrd0aHYQjVK2zSYPz5fYUKOjPum0ZHjJdNuDzdI8B6pFXihAO0TI4fj6iiM9K070KOLlw4ACETu2qN8djFVXswH2rypOuO2MUZ18fFokfqOo61HqwdVKV1Det3VLKIHdOuaZ1WV6Rzmspb2UvClq7dUrCrAIxE5bTlKrsy2j3Kaqxs+DcSktUpqcHVz9CxoI1YO6hXXJ9Uw5voMtjjyn/gAgDdIaK/t1DJtOhzai7JkIvhbjebu/jalv68qRtKSerD8IQcQYAfneH57mAqyH01MwsW6UvPyQDPxPq0i0D6fYbevUmOIDUrAKCbTkGmEJNF7Sb9b0VqNt0rJrUi+mDGHRuECnTxlXSk12PJKmR55sP3g6oQL7rOWfvXCOo03RcOW0ewqlNLwdCXsTL8+XlIO20Xru52aP96yHuBCBaSqrqk8ACNvKVoSBDbWJ8sOLztOceYOXZRErZ4drV7OlZJSCm3u4UlsKZX8dV2r9AC98emxPNlH5bS6+eIrgiR9MMlaHiWq+94eUTWpadpt0X0dX+ph9PoSLQzFvPfPW0yhJJeUXEzcAfPTw5I9Yb8+WjVhlc87DPdbkQ4kcwRHb8u1x9EpuMnYc+X7DrfmD4h8Kn09zkfeciQd5QJCncal9eRnWGipQs+l3rp5U7da4kwnmxQLiwQyjWSv6DG8UjzE7htmIXditxtGvxBomMIOWX7ls2bmjSd2RHAQF1As+RWzRNjxHSsxvA1wGMocoKeikbpGEx7fdyPqjMKoPlG/Ts2KgXOm49WBNR2SR4dHt1yAvKETdLIkpprD8Qi/l1tVMBSuwJ1ui5RRLta2Ap+HetI+DwlwMmABgNSR69cybXqFOI5EZ0zJaPXsfSoDaErO2e3z+yVAGcq1Hr1TKYOxS7pURoJDYjnAsAETXzQfr8kMzzhA3zP6ye8wqxo/O6Uxye+aJ39n0P7CsaqEB3OPT4/uISI6TNIavxMeQSBO9+b6I+b5xM64266R94JZTc7uZ9mDW6M2JZAhsF5yD1NJJfdyV03UwKlz7ZSWcsupQUcGvjpy7WxMRw1hTnbF2LZ5otVActiTUCHM1tOdMH3nFgVNEkWqbyX02+wlFUliK0N5vdKvHfcpWg5OOAoen8/zfa21pNlRjpzUbFYaMXFlH1GyFp9i50rHh09pn0WI+TkhHWZc+5Nbc5BFW1v9PsQ9KJvMRsBCT08KyPQsXeA1KEKgQHb+EANuUiSYfEaS0z8z6WQIVcvWK/HMEysRuUGiD8MPBuwwax8RgufGAHopfqveUrOlomn4GTIj2XPxfvNZwsgpW6FonYBodYsZowHHC/Qm0XyM1V6MR6q6th6hyJYSxkdViiPKa0a0pSWydCoxgoodaCnPp0O3GJvamRh2PvwVGxGP6gCAVyNG0HL8HEW8LeV9HyfdAiu2IwTaYMoIDY/cw1JoGwWoCNE9K9/tywGXHcD7UPoWx4K3HD7HRkZrxxIu/fOOdvUHEuup4fdOVHqH+wzwjYPytTouLROma4WYAdjv7PZ9g/FyHZiqYUVUM9k3fKSMF7K1RVfTKrefDzU9lALDTRMVUi5wyzH0TqaZOuWoHpvf4ibOhD3txWQEbLulOuMdVk5c2VqgPu6sFUEb2Xr4cjYe0vMZh+NPAQ7xlH7501viXqd83YK0TlR+vArRwXXKxtEipgOhgX+Gx9AxZQkRQ0xYn3Qyd6boopImkqxk/WI7Daa4PQs8TJrIGF/hKeSDMiJDyQ3DtdcygzowA9ngAjZEkH3eYQFkYAvUlKcGzIrmu+ZKdDBRTQ8gJRdyEUWXd1CrAw3j9PEZhakQb1lXrV+7/S7akdqDWbM1PxLWyjRVZtzjg4U2D8/cibm+YhSn/KPFzfT2jw3hcXQyycgsPkRg+reHgT+pT0OYHY90nqhwy081beWUtV0+PUyBQHmRXcdBmzO/xBWIqkxqlEgoMU2y84ksA6YDaf+gYScdx3PIQbBCNYXN+3xHYIBjLW2rkRznLW0piP7WtJCFWDOy/VsOosNiTEIr8de5P6tpUXSSlyeMCYfq8vGQiKJT55FqogvWxxnN3UizuP2VA6wnn95xsV3VoVVgJ8TNmXvcFd/nTQWjJHCN1hVZLYDHtkIgYyE8kbwQysKWaz3arrQuANcXdsUc/vUncB9yoyiFd4dgI+lWEVzHCQW+E9LOUvIEubAW8YFxAuXX85xPl+EkjVotS0zCWno0W3GIZ2mpONlH5TOHbmPJ4pDu39UR5M1uYMGrU6khKZJu5CkKdL0WMu6QiIyRh2jZmXJxgj4pGM8zZGCUIie8dPTOWC3vpYiuk88xkNIFF8NnIszIklsHfOWj1Wk+HbaTi0HUAVh/77saL2+613RCDZiohNW/NAXQ8ZVBAlQ5YMuHmQPoOBlUwly8dEsBdGocYZ1Q0y4pCG8M/UYuKgUe8auVsqJ5ehFyrhFY3i43bLvxc4tANUq+TC3oEVdJLjL+wNYiTmiyANL7jWCJgguyX06ryW/wyTF/wJJXYMEjxSQSgbqeWcVjWWnAlsPnRDMHrgvSyfb3CSMAtWB9wTIoR9uMLrEdYGgnTP5yMcZi3e2gBYzE3USJnBNT2bxgPAFHqndljTvVGBcIBIYP8WG71d8wukGIqhYh30ak23JyuZbb5sRx8e4YXVS/lb+mjJ1oMDt5yYuHZSDXx9leaooNt1RgnFL2sPLw/planR92a4oCsLARCu2NohtXZdPse+qxndzF97uShxYolp4V7zDERwWoCd5lH9+sUVscP1WDOY5wyefpF7n3aNIifux20hKkEHrDIwjeVv3Iucdy+5Fqnoja3aLZkEH1pemUc+/CPxcXJ8V3TMUTYCGbXErxc+Q3LEyLoO6TV8GT1fpS5G7z8xgp5UqAApZTWeQ/v/bykFXr6sj9t3r5rIHlqi0KismBBSs28xw4JIiy5GThK5YzbyW/qkld4MSJ3rLzeQoqYGpJFOiPXnz0jg5+EQ0obdbLyBDNluK02SVQ7ny/I0XPN+WoSLiV6zI9wH2/yqRFUt7MEb4bQi8/XGsQA2E4iIsp1J5S40IGiIqprYFbn4kIpJNQrvyaUHetz1vCjU/2DypN/fh/UiidBEKqeVILt8eneP2LpQm9MILOWfJkOhYTMhUypCn4lJq9VC/GXYXE9WTD5o2itx9sheSTDNIXZzNoYctB9EczAbCQ1sohjUTLDveFyHIIN1uKpeUS44rRYfcjayxY324w3QQxMOqDB3Qlx8IbUX/3eCMrjvKlXbk+0kO28Qbix1LW8OczYaaN4pQAQkwwTSe83zrjRpAoooQaU1dZ7jeKfmXEBMkDM0p9D2nPIXTxJWppmUruq7lWek40p94HqPamGt2nhzlwoQ6E2Klc30u/4XMTxSRCarE3N756iqETDR1aj61rpbd4hCeZw6XHpgLyFN9gegXe26W4/ea1b3rmVS9vyFgN9hat7lWlNgEuNir7fX7/0i1BNiyLSDWOs1oenyWCLQpCUWILJSyab3L0huZoKfZjWAJOzwXGCbYueMMgkssT8IpZpcQBtoGivPMArSYV7rmOY7q359tBBZSEdEi7xrY80IamdqN2xBgCqjupARvNlt5BNBMuq07wOP3+ytgK9Qi8WRO9Y+QO5eayDc01Row/x/ZwdYUCOGCl+NBS1vD3RPdExt6AFHBENKzdo/nFo2FjiFFLajj+6xLtqk9QVkgCg3inoKh8RWOPEuliPJDLjPbH9z9pgG8CjKLoSXE9t9BGT8XFFfOnBUrEt157erulTGgZC1RGUg1jB0QFCWqbk2YGbjJe7vdw19wvuLmjMGaPpHEK8BHj3hhUNb3eAjSUhtNaKNeJ3W8gXDcX5XiPJiBpply0W+IqhSnERwRM2AEsb48X0oCLn2xzuSO1w223UDn1NEG1d+Udjs2R6oo/XdNjoVYdLZqHsXyxPFQII2M9mg3QBENXxaaozgjSU5BcK9Bsklp6qUmANSNsqVqSClN/3XpCPdLAWRUseTldbND0a79V5XwSkSE1qHqsv9/g+JXQ4uMmqknR8U+HbrR9Cp5u0Eb5+fPQ+CQRCJ8oYZPx+f27PXEiiItBrUjLgOuZMl057PGLQnP75Dlw04ZZ2PiPu5aNeWKineZCoOxyhjTMvp84hZ5KXonuH4h3NBk8jdOILjZ5RbDx1qbKQXSYlkJFuU+tWD6wj2IunHMNHxgivQNQzY+wnFFZaZnnpakiV3voN1T+8vNAroohTTaWP8BywckxAX1DbbyVFqv7hQs1AjWwihaBisn0QDluCzkVXdOCd7Retk1NGzqUkZePqNF8kxLA9lL1c0Dqkd9frP4VCi0aYwNtkDtccO+kQBUctWilTxqBByKx7A7wWwgzonk46xyUBKL8AGb0GeyeD0m9n6M0t7Olz3/vy6phTDgXOtk2J73+EiR1duobt5VNmX5/5SmFyIFiUVjhdG82cbg0AU2rg+zTQ5x6ofCqljpIrnajHf3GvF9UMFhQlJEWRd76DXlfTCA5HxxakY7pKFjIW9Mlm2bVKkFQaj834RJ2SC4anKTpC5ujGPDIL5yZ2317PfGf42yq8BFjyKZdOFL4rz8vPSPupWjeVtDzqLekMVGmu/bIH4dRRrx6pMhNVbO93czfRu1SvG+SN7HTNh8JdkuugOAKCmwjeZAW+wMXAwpMj8zJ3+kua/I9xwse3PXTw6Hkcvlg3q1V6/ct7r1vpIZU1NDzeYtdwLhJIH8db82v1MFkmyZK96FI8RF7fjgmTYsTYDNUze1ME2quH4AYMCV1KlbVPGHh/ZmUwCbRdoZ11XNGOBE2TbIdVPGLZrOdcBmQRlZI+o7mY+HqAY/IxiKIAbolDNYdqmRY7/bn9RbvZqlFTxVdazu4r2cadBw30j5AAZQSZyNo0CHTgywEiGO6aiLs/VBhRMnMkzYdYW/y6ZsywUFSGM2G8lIFrqEQP+fkIboXEhAj234k8atB7fMjEaso/6mS5zjfXs9BbaXokdkH/Zd3/oySoOgDW3lLexqA11BoxJLBBim86KRXWEh4gtB+NGq+Z7pMvQy4Emi/5Xw1VdC3ZA5rU54ADM/pZ37mwg1h2B3xmW6tjHhcuwxKdDhKwd4TlHyevKLO/Ifdo+VNRY2Igbp6qeXcJ1kKPf04mFG4zDqosTE+Y9yGvCcFlPRw5dz06fZi4np2CSc1HDTRau5GWDjgcYWyvMfpXqlU0wRqgjwP9H+/8fHr1JAJ7EAY8KqmqYwgOWy3ys5eKAXw7WKx4QkeQtzH482ySCMxU34TP6emxSzLW0vUxWBfQHuydl4Lj5Frzb1GvkRRiE3uYRkCpBfhhR6jz88w3R6uyotOrdHle3NFGR8oyReAlzPTj40ma7+20qBy42e1fG/LrmcxHphk0vi8cIXsJdBa8OK2PL7E7YKM7QDGZ768UmVx9hovIIktNXdHIA1yPzdOpOfzDicNx1hA2KGrRPP06Hp9PRr9jPYdwnEk1VLsLQZA/8xEpNqizkNr0KvH13uKj5NHD2vD7prm5Gd8p0xbMNmwSvRQ9SI4PqlCrYV3zqvvRg8rKncxG9KB/E23bZ0cXRRNkZSwGkANHpt2u6+dHys937xF4XrKMC9TeZPAdO+aHm6BcdmliEmupLHzAMMrKYoGlQv3UK5p39I7FA0C3ng4wL9+vtIEclfyB7wTu69PB19vRXu1F7OQBG6wq0P3gzEPJ079vsW5jRRlBFWJSpoT31ujeutSPr+DOyDPZtVqJBBlye14qF4MRae5L3uOkFN6U9PJwUakdzRHuC68ceStfM7gTpSBJDkqec1MnxqcgVMJZSDxnTHfJpGxJ5V+idMareclA4G3B44M8u1nevcbXJLQDzkEG9unp+N9bM8qwQTFf8AyzOUPOGY+TQ2YS4C9KlGU74dUWRxyikm6vSxHtmc9uVxheZRdQBqmB5gBo6WaKGA7meT0c+Plvsg2zlYvqYMV2NvkCE98E23NaDU1iupCqN6z7pHnwIS0RuBEtBBpO0/+RmO1oUBawaJmu8w8Ai9FshTpDDBt188kvCoEdVFFf6GcAPiUNIq7WQm6K+EIlAGjpQcYrL1RBVncfmjYPX/Ha0vJ0W9wpdKLCmfpAcP8ZtwlWpq8p1+r5FGfJHY4leZlmmIa1TVFiE8jzlRV3bV7q+4z8Nc4pkBhUAD4vvqlRpdmNZ+pYT81QyNa3wWmLGxXvxUB0GYHOaLdBZbdjmsOfpAeza9cblCwiLZdtASzuyE835u8WZRprdBIIm60m1dL6UZhnAgbOQW7QWuritqUpME2SIp3445CV2B5Z0hWzxenEjcuZdhud8ntDl1QYjJYFGSwM5ov38VcSjxPacIn7oU31n3xehNitIF6t/MQ7RpmAZS9DJEQflunU9cKOJoQoLVLo3XfUtl4dUmB2VCPxhJ7kU/qjMraizYOjDc935IeJkXr4PrFWo7WS12ylZzigYR7228jyk0lRTAdSq3aXYuPXG9lXtVyR/XmrfaoE94UtyNXGnUZjQinpxg3kPQCLTflm8+TO6ybGPymilCCdKXHu7IJfkqLjJekfniSd4EJsVF7Ab7qE61G7zaVH5MLTZ3KLXoYazjZbG8hoeQ4jSRx6sFoKrsStbt6EgTqSNdNHjiesppeYJ6wom4KJYmhIkZ0eNVlbhAILpiLHbpLxLg3clz5Rs9IllrOElf+GUr/yWLGCprH8mDXyG0gouzs9GtLfqjQLB3gdiX5vhPnOUomntOheaaPe6OiSvgin46bVhSwsT7P8EwQ8txFR9LQ6+crjlURWlAIQZGD69XmoUaRHRYZukAyKVwvCdpzdgOxiXe1otXSQCR+/qYTF6XCn9FjWNow8KJOenVLE20RFiC9bWjFu/Y6KKODAYwIUkzoxVeL8d37FKKmRan3ScW5/AHFyvViw1UtBbdPHqHV1zlaQqgisJKOmGLbSxkfN7wH2/n+e87wBgp7KAGGB7kcF/sp+xGQQGMvAJEMiZNJgmG7VqzA3p+XXBNQDiNUqBDQn5hGI4pTXl4K6/5/V+eWbDcKQ9ERJXXAPOc/sWhtgyTnp9NVcI9tjEFI+7EOj75lbje7HYsV4mGr51GoF+qKIhgC76+AV7wGJ1YgJIUGsGT7Pj8xrsBXE+mwi7CbHvEquSD3iMySzckST+CepaTJdDjcNZ2kX/3zs7VKSlXkgncy9lTQlgKc/B/wkF7RfMfAlowBJZws1DVu7ln5XMHjeHQqajen2LNTuPSmBuq+UptLP3EX16XzmFIXHlv1XNe2LwXHkUGY8dTcI5EmH6TMSCRxhown9UQTdGDpa5eV7vKEEBAVlxavt2rXc00bwCZphv0TIfkd5Z4o4eAhkQmgJuuqET1Lp+Phpg+KYkzu4AAisJmSBX78RfZwC7dluwu/Y6sahctPj+rndBR1baPngBvNdwDEKsEsgJ0mmo/1F9ZqE5yJ5mMaIYenW1yxcA00IGm5huY9mWxTJmnIfxrwsEbjeAt/A9FLy+Xta5DZoybM4WFwukBRsMx4uFizZEqEc20RX2FEh1DHV80Rf+p10aNvjyM4Q8pIBpZA/U6pph/G99WCwR8ENFvP79kp38wxwfQsY/zMGKRYswrokoVw+W4tWteNQzfyA1JwnjF+5wgBrB9I0AATHq13hqBqC23PIk0PMXsqbL84nkdm3r/t30gQtS1AoMgEM2/Pnl+gg2ORMVcBvvXyvYavVz8evQlqmAf5zhKqWKypwMF7+lS9xk1SfgjMiMFK9Wu4C7jliPBQQZd+OJWinxr2u7fYPNpA1NB6ibfgJuDYMDEPlthxv89PvLOxY3qinBIbYf6F6YlaW3GwpVg/t+TpHw9wqXxB3lvKKsc17i4qFQtKC2hdfTocaiwYkYGcjc35tGoE0dsKXhvto4f0+oxV7XHXW0jGZCmVAc2/cEkGiJUpu1ifuT/XuFIU0mnA6O6p3w7b6ZjIIFBeW3XnoXDgtrSHZY3VyudBbmQ4pU9Hoa2jkJYexLOIFJ5YSKXJ+bnKlS4kzwFLH0Tw56XWS12r7HHA7siI5p+YN1XQBZfmiNw/HVzgnY0KLCkqqvkaF6xLnhMiEFsmzgf3SVze3D6OSQGtE920mJ1uA4575ANNUKabMVrNd11YCijpIerkRh89SaAjTmcn3k1dM/35+cDwWrEMI6GVXSWa96lYo3Nva4Q2u3MU6afmfbKITcQsOcPEKHnNG5ApDpwdjZ8eracOCUyYup7i/e/fe42DY55dH9uo9ANXGwRRRIoISiPGOuV874dYgUWQODu1OuaRQKLoQLSbN5+NVOq5zHaKrjUPrqfEgWVu3H9r0RPEEHlWcEhPh7zZi0OJuwjOGLvQQolPVspppJw7Y0sx6SYkWlPrciSdfTCM4arpDk7FipTMIB+FWNbnHt15sauWK5G/9Nl62fuRctmQb8KvfTo4ZhiiArJdxIDpIk73tmKv5aMMPfI7Sn/R4eakcR8ikl9FJcjlPa73Nyp1VItQ2iwRH/a0LQ85XyMU0z436gIBCO1Rw7WBLp8ONwHEZlaVR51XB7fnwjexC2W1JuXtaD6jLSE/e8z6+j6kK1w9Hir7r9Hjb8cw3eDtWMYWNAryhpSY3hV9A3azJyZDonlvycJiLjRWjCEn4/p3YmElzYzXWfoWWnsudiOhj7qZtBl/32dYwQkBiSDdvvQQ13gGTBYkxg7HPz3D4/l4nZt/oMz7E7NhOHvwZeSjjf7kOekF7Qcflim1BnLuucMVmcJSDBUz1JFiOqWStlUVf9RheVvp7/cVqVovnZ50Tb5Fl66UNJrlqSxEeVZEmsP39U4l2EreKDHUaL0I2aYij+QnP0/gVCwMiqskZUuf0Twu6U8OkhZ7nIpgz+XuR4QPPntOz5/7vzSyhQYemJj+pIu7xqnEFdAk2L+0EUehu1LQZDJx7HnyA1yDO3hHQ5Jh8zuE13gWaAgWz6Tk0vo9PBNJFlRpVPaAaHUQih33MDIkQbM/Fzj8K0u/kEbZJxMVL+F6eeJ9iz9zJZ0aHbzK/cPeD+WVPURu9lUnKt2P1BTtLeGr2j+/8VyTYXRAKK3oxDajg5dOKAlucEHP7umTS0xuspJSoOqlR+ubk+Ub4mUoNR2NLtBKHAAe8VpB98QA7yJIWF4cvHfNd3eRawCqHmn0qBQ5ooN7zSgZzmGnj3QaSMVtis8K7lr17MGMU3GTGvaoLzwlnv6AvV+Ia2ODaCu1XvqrxR+Pts9PWmA6kncI1lIBLPUn3Z5jvaWuWsCSr3ROmD6TASWyYtl+P2d+wCPmT7iq3XtQ+83t98SLAeIjUHko2vXE2gYApWP9LvEG6/ZIkaoGvKMcjkZNG+ovnCTgOX3nd+TpHUV6v9e65E6CqGj/dLSwD5Wy1UqD6HxttDIRcuRQNXZ8CC57/hY+1k++Li1WjFvThsyDmjBXEScy2q/xhs01Tp7Ifo8RzXfB4oNHRuAXaQNXPAdcgAysnDvip4vTPVERwGtTRMwZHV6wdqeIjC3Ksxwk2zPPG2gGFS/0JsaIEb6K6QWBObbmoTJWeroDsET6f6FvgKFT+v2gvnXkeR8de1MUuDytvgCJ4ac+pS0YQ3APT5VUq80ku4cQu+mhlk7Fvj+aJSxmPs8vSZt41/YzlFGAskbr4f8hpsF/icJmngFhak8BmWbMS/Iwn1kOko2ikcUH8j5Od3AOHWh6SCBGpgz+Ira7jQJCAQpblgRmW3S4xhwd21eZo7Qx8i9cSCBgP+GP7G1d46ieStkE+1QvQO5HEHXL2E3KLXJLmPKlivZ1trWJKiq2VN0Dcq9i85dLnlK2tYKVjsufFRn26KPRbiTB/DXeSjZ6R7/16gmvkp/QI+UJv5ksFFltn6tB0H6E8rXWF12WLzGuOgNWchyTuzve9WPz/X5vHRMdOKElt94EFsQp6E0dymj+/RNePRiZP7AEQ5KxJ4I2so5I6Ez5aOY7rLcWzzyFBIrdcdzBuyKbuAvFfhi7+GalMTorMioGSEtajPqZqk7vfgEhW67S7fMI1Qv5CKdVGUrESzyRBfo+SE4VsYj8c36L3ULd2xtCPAKK413sUqWbzJoNjqX10Wy495942ZToFT7jRhpL2lvs1izGqB6GE/HNE63vpw6b2QAlrAbrJiBTpXvJ9Y0Qd+/7BUSZu7xFG0QfMIDz5nvGGcSEqGELqrXj728G0ub4ECqXJHG03ojKzux2deoVo0bGLBG6IQoTV6GC9Esx1VvmfheS8ibTiVCnz58gYyN1sRCVt7dc2qeDn6vtjCMP1HGknnry+0ZPGIEg4GhPbHdvmfsYVQNX0O+s8fPPMBO6N/r98lXkOOQPmpiCVOsN4wg0ZUdoVJwsKCyE/OrFg88d+jXthpbxE4kqgrMoeXMEGgJR2W+UeJCkjm6pEIQYbMkTbD1d5EruVoZCoPKnxxWKPyfJDyQIqLHFhIi6N7AsiLytjgBP9VT3RgqPczdlqPXt0Fztpb5Y6xKP4LgMu355ZSeIBdJI32RQB1yILAeSe6nZ9TjBc6wXFL93foZ7ICLNQxIDI+Wn5mu4nhUqAvvNt9SVnuFyBu1QzvuEeDRaflf1EtQrOgbyZZztc4lxxdNtR8EFs6wAKPcPwRvXGExxW5EHpH87TvC2iftAYSD3VtLUDtnfgp03lbjfa/YRHe4nTEG5SjxruPVCP7XvQ0GtIm9S537SD5xMDd6YaH8TMo1oPYu3RfwIKNkBcuaRdnNc2WGgtrvII8RsyYXvQhUOwd+ZzsdR/Ebt5ifTgiKUZ9yiF5Lk0llFMc1T0gtJIHwqhVs2+57HMYgWLz8d19QblefSNwqPAHnw+imfmzwHI5sJIO+x3b7ZqEzqtveDmR5Wp7/PMISLPYdSsN5iLcUFLt5oUQ8GEYY3dkwnt8b9SWF2kkPYM37/nosmITfgxPW7WJR+Ct8voo/AHMqLbaTpt8cpNUoT+YEMuEp+zRdrhP0pRXfo86Xml3RV2kB92sHW1o7q0ICe6t4/2cOxMMF80hsaoVVOjIH4vK3xaLy8AzhCqhzFUTwICjW5y50bqahN9pvizcCS+2IDRipq2/DhLbRla3jfwAipcxZWng5lJzeTGsG0Zh+e9Flys87tJ07iM5br+BKRJnVoV7+68xz2L4W2X4yBw3TlGirnzSX95hZdbrkPEV7sXuGQfe7y7JZCFCkf2Fg5qndwk3r7CuwQy8/Itif1KOcABQmv4/mzXpHukfjalZxigQ7M/+ZxPHxt+OoCrUEEitfgHMdJPQfRiRk4lHHK2sclrpO8RVzejQbGMfW++Fe7e+oB/ecsgJEo2z+gASS6qAmXnX/jxgxT8CwsRprqSnekHVS0UTxr8g1b78o9jqC6xsiez/CpFhU+xyfmbW3IVXTprdajVzhcpmuc0vwLwgWYjltWIxcfze7+ZENgBxshqqP1kuqBnpK+3ugW78c72Jpq11eRZm2ZqtkO8bl+6GU0lCg2mvFPTKRYU+FPIt5Jbebb4bmhq+TpqJdwnv3FINWrx16Y7CRep6/bI1l1LySJxPyFqPP5hXF5Z8i9AaGQuN0vnvRmHnEUBAVCBvfONrfq5q8H4lWEmCP9/RMmdEAnkfmbx0N1fMjZCIqQrWqXUzZyWZtxtk8dLKy/Jedm6743kpJAVeLxn7w3AmLGk0KVueo9zt4I5l/ObbYD++4+Tkn7T5i4cIZ89Rt+cZMlCRJN0GF476xovvGBxVqIrWGUmmdCKI/bumszmfcoI67cw5XYxXCye4XefBQMRipqc4LU4tflJp6f9NJeVZKfqJtwQ/GkIUbW4WBR6KwzWg/plTQA2UsipaekW7zHlK07W2SYOYvHMHkK3D5kVhawV+nPx8WerfYCdtvrqhM9zgZkJzyUJhHH8hz5SBLkXBeBnC6lxmi9Bfk6ZddLBNLTyu5lbHv/nQqpfVPvuhIdDnRM4hPg0tgmU7MLE4NSbIK95dfYEtUFlMVQMqLHS2pXCGIQZFl2l3jp6dG63eSb2B/15eG1x5EK2cg72hQh0VGc/DSy9DiMXip+GIrPnu/RncQwVd6InUAF9ZW9ZU08QCa2SZOdieZDLe4idqNrMmqPBSGkywkvlvyZyi+e0f0/OQ7LFU+RUtyfw8pJ7JJ9w0ZifXrUE4pxtHgkqNFHGoPqGBMcsAgk52+mP7/VfKsToHzatw6q+R6v1xzJSzRcyatE67oiAxawY9YL5HTGt+r8bXK/FgAspkFZ6QaD2FWoKC3Sr63Ea7yF7CoRbWJ11pThQ9AvthvrcwDB0HPmjNblqOKi5OtPmIF4RHfv5vj7bKlW4Z4YF3CtXL42W49sVfysvde9G0ACJTecrcUTjLtwD7D5pgxgqtQUQwR7e0gtmWTwCOGr8dEbV7HrWVJb+q/L8ZUhs2RQHXRb+oxvzuvYlVgHvi1Q9JZ/wUHejGaXmsCI53TmtuydeYBX7T8e9Pp4T6wRWbnsq4mR9tqfvJiwxliq5scwOJ1qIbZLCrj+8sqVy9gKSIFJrrY+z3CWDsn0Qy+3fu0XPcLJW7RQpKIIihy9MZLkeKVOjlwIci3p24xiN6cbFi88gOung73z/hfWCaIK8HXZ8VPcFPxt5CFLlbIxxX1fhkcoXDD5IEbiV/T4gN2Kt2ECkOJeGPiW3dKj3oK3LS5YaZHnGQ5SHpnkjeebfB72mwGJJ7nQSom6IJ6+hVtq0eGkJdF9kkwhpiHRelJVcJ27BBC0UMczRJ6HhKYEjU5WdeSaN7SMLeTj0QseydL7J6M2cHzKy+W7u+QaVMEUnRa0bv2rCN42ZR6JTdotuBTvyLxtjmKPFBgw3ozmSzFCkI49orZXNDN6XNkY9pqqxOLcPb6cVNSGDmmvgvRtibsMY29CazHE2VSi9UTYzCQ09V6p3fznsRMgQEjFFZJs7uGszQIiv0m0uEezs6QmyWfMJvtMEbiTthukWGm8fu/wBGX41q+XgVJqXP1GpxgwY54qL6T862eR3RBGgUbUFze2osNJqspNcsvylwR/3EEwV0nyQZZsS4D6GV1OURssUechbXVI93gSN8i1IqANQjAG6HIA8UhAC3NjGzzS9c9ZmIEV6otU3srtnn/j5dkXC3hr50esoRNCeC/z1PrtcTUIFl8ZQKjSPLU8sqM3yBdEfUBwpPUzHL2ZRVZmI/1CoJgvcvaZJke7JofVX/4J18fgRL8VfI8YKDcWBaBLSRfR1fjzMPO2C0yUzHF/HtF6Uh8/0Q3wLyhlfv78bkI2wuTIJpXZmOkr/KDaK6eygRiv/fmNeVk0Q/4/YOCKt16hPaCBC5wywWG0FtPFsAtb1Fak0MthLy38XtkuUnoh0wlCJFpvoaRKGbJQDGslfWpR2W5AR8Qpw5ePHv8A1tLieg==",
    "IM": "eNpVnWmyLblthP9rLa9fFGdyOY5wb8Ch/YfzAwfgyFLIavJWsUgQQyaA87//899///zfv//9T/5y/ucb/+T855/8d349tVl7qrWktfq//3zNp7Q//3x/vy/VuXpds8/c+/Th/ofRr6SWv6+3L7WU9L+zzxg2o8y2RunpazN9Rc/zCdMm6J+O2rUIzenDR9d9f/9W7XXUNucdnv98yf44r6+Xtb6Zc0/LR7P9cfpGTfrK1teos753a0LZT/+m1jb6pzXq8T5c93AZs+nFfYzyteLDzV7eRl5jrbTGt4Z2ofqE/WlV2zLm7KmsFJ++9trLV2ods65PD1jLJ6TvbG5vecy1atYyfmfsz5/t0+Fod1tZVc/wJaZ8vqDklMcqSw8IG5T2F9SuxzZ9YEutdc32Cft8u46sNf15TSX/fGLax5tnHSnpK5Y+pGuNPmHvgb5htlRmSrPMcP6asM4hfcjFl1MfabU3LBm1v2/6V2555aSFuoBpwjnDlIYJaP5WisP7DFMpX+99ZZ1B6y5AV757r1+dugfavVZ/nt+PjDTJTlu9FF2T9v1M2SeZ+jdLrt/QduYRN6F8Z41fya1XvaC03uMulHRm6J5MnVLNWcvxGQtR3zOK9ohj1H5809+yrrjrY2rXlFQTi/Xh86k67SGBmNrLziLCjH3aZSQJkQ58LG24j56jLn3VOWuVvOTys8K5X5BX+yQqVa/JLfz9kXe0TZMU8aAR/z7dk2w6jpSX1vhlX12qd/36uqWV6ws5quIz9hfqkq38jVkkkK2V+IZ+ljDmx12UROvOhy1MV90gpdIJM7eR5hvO+0ZKRnUMqyX9dR/x7/O+kBLF0Zcu/ZC8/JzREWft0ZylpqRVFJ4wfMbZBUmIhEFC1fWROe6TS2SRtOu4Zx6cxFPbC627p+gjhrRazkky6cPzDrfV5tCwVGsNMr2e4i1DUtL4XgmNH0bZOyFBrFWnmHSmV1TSh+a6aufrWZpbpxVkhRl7o/SA3PMokoW2wt/bLmUeq83RytZsP+Nlj89RpXjL1F6uHserjY8hEZFmyn1+c8a3b1FesndSWRlBzvMdAhO21pIxWFp/zZV7+baHCWd7alpaRM0yXsn/PJ/vl7ro0odS7R21GVaQ723WKleVsM2mg/LhI+voTCluqYOk6/A0OzO26s5Vtg+bKROx8rMNTDBZL7KJ0tlzdOnVHPfwGuakTa6yQDrh5t93JEQfLxnWKclqZOltn1D2AfY2dAeKrqr2WUfQz4R0THNdUhNL8qVp9T0/oatsdbI3o37z0y37fHUJy8xNTlxfBEFiXPwEE6aZp8uk6QJhWFpJPf79uQD6IxlFWYXc1xdefy7ATLZ7Mk4SdCn16TPWU9ldRyMR1431u64ZR8hTqZIRme/JGoYPpy2jUoX6ejkXRXc+/vk+Yv2lqTv5RdIaxYftfOWSlfbJ7zBF4YNHA0hkpaGlq6UC0u/ixtPF+jhTZK3knxnzWO6iyylNKa/r+3nE0WUYxirv6hvayDC6jY2sqswQh4Tv08MJ5bJvuARTl7Pqj/ts7r0wo+5L1vV07TG3GBeg+oSjzytOweAiSGfX+I55TYLWUbUHqKr2TAIz1tYEspZD5l9qecwoJ9cyS80X3WJOW/LgqiAfOc55ziybKUWS6zVqjB73ZI2kb+wynYtTnj5h39NU+odzqCuYZvjzc5AJ31c2XZeodB/dV5TLUbR8OVcJJRCf/uR4SI3KLkpQmjYgvGGdTdYxZVmj1HMt8fuui5jl/EmRSdvpSJMLQr52WRuE6yKTMXXSfhnzs8xD2lZWV4c0cU7efcvX0Ww4P9xaqaLqX3HEOeGd6QHaZSm8EVewL2PGx1aokkwUV1jBVbhTsqL90VbIbv0c41G4bJDeIXWu7yjFh0+o0KVpkqRFdsE8LZ9wzPKSIpITqokyuu59MMMUbsY11Hlps3R1W1zjPs2ByyUXRGehS/fFCecwlwxy1yfqXs5v/nzEOgLR9Jm6EXiJ+UcgrjzLMMhF0yab5mG4SJKPWs1yCaTv5KYNaY1vb/Qevz6WvBsFWxonpjpL2DPsJHWdcJFS1ZG2mnz0OFgSZ/Sa/rv0a/f3hP0FeAxyhSUPCRO+P8AmnKBHSh8HVQGHrtyKT0jHckpjS/nLw5ByxUvwj0zXx+IcdCFLndLvP8/YuknKfynilLxwJivsw3YUJQsENn1KQ00UrY8fX1gejiSuE3k+/bsnnKhWJ5WSNIYcjBHev7Z1U0Qns0N0KcX1Ro+XuXT4sn+So6x/H71oE47zJX2mO6k7IQej/Sz/GGf9s6wDUhggeR3fk4On1JKsu66rJunOt7dBT631jMaUk6noWGY6TjjXQaZBCkf6QicpEx5fcVSbhLnKo9cqCf98+AWOhbPkv3BPpk84twH3VwO6eHICu4viVW1FIxyCJF073d8uZPdCFRujcz7u21xxxpYDrUwWXP6thJb4ufuEekJwRYWyP9IacoSun7xntCNsXKeCO9dX+Z1xNqITetYysFVSsu888zPWiv9lDPUSXT2iAv/U/NxtKQYi1RL+HNXW/2Kgmpw0OUMNa3hhnD1lnyeyqgBe1x81FXfiqjfZOJ2pFiivp6afGfXGDDLzQmNw+dmKcOQ36tDFW8TbKWOv4l4csEeeu75Dgi+7dE+8PDBH92FqSA5J4zzDhHxD/YyzIUAEo+TDF83Bk8lCjHRnzZJ1n3Lwqowz2zO4ypPJ4k6j0BItQJpHqEZQX8WEssst03Uz3TK49iNsdbka7sPKdN1hmbqJ9hlvxpVLBcEtsdtystuMH5rel2DtFCM1TV43wttT3nHoOLG4cnJNuMNTTsAvcyEnWCgV0EZaLlflyWbG+9bbZBYwOuGLj6bTYWJ0Ba50u7Gfb/uRzQ9ToohaXka1G+DPOJ6k1MQgWtJ79JafR+QLDYwJqMHB++BR1tpyU3S6qF93ySzXjyTa0pulrqTuys9nHtMLqpFAKLWADzsdXnKxiwmOJm824Yb48HrgC3EIfywnI37j0cmASCwwDXyun+O4EZMcXf0Hlx0D9C5HPcaZqyHNjtabC1et+4R75gpl5C7qiuqaznAFqxvgBYSSdJ0Vvfo669G70lPyF+U0Tjm9db7RK5paHt9C7JHjWVYzv/2vDD+gINu4cBzDDajX/laUtmynwkpsdfiOK94VVwsLXnAY41YcvavXVzmu8uwlGf1nwjlRHZUOXGEcYJiP3tOUJzcAhy069OGLbQjOli7ECvYnjfU5kwLEMSgKOfIC8fNNuM6knEH8LCGWggRXnHA94sHt0y5LdF9ss2ecywl202Rc0RVp/bzkHKXkUAvFMEi6Xe7rlWqpEKyvNrueCH6PHgiDI+A0hYdJG70VNKQp/21E7gJHMmMpHGN7eGHD1f2AICo+QHzCwXbHkBotBBbyc3z07rJgYVODMk5f9kNsT9o+XOUMDIDXGcStPZxId0G6RXacCCGo9ObxC6ZmSevLgo/lwyf+0rUWxk2MIzPsozf+kgKVs8eNQ4/GBZxNBuybeAlCFn0HrpsnGERBUwfe7r6DyFn+K525DMeR+hTiuX42Od/VT6JvKR9z1vyU27PMqKQMZikOo+DthSlH2hSUEAU24o4c3tEulKfrqofLf/iiT92uqCnyxUMSB6Izqz9vuPpPS0vcZ8FZY7zho/zkJ8qlJFovGILwAuDt8Re0CKhN0G5nZtiJfq2/IrOaQFQUV5Tuo5cGYFBXAjcqrLCbtM6/n0kPGLupnPT7houawNcI05NUFvzm7DMubKogX/eNDf+Mmag+5aoWXciEUCMVw6W6P5x7IsqKQxVK5rDb/erHzAukYKQ+bN/DhGPxoOWkFbRZ4H/hY496zOC+OKZygL/fV7RzM2WuJPqKpAQE/TyhH+ZIwJL5QsIoi1urfkIUhZHS70J4RWjIf4ivuC4pSDjoDzjbz1dcJTl0HnB3UoQALL5R+Yb90uGSiMSp1OHDJ14WdAGIpSAqzRBh9GezFaTJX8XH16GUeBQnXhbkoEi2JTMmKZ7mEVzZU/lYxOxyQJK7WePaZEkl8R3O4MjB+RgHiPyIkWVvpTtWSiFSGkGNDpah7ZYiXP4d48mlTqlhbBSurqgFx5NLnaK8Wlll3dBn7sYjCrW8yjlJmmZZcZVHjQqrl8yIQtUNHi2u4WpR0796hQROz3GBGFcoBRERbmuxEL0/E+pbhWLyBF3wrtZ4MU7BQRPYyV7m3zVeItgc6wVcOLqPrqvmt0VKACj++GuzJWHCRJaBgc2ffeF2uW/6v4yCHPFSDg9vBtFmIiyGc3UvclzIHXIOIrVginLcgUvMSDvpSooxF2lS58+MB8vCqSja1C6OMHwIY1hyoBFZ5fEjbeWGSMRIACw4mj5hPpZwfx7mVIFDD8I0PYrCJPIVYguzj15zk3ASE+6JpNqHj2Omv8UU6tIqGHNzPJ+oCnwSiAXtPszehDfca4vDMgb+icUcYcYlV/CFie7Fj5QADkz3HGQPwXAUS+pAtBHNp5yd0KXXLoHqTqMIwkPOkQv9qbxKAttaGH6pD9KNDXb5MsflUOOHrRSFBt4ns5hm3Ojro4qaEvIBD6WwPgRx8/mpeC2FBACRMV+J5/l4Imk27JE2qn35Z8Y9TgXsuhMfQe+YPzNebA8xrDNJaNu40htBCb/V3SSKk+3x0es/KLYZuEmAzSXu5JFbTcjD4MtEeBBfsE7sgyVJOvRkdIsf+Q2fyKMoOCmQKfEJlyCXUMnA6znSUTVsdyDI5V7ID1KIL9GpPzPqUWG63hapym4F0XSKXFrEyH7JVP3azyMORS6LCUsuVfnjKa0n/0PSgEEB9RpBka7rNQMLyleS19x+UKl1lTUfoJeLxlfMnOIiLsApJL5JqgwgHT56oyvjr+XXVqy3K3tn0o1fJZ9nEaP58IG05GVVgzEqYP7PA855K36bZBFkLMLPCt8NbsTaWoNsf3VlujzIkseNmuFNfcVnPNHPeswChIQG9uF8gw+QQ2huwbU+ei9vs1wHso569KsDi67QC63f2aRoNdejSGX+5abJOcmW5hSWeHl0xUbLUIkGZvqeIZ706jLAbrRhZ7Uu+oEsx7mXd0sYcvXpJsrPMhEpVIncnebD1y+WqMgmEgUGi7Gp8qtiJEedMO4kUO3hswtaNw6i/IdJGtQV182VH+gjE2jiXuhhPny1ua4+DPKEdJg/DzjZMVogGrTgIPnfPzmQ4yWuWC65bHsY3l4HHLGSIRrpZ8vv9GbKd46VLoMeIeUn52mFDbxEuTgnxSU6BLziuP8n+JGAKM5XbCX0yffniICCBPkkWCJdWAeh4cG34tLZkrUjW2qJYJ9/wVVcsrMFDlmI+WiuEDZTfq6jkqdk75BYw+mWT8kPsZCFaEj9TPlnxoGySVMD8JCiD+BputSMvC6p4GGUs/bJR8dRjROqnhguB+0aGHO8Da60RL2b5ms+5Qb8OgLxiDJHJFTFhyDq+a+5hoXEAKnZLwDVKTkir5wU7EzL5vSHR9QL2TfyvJbgz1p/JlwvDV8YTT79uJw5r5h6ccmMP763HOZ8e/xyxIF3tOf1DZ6gR8iemBnpTWE/8bYkdzTlncoUy8lTXFCf7nTi/GN7Wb5CUBz+J7GPObezrhMo0ETaD+tlh+DroiCFGyhSDEfx8n9AnuRVSMdv5RZWesxQhjM1/KrE0au2gKjlEehWtvwjtTfmb1h9bJElIrx7lT03s2xcpIJP/Uy4Zih3I3CSWTsfvvA1TKxYf+AbsNf4hAPnSxT1iXJ3FaZ199kDhQ71oqgB4YfPjDOuDyZznEhTxJMMIpevPS6Wq8QdBueIy7j2GEuv4EXO4DBbM31GeQFc4wo2EjvSz0suhiPtLsmTC6dgLgy3FyOSBiC5yrUEBZAD5qkkTRnFZRH9zyvWhdumbYFwOaM3Pt/zF0bpa2Us8Kt1aD580DgxroTc6MQcIlXn0aHBF9yrnpFH/5nR/oisMpkh40JhjnYk6ID8LLM8HxLXpPAAD3z4MhLcLqWtVRwUH72uaC+WMiJHsRcfXedqYa4wVen8bTVy+rnS6NBKADc3lFgPeX5CWHIAFETLR3xnUCN9LoeHgIMERDiTIyv18OcH8JOj0Iw9/x61umfMC1p0mF0tUvf7Z8J1rgbJFIpeLKY+x1gDiS7vCwZb/sRAj2x5rJFEt0TFTkY2KUg+fARaukehHmlyBiGHz3BuSb6jNBysY+s+/JwrsrqXpUOksL5NQoi5nzh/lSP2XTySTEINSKBIOjkMLa5+0+cfkLdINJLzpj/8iKBuGF/2AblKh4U/3/pV1lEoiuxTIrmpxvF6Unb0Z4MMUQlzGDX7QrQpzd1Jn4L5CuMXZSTHVG4p+W+PhNwzTjYLRE8BBgRe9+M9KRyKYWD/gQKGJcb4hH14+NYSEekUU11PDPN1KBIkERkguKU7b70ecp/hht+u+L2SALEV4h4+WVefIaAyZLpjo8TH78xC2FHohUQaQnvyeXVuJaNSLx94dHpH+HsTcGkwie5mPgUxhr+/eqqRk4CSER1WfH3bBifogo4uhi/0j9sqihsjSkjanKT1FV7+mPCEOSNFJrXw7C0a4K7Fonbcg/jX24nCKgK2KaVy+tjY6QgdkkOGwkTbR7dQSzdDN0l4iE3jrpxMtYRHolQ9POly79vlxsl10LJAbbY993HIHBKC9ff4HPr4BtPQfca5sUK+SQVrhBKEnsNn9Ms/kttM5iQQU3zEuIlgkvqBD/r5rS7nXAVoyWuRcZHbwialN77tKKkiGfhgkF9UfDTvrZV/n8yBheMMX7g9Q5J9B2ByxQj60o75JLaROvlI9oRdDS/fbqFQA5KPSD//QEmaT7DVF7ByUlqkeqlk8N15AGTCQ6CMQl5Nd534iHABMJNqF/JJcE39Fcd8CsSR1wQsD/7/hUXeLLSKzFbL7dXd8uF2NIMOQDfrgy8SjBEmHETdUj4B34D4fHQfH/nMYL8ZNiac7gUfOTc7ObJ/XG+VazypUDAEhMdPNzv1Cingsm7GwmfUG7KP55tDJwGA9fyOV+ozjoklQppgRAIN0gWq94x9jzL4KmHMMrIrPuIYB8WZugUTNZN8iSfYxmElc0oiJBDGR/cBGTgrx1n+PYmOT/nXC5PLUyWM3Cjo8g88VlFe3ujm9XZzFXxxxy5K80EYSIPoX6PGCVuJFMIaOS8NWCR+/pZScGXA0ymz3mb30VNLA6lDTq0EpGVf3i0+kGiR5tixzfM6w3vGSfVM3PAJOC01GoZ3Xj0CjPYkUUmXOLzgxF7S5520axJ8Phehy2mT9aaoYoFXlC+e/xYxkhZItP3IoJwzjB/bCDNvYCK0bbrra9cyadWA6zpduP/35+1GA6h+wDVwr+KDR7LQ3rgrljnhlr0dydLlZs+7okeqA97okywiRt0gSeiXS3j5TaPVyU0C5IL8Nh+uW/9tFUX1Ct5B8vF2z1Z71sjL1xbkOOFCOQmXUGaZT6l+ui1AOSTsNarlcm9feMaxrYBmJIMb9xZG07l7JOn0slPiVvjEI2DgnRmWJxuaEZ+/98DuLheUMqj6M+EloGZSwOCkifPjjPsRoLf6hMFl/n5WcSIh4RykGw0oytn9FjmdDe2n50sRCnx6KaI1Uto4wBNaD77XR08uzwTuRhEKcE7+hn4VmUDPzUUTUK7+nt8PFk1SE4IqcTSrtXz8FqZBwJgLnkE632V7dDbZfB0miBufvviIcdKuJOmJ3MnCuT+R7a98EFyP/H4ydqob/MdUEwUmLqJUIpOmTzgy/QF/Nu7cmv6Nl6beenaAGOXgjHVPrhjkGknjCPdJPxO2TSK9HW0njyq/hLx6aOrrrGK2ddias8KEfK9lIyFcrzdq1IcfMUhOJc6VjN6M23wkEv4ciIR02fLFk3xVCnABmfxwktvjhKOV4NOET+g5OcdvuHYZr4RKS3yXERZw4kFOj3CcNJNgNMcFWgzEV+5HseJAP6UR6mDJKEYjo/t9uDwMGINGXVuewfKPG9dmCufIrSMyKmEBOyecKgUpxQFk1Gdc4NGsAuSoUdClqcZr+oStWZWkSAGwLqyc+/JGH0BuKD7+IYyCn9GltxEN3v8RvVOx4+P5haO4HrAWm3z2JVz1Ck9hqcAKnXp4wgWJG4iHdJ+sT3j/y0YTidGgdEfNv48/ia+EDhWsS8M1ntFByQvJVHixhbyS+ISLrBi0kaBegTF8+CqcTL3QpH4zpZ+/rzfbQmqRj8PJaXHCoX3ktVHtLLdLou6jO/KRY6lvh44iCSFs8QMMtXmyv4matlzf8FGnBZMuXkpYWh3zC3+/NWozDaagP1EM5G6dE9uF0gHJKchRC2r/8dr6n/CP0jbgzx5XzqtSyQ+w6gNZclM3PuF8oz5d0RvoK/5nGL98UAds1Qe29mruaiz4TgBrGDicBTcLj9lGh6l2AzapnZy9Gsq1ExB6saozqf/qwy8tGIQKL4ur7sMXQiSHrAHeQX3FLXplODoaSL1JAbBfdCe1K3iPtgGbssbPIxb5nyTbC6C3ujVhUPPidzblqlzycTKcu14W9iA/JpecngW06/DN47MTuHgjWoQ28o+8ZWXmnciJlE5BF8Tn90tGA9SRwtlyjad09G0CxgScFw/RQqDqdHYHWO4GW6/gJs0XqzcyG3WSlEHkML6lnbRXRTnUfkmiXd+9Sm2yUahnl95fVI8nn3CSbSR/tA4gX+aFKcurdLSx0jhUZCGK8QVbI+/iusZzxjugdT2HhEkjF07+6ig/61tPDqFdFeco3PL3X3ix4+nDcY+vBx9tOby4yB9e1GH3F8c+/hraV95LtY4QP8t/rjIciFxlS1rIPnwdPDtbYDSJo3/eVqXkmk0rCmlWZOtPz7dwk9spbacILL8gZ10Jq1R6AIS0ZE6sL39HQc2oF6oEpiVC+/K2IhWpYQkpg5KL1cLubAHt9dCxlFOQj+TjqJm0c6RwjeT/nhqr+kqvadYB420ZRkKRz9dBOCO8BHCky37Uz0rZJR/eR4t6JtN0kjLy9ft1TkcLZIAcwFqQQnivjzPSIklEqGaSRiENrxJ51deCbTv12dIi8vWfO8D4zYiTmZKpNoB7+Q4HVpokMRIo6SUwv4fWeAU3eXBUweqcvrl+HrFBxpmM7+YiasOWjz/HD2fBUk4Son6PkRknmOm4vHDTrb5StercdKI8c1i5oSKuMHrsraRXXCApjOndgUdL689kaoEwpvHS4e3zuESZDgOYkuB1Mr5uJCx8lD4AkE5v9FUjfBuK0gX//IC2rS3oPLZOCk7z3oc9QroChUnFSP9CwMQJGwf4yANCCPWW+QxlukWCkFwS/wFehEdcfPyo6G6DFFWs4ir60dEZDomaD8LI/K5QehyJvKRBYZtiI5D8C0V59TV9NEjlUWxAhrs/4FpaWDQl+WgbdTi+wHSLl8n73J00fg7/lW9TWo9sfECGeMU+od0agUxBqraPWrr4hIMISzigk6fVfbUnApfmyMBk1RIBhQzHXc7HypANLWeI/DT6Svj4zSsgeR44AsLlcyoiVHHTgAE7MoBdUnzGa6khdVnxXunWEDby5TzqjjWrNgBW/+KMfZaAXdpIxS/aMT+oY2slJoXKIJkLqeyfP9+7ICmYWCsIr4t4vfpr4iltjVhJuHI/pvwMKUnvRtfr/xs/E24ZPv1AKFxKpFPFCe2g1pkq+MVd9ED9cdCgyXo00Aglfj56r6lQDLJioTwdFUr52FJIMNlqAWO6i33F8fTngkZwKZav1Hz0gOY6f7xqbtr12Z11LnRUUmCk05NDnMK3HT1bQDyhRMmkzn5NXmWiuGolzhilYTmO4RUHj1S8gJuQcdtafMBJI6eIdoCMA+l+YcJFnDqRM5TPqB6/e911oXETpy9lLyF59yxftk4STmoyoCoZSmGJV4Qh/wfGBMKq+vB2+q2xgCWz4zmEA8jX0tDFYhE81jIfqhZKrptFlo111jHjGR7CzjpU0b1G/643Pm2BeCYphmoieonM26yjBepZOl7fKXtvGakzTugXHbS4UzpB0VH34U24TmvDslGcixC0wDlDWppWp09AuUWLLZLOsG46KvLEqtWetTflIqAA43B2Cbv6hbek19qGMplKQN+/MGwn2SHWFTe0aZx02KXnNzS0NkSNoJzby6B52ba4oQYGIFkgHeOLjxhHXC2MNGFNvkuPwNE2NesUZrGFP/8QODSAGsNgnPrqxlvgnuVwkotbd13QiBNuIgjbRHnatMYyYYlbnilrn8aRUqyY4hMuWkSmVqH2guKs9wDvOEHFutW/5T58sJ++KVZ+gmWnonn6+FbW2mLBLA1+Jd++Ku3UVJu2FA5ETrP+necXXp4cTwPWXJjV101iz9gau1p8SXsaQL34hNdoAaCn4ZbBYG/XrYWibIKSQnYqZKwPjlt8OMgg4Kam61vuCfMYbuHvk4IoAKWfCZuDkL0W1gWOQMlU+ICrsRpVAvhOEHU+un0rg2hQBrJ22bf3OoUyYlRA4dzO8O0HgkmkvuFUF6o04uYdZYUrCWVOKXkJ7z7QuLgJmn0gxx+JudVnHJ9jWHoa1DhF8999hNdQg5jTcG1SrxVEvFzfL+FtkF6j6KnUJ0HldcVrZDVI5+r7e15xgn0DFZmQa4sQoPS3Cc4yW+IPOUA6n1Hf8EUDq8n9hAkqK8UVHpOJdCvGIB80j+aj22RWaEoKvMTApRL/+gBpshSGsGUyzX303E75A4CVDYv9PQ3k5dJUBNA1ggyCb604Y56WenhTgCvFXKbuE9Yl6lGE3arhyy1WbrHiWgdIVptAnFZ8/y5Lg6GB5eubUvcvvELY8Y8p16745z7cHlgKjY5H95WX/dMOz7zLphoMGbUTC7sTnnH7YxDhkPOWuwvAEUKSFxMOOkzs94UFlpu/AumCqk9QAGf40swfAKGQZPKBiyWR+IQTuVG+1igqHd6FrQWamdC0k8lTaWM0fNgkkLhBLueyNgZEiD5+VMgAbaXyFZSu+LApELoJEqSLorUCWh/fOpQSi4UrQsF4rz56sGw6itCxCM7E1fstjSYnTu8kCYrr56MvT1DvlnEbIBwrfvtttgObRAu6Ct7c44RjIwlHB7CWtHD30UeuWV8YtriO+YZP+g3RtMwT+0Jdrj/8Vfqj2OlskksYLJfIgACmfcN63SZbKKumJCIRKND6xI/tss+KAoTnob/nazXZTkn0Sc1qkF1Af6v56LrtPLneGWC2fV84tx1UC1opVv1Jsn5xH+yyz+BJ1E6Am/Sg3R/7zK2jNGXSbWkE3XALqgmgFi33FDG2VuMTrmoAJp9UEpIt76qhXe1GtSJNsQRt1pR99Gp3KTVL3OR0mg/Xe2uRmm6p/NVVt3PQjfK4NawuZIaXX/dLCyddXx/Zg+y1Fw3QKgYyEJZmfeEDb+sbqiQLhBfpw65YmoPHJOg0skNpK+HDN6ynXQBt2ahhiTt4ExzoQgl8S+xf4hIvegw5Pqwl2HrYb/vhn3GTG0RG8X4ULfLPdE4T3ZStS0F4wCG7BhHRYqGj5PDnN8eBJLRK84NE7H2G+41oQUWXpa4TmfgCL7OM+fiMeyZdILkX26+FVq27FBdXuNkmN59wY3pqcgb998ps8+cd6xhRwm7cFYrC3ujrjEfFuXXCIO57n9ifhRZqQ8dehSPCz330plPTU0cheabdyhdf/zqSZesMR2+7GUb7eTrIPGUhXwmxUvdS1LUsiSZTTR7Coe7dm6TcuhWX1BKef2L6Zk0fMt2jUu5v+OZQA4jQlxKQ+jH3e8ZpbliojSzUo5eewwJPmg1RigTYGiv2+AEHYLbaz26NA0EHfYEPk6EtDJxasrguzjhecqbv8STqtv5V/hFH12UjUkXgCAGYvsThNSsNZUnNsuiWvPwRgXWWEoSto1KutviMI8moUXgy8pFCOPdoZ+JAOolm4nYSTsI7DiNHZ2QyDg2w95McR6MWIj1q9UnISi2Or1c0mHCE9KlfC/7uK67uVAZJFOl2ssJdeOSz5f3R4lpn0X7GnZaTvraOJl5G1gL3bAw+pCs9WUm9Kz7jpGYSL1uNeTbFlH3CjtsqcDItskkD+PmKwz+PbJlF2u9nVsc12uRlaf003SWFyNd3jDaiBr1P1mL5+YBLytHqctJBB7B6xaM8Io25I29nWUO0sD6cTrUihy2hKprwVzDFTWBtoTi60MJvQO0kKzQLzzj5idOykmEeki/galXZG5L+SfH9vvgN1+kUrwEk3fAp0xWU12l8FEtpNGLqNcZrXhlNxpVwkZ12HOLa2y2cTHnZvUqDrJ7CaD+N+eCG0YvyH/2+eVk15QQAydpeIJYVFjifXVqgbdiH1t7wllLIe3BC66lw+xu2Qz2fOjZJB81WKd9232seSBw6F61s4TuNIXz8RRWWvwsYS5Ml/8RNPpP7x6kl6+9RwyeeBFxS1z4+rtRX6NwO87ydBywaxANQ7hc+4QTmn/WSkNWCNvT13XYUyQqS6FY3rNOKT9gtaRtRO6UvYEdxh47WHdPCP5oHp+f7PNa5W9or3UwBg+P5PNymgL1lawdRfHTeLuiyVzSxIgc8/PE6AZe1QrXavNePuJ3i5407NapW4P7b8M1/jHOlzMvCEaofHJtbLyRC+zSq0xbV3vEJh/BAB9PkQje1Dt+/yzlbMQFqnn6vZT73+dU9LyuTwkWb1hggLGFdxoTucSTf9/y18IbLO+t+kkNM9d7rkd68cpo7kuDG27QmdsPHL6UH3UX6B0kgPw941Tn0xqIhK0nIK67hlFHO3RNEn0CzjvCEHT0NwzUwRVamHsbPQaPJK11ScUJmfMH6U/4SvpDlJYAPCvfVR7VQ+Ww5WpDEZHyu+BU3F0gnSAPtTj+Pyyw1Z7Ct2evcPQOs36mPn1QgEH0DMmF0VtyG17uFrkIUmRPF5zhhHWIGoHnQ5spS8t/4cTAgiC1S/yh+vuObpz7MBrRps34Ub5ucpgaAI1qhge+DAUPZM26yhbEVEOLp681Sb5hkwYQby2gN9HzCvu/IGf30M020+70xTlIn6hCKvYiEaR++1AmtKe2IhaZ+4fkn1lEGQyMXi5BnOFK5KWpLPCS3lGSiD18wPuBkhAkBGZY2Sbt4F+fNUO8Zw+w1Zm1215mvfJoGOhVnkTvjruSrfyYRgERU0vvqDRQeSc1LiVaHFXL9LmCf4iRgnqY2gAV9/Fpl+oxaI1W5RvNnwmkdKJ1B0R5GoVV/w6t7Nn6qWevNNcfPhKO3oCapZyEno00f3maZSI70UAWUY4Q/Pn1gq9WYaZ9JjosPPzhXo78HHdopMn+jt5etDKrCTYFp1ZrpLp9w0XIa0FKaytqTn08KBQdYXoBdEibCCk4rfEhikrry9PzXFnhqsjbNhZ34Vf75LyVc/zxbX+TqbZxaoKlJyCvNyF3PyW+Hpj49A7V5pCE1A87eVUsvIsKqonEIqJI7L05Vk0tCOwoJugxV9eF6YG/6vFfLQm0tLCGfpsTUJQj1ApiY4a9PlbCAAKPIIX6qIzuPotYLduNKmuLmHynbgk6GiD4OGjhB/tzxV+s8cGrohZc8SknZ6170YeBt0qZ0qXsf+NrpQtQm+/UQxv2u5xvUy6ukIpHfwTHQbviEra2IAMBdqG5w7Cvdojsr6KW+mHwAB+acqP4ImiFj4YHbjG840kzBqtxgUub4ZYYnq4/7oZc8CX8FTnXGjzjglCHm5IOMW33bQomzYgvrswE8dJrptchVJxL66a+U5vQoJV3mJxMpW+7fhADx0esed35rQt5HWuFPj3ulQLPjvdK6tbzwKt2qwWR9VLIFxdajxscvswnFzE8dsDcp7v+h9YDi5XvT8W1+DxROl/rJsHKj24924DeEFRzIXYE8XQjJiBkeIu7S5tNXwDqb8pNGefgKy+tcwJl0anOiiD+SGkIMZgnYyjsrdG/9XQHkDZanHdIx+d2bf++izgZmA34b//60HgV5rbhfzX5YxMdPLgF9E8hmoeHK9NGNqtMKu4B3oMVTePsWLjmEQMvWLrRsUqMH6pnOaM3a5Vjfah+u3vWKn/xA0bTX+LRH9pmCEfxnEpbataU9sM8kFImaMiv0hfXd0nP4/7UBjZ8/v2mJYJdwBx3TX8IX5nRhI2AvpbJQ6xnHT99VQhiq0ww/89Fy8xyslVW1JgTxr/tNk4B63knuOR7P64bzcUFwmGYrcYeuN4CVpLcyoeTPFr4ukvZjBpTHkcq+wiJuLgWZFtYdQ/ryRYE9FC8na0hqPTn7U8X9dCbfVawEUZg0EXw3ENsTLh5TaFmK80ih3M877i8lwR0rEl87fSs+45gUACvpUfsdmHyTIbo3Jwfa7fsXTsQYfkeddmfSv91Qmb/OzRKZq8/QjUx/oRnwUCn3pLDsYiLdyXT6IzUa/JT3Gy09UumNnwugwRlw3xe/43bPYSd1H6gtBjfyVZ5IACLd+HbQvP6F7b7dc8yzQnHbdsQJx0UCD/ms/c1K9/ne0pvOOqucZrXdr4Uz0riGQkSt4P0b/hHlHajBuBTEvl72PRDSEiRcvERZZ2p+3K/umRYKi6aFZViT9+oT3m/BJONTCbHrzyMuSGjhvUIFRQqvE2V3TtooW9LJaSNNX+bwklejIv6JJj8I1Xi0a49twTO/2IJs87Nx7Qvf+prSDTYJvFRKtPvwbU42989LYYBz/XnAwQkrP+/AxaIZ4s+E6yfgKlWrx4bq+fxIr7dHVjRUGb3UvvTzITdAlSKiyAFrOsIyj7uXrP81/KkmhNHb25T8iGw/sNNzXOKFv0mng4Giq0sqUWJea1Fwvtnt8t7s4R66eZODQImgaODy7vbjp2kOwW8zWYAdt/FR1JAm/K7iqP7wUAa9HVn70YDx+RZ6GTRV2LrRO3kvPOCy63JBoGHFhL1uev0Q1Dvlsi/7yQLa6zQffc3MLXtgGjcz3/CR5WFlqLpQhbgpftxNjgX/kQXkJ3XGa5zWf9t3NwAWXbrVfHW3JbOQJn7dqFgrGB/tJ6uathlgnWnUFt9+8vE6QVlpG2n0i1RvXK0Yo1EmTWr9Kj8TXvOTQZ/jygY+6XsU9bDf07KuX1aC7uu/zh7sK/Xr9O9rI36/BHj+bfi4kw425FeX1+eqn97dt68jgDH1AxTzx2dcspqEWYSEQojpuvkS1uQuka/1Q2V256uhT2gULIzEkCx/Qns9wWjLWPh7YNW315ex5od/UHp00uzBGHsDcLyVgnlp9psQ+U04RB9fQTU1kWkKo69Z0M5+/biG9efv78+A0TOCbKv0KrL6YazPUUDYDzrl5DziEl9UAfbAb/Ik2r6Eb3yBATWF/M6c/diWD5+sADnMFLtksvV9A99vH8BaQBYrcO3B/DlhrdiZn04dxkq2uMLbkYRqM36wotN41kdvI8PFT9TRShog5ucN/fV7pDlwsZ91WX6jnbLeHTXw++Y3v99lzluJS7dV0k++5cdwHTewOMtowmX4/CNe927rw2eAluCS7KP5lSM0ogZSH0dYYve2s2w+6bFEgXP9vOK1Cxs057BfnEv99ylHs1B2ZvkBII8/z5ivPRvNdyYpLvP3Eetoj0zfTPjVfWvehPerMtX6ndLB04ofwozXuJIfOZlQKjVVH77wLT4TzY9aau3n79uNRq0FDv0CsfLNJ/Tb6w/VIxtCdrhfm1dXTagyu7UgNh0ZJhwzT/GVZUHQdMzloXu1abcWQcBHXN+1fBUvlZXy90yuWuk+eHoorV0EQnPs1ze7O4fNjASwSk/Cp5icwYYHpGk2Px8388/fvx9gZH/40EY6wjMk3RFmYKXJD+Oa/jzjw39uxn71jFSxt0Ej+qXdmglJg9UQqnjV9P7dAX47iCZ7PtzvLzhSRAJEO0E03il6U2/Kfc2hpfIiGJrxsrKnqQY4g1XC6P39YGP06D+QZ3AGH3MNlGG/UkoP5eqjr8ZuNzEhlToEUs5bKxDs1v8yWX2KW9LxOsVCN35zp/y0YGGGO6S6UbSapfdMmz582mvSF4AfkQDFrSus8kGHihUpC+bHNFKN53CiYkJ7kp1QC75Hr9liR/t/9jsW4zZb7KFu2n6IM/P7CcpJbeEB7yegi7VOpm/HF14+bq1ph9ImCMs1HuH7hUKWR4UOKW/zZ8a6jyB24+dSWvP9e7/nRjNx2gXzywk5aCzvCa5cL1r1K/DPOehmb+nNz1vQeJlF5BAGvq7eVkVGckG3toDvLr2furbusvTtIOWn/rzj/FjJsrw6frltzmBgXu002QtUwUjWrRGDv+JIK50yrC6wWgP5sMgbQvGrb8Pai67vVTP1wGFbfT1Fm/yqyIqrfAXUhAwTma9fjvrfi6i5tcsaCNLH5z//D25NFw0="
}
_RETURN_SHA256 = {
    "IC": "1f1e293de3c93d13a29b73133a4afff9de6ca86009b60096de742898b2a999be",
    "IM": "38318c6c94248fe8fd447e214588fbf0cd758fa6a1cfd0d573e7baaeb6c86fb2"
}

# Official CSI price-index closes aligned one-for-one with the embedded formal
# return dates. Values are integer cents, delta encoded, zlib compressed, and
# hash checked before charting.
_BENCHMARK_PRICE_BLOBS = {
    "IC": "eNot2gnYjVX3BvCtZAiFMiQZI0nGpAjRQMiYhFKJRIqk0PBVRGRIMqbMEiERGZIGUhEKhTJUMkv6qFD2/7e/87+u91zvOc+z91r3ute91t7PPmd2/txhc5EQTn8R4yvdQmjZMoRCpUJoeG4ICy4PYeHkGKvUDaFi3hCOXxjCk4NiHPFtjHuWxdi6dwiPDA2h5m0hnCwWwn/OxPjk3hjX1gnh4TtDGFUrhOED2fO5+YMh3NI/hLsqh3DH+TE+XpbtdSG8MDGEV/hpejrGv24JYcrmGBudivFA4xA21g6h3K0hrJ8bY/ZmMdZgc12PGB/YeTbWKhRCLZ/X9opx2IdnY9XCMb4+I4R/68T4brEYZ90cY6tvYnysQYy5P4nxu14hXDo4hGILQvhOPKuaxvjZTSE8NS2E0ZVCeKMcDmB6qV0I3TfgImeMb6yNceGrIVSdHWPDX2I894MY/30jhB+/j3HgUbb5Xzk6hKK4ab09xvtvD6Ff6RDqNxHX2bOxGuxlRoi1dYxZLorxnGoxlpga4993mDMuhG8nxJjt3hg/Z6t6jhDa8b3x5hA+3RLj4othbBnj80/h/7UQ2orl8KWwtQphTb4QSuO5PV91343x6atCeFtOfsweQoX72RZHaf9HlsDxTzGebhbCdRVD4CZurCDm5jHe3FE+xX8ifwhPsLdwaYx9cDrlT+PXxDhZDn59SV7oYGT9EHaXCaFKbtyVD6EUO3/wd6v81vs1xi820kOjEGrTzar9MV5XIIRO8lyKw2dq49G8X/KEUPx4jC1uDCHrwRjvg33yQho6IW98fnIgxmU1Q2hVEN/G/9swhIdg+J7NMfT5+O4YC/8NNw3evCTGVbg43/VNfNfKEWO3H2JchLtmF8d4E4w9WuEa9j9o59GmISyZGWPjkrTaOoTL+F/yZoxv0t1SMT9KW2//zL7cNJXDdbi9lKar5gzhGdxONv75LCFMaB/CAT670+oq+XpRjNn+S1swDa8f43HXOg/l1/XKj8BifqPPYryqWgivZw2hz+cx/rAjxmPmH6eNK4/EeER+RjQQqxzNF/9UXPxDT8u2xZgHtgG/4wXXtWjmCvn9gr/b6bfzBSEUEXM/vJ24Rn4Ox7gcp/3xVx5vi2n0lfNDuHVkjOneHhizmrsV/no4X3QyxrJnYzyf74MhhCby00b8B+bEWMb1/7JRRcz11PS99HTHX+aqo5+N235JCIcu439fjHnZ6ZorhBLmnGS38t0h3MnvO/w1g3eQ15P/0oD5U16T92xs0kojnyuw1RJnpWnoFOzB/J/k4ci14i+sp+DsNhhaw3COGl0o5n1sJ+6vpYXj7jek8YJqZZBcN8fre2x8lvx6/y7+Pxf7KT77yX238TH2PU8t4LQH7krjdy7sI2Ft94c80dr3F8mxHFz8I90UDSHHdbjhcyKbX4M4ip+8cnaT/8+cE8Jz7Idkgw8tJaZ66eLaw2y8Ib5BV+gp5tWB5R31cFjfLGT8zGMxfoXHK82Z6/49cl4M5rFfx7hCPX6Ns+/Z7GXsUrVbCsZXcPyNsecYd5Ymh5fJxFkeRznweRF7d/BTQp4Ppn6qFsea87l67ABTBbY+Mq4H3N1hm0x/o/F3hx5QTs0dN/cJtv75J8Y5+JgglofxcSNOt7g21fxseOhjXl33q8A0is7aer/fvOtpK4+xy/gehusOxu/F9Wnj9srdTtivkLe2/C0X30zaPSOHi7xf7vplNNfU5xY0vBv3X7NZlb6K4mMi3OvEc9CcJ/Bf/mO1BNuHfN2C6/HWnwk+387WODmuY05/9u6jjfdxcEy8T8LRQuxLxJrb/xbsvQHLJNw8an4j84caw0XcAetS13vK/QB5uBSnl4m9Mo4bm7sBrifk4E4cPUpHHeAowvd9sL/EwK8w/GTeAhi2ienxPBluavp8UKx58Vac7Ry0voDd3l616bwP3T/Mb0s4Nuy0dulFWfTNN9TIHnFMoqHpYh+tBmqyf63XDHPn4GopuyvwdOUu/dA6WgfnS61l22B7Wf7elI926ig3bMf5eEacbYwdp4c+Al9pXI0x9l+vR83vDssBuswN553WjWF8nCeWC9V9OXzNM64jbW1kuy2+F+Oia+pzbJ4H0xjan4DHvrjKhvNbYL5DXPnw0AXvWYx/kea6wL1ITkeyP0k8y8TQW3+uzn9teMeb8zQM2WD5gM+meB4ttoZs1qHfQXjrTYP/ZW8irsbC5i9UNKYcrf6rptrqwTP4H83H43zv5PNn2C+H7TpcrPwNR/T7rIlj5WiheKbCst+YQ+xskPPPcZQb/wVTP9H/NsCxBrYb+O/Gz0B2j8ORhwbG7onxbtrfb93KC2dHsWSB/YfUZ80dJ57P3C/Oxia6m6jfDPd+Djur6bKd9a2seCvjdggsnfD0u57xnH3AUX7KG/soTdxDgz/i4AQcG8X/IFvvyPMHXjvcO4PXfOJuvCjGzWxewE5n8b22ilZx0Qm+I/Y+veRryCF5oIGpOHzPWjWGzYe974GXHnw0x1MDWMbjogQesov1POM/dL2RsUuy/P9aKcYZ7qeeUgnWr4uHkLh+DCbbqHi7/1v9f1z8m/idLAen+Jtl7HY2R2TP1NODeNrDVzu2n8Kx5TdUYaATP4No9uIF+DS2Ky4qDNf3jR3KT7t5Md6hb38pb//IVU0aeg0HI2lgsLyXoP+z6ng1XzlwtgW+w2p2rNie5nOBdWAlrufReRf8rzfud7bTujKJTi6Ct/nAGGtfbc/LZmoYOeT3Gna+Ne7d1HfNL8r2TzAc4/s6NkbpUzXFNXATvMY2w9NEcazG2YVpDU+1Yu93MXxfiWmCWFKNHrSf+YGNgjh4VH2toZHFbC3B/Qi5vEo9tXX/Etot5H8xOV+shj63lk6DtZq8NlrNrp56UD+pxWY/a0cx/WSb/Jajo1H+b9bHGqjd1KPX6E8t7D0vp+UOkvUu7TQWwxqYy/P/CZtD7EPK8rXOmM587frSugf7HfZMLeV4nT1M/eoh3E8Hz+Kxk/iGyfntOPwbX6Xl9SHr/ij5rM/2cDH9gfPOPj9Glw35LeZzRVi64bkqH2nPdYHamUfH14j95HcxzmBvDtyj+LxaDINh62rMCHwVwd0gmLro36vNH0Wrnc0tgLuJPg/G0wP4uMD8mv4PgHOGudnF+ApeFsjTDmPfwVU2/OVhM6v5feT8A3r52P6ur2u53c/ZP8ZBclEJJ2U8D5THVVF99EsYSjfXR/SE7ezPM96WLl4iF13V+KvqqxWft1kLSoj9GFtpPa8E8wx6qaD3noLjpLxko8+2eBtGB8fWWTfpe6Hx2VfYz9HMLzR6Nd30tM8shPeibF5HEwfxW0OPYTJuxkF5uizufV/9YhQOnzZ3F/43imsa29+KI5v41uKhJZ7HqueZtH2ATgbC0cye8EZ6WyiWp7Nm1t19/B0z7xM5OOB6Hs6uY6Og2J6Ux/3mf5l6kfmT3G8FR2t1cgtsWe1xuuOpKVzP4HmpOJ5na7NnwN7mKcmwAHfljGvxUAgr+PsNR7+61xGHI+hoMK2dQ9fr8LnFvr+JZ9k/7fGXWwNneE2Ha0gNuoHhBfO/5OdTmN/TU4bI4/vyPEXu2nkOLWLuYdxONWePPM7CTX5xXmHeMjUb4K+ibhvoLYGNhmKdZ9yf1ux9uK/E1nDPjS3wd49n604w3tApxhv0ndNqcnPSj+eVimzcpCbaqJnuaT3Tl0fh5wP71SN4GUP7W9huw09BvodwVwQv99HFreZW8uoHy99yWE7/3MpmeTkaTPNH1ND2xLl5JdXbI7g5Bzcls2TyWu5MZm35kI3+nj02yvMxtbTL/71i//FDeMV8I3soCW+l9ZCdqWxuo7kNaqZ/0rg6f47vSrR0i7y95L6tfiwm703EUgP+tuLtwE9HY4fhcpJavV6dFhTnWHykvefupA0+BnmuzBMz63l2tryNd7DRXw3sp4E2rt1Lj2NwkpVeruZ3mjjamNufhtL+6gI297J5HhsX6SNMhrXGZcFLUbYmuf6AZ4AHFOJmMXxAnx7nQyF5WiPG0e4PUWsT1Wg5OpvHb3f9YB3OGquvrDjp71pl/ovRXla9ZLoYC8vNcFhO8j3Nvbp4niavc2CqpreXhH2qfNzm3nFcdzTuNmvrSvPIJH6oHhwdxF7GT8PH5fJ8nTmF5aGGzx+Z2xrXn8H5gliGm/8cfDmMuwTui+g97R2msTU27XVxvhHndxfLzL+Y3870NqBwZl/XVx3POS/TMx6gzSbi2KAuatNAVnzX8b+qmC9O+fT+FnbKWd/KpPMJz+8zbrN3lMOvq+ipznnqiv2MmumM/6FsTziaWQe3OGs4yv5AeLrab1zDzib2J+DmA7V3vvh+HIIfffJ3tofAnofdXnjOOl0d0ecoepuutua69trEGN8xZ6scnhHTOeI5rN6O03g3ujipt3yG00Jy31t8LXB0FsbmKXY4t6uBr+jhWf15umsz9ZUbcf4dbh3phI/Yq8JPQfG0ZaewWjou39Vd82gTp7KVX3yb5aOasS+k/Ul6BpSPdXJeCtdTzTut3v5Xpzj7yJrwhHH9xF/FmFXszWR/uXV0k5yn54oP4XoAX7nde58u9yWcuDwG0zv8/mzuXP3/de8n4umL9Gyj5nLJ/zjjvrPn3gzH03Swln7PdQ7UAs+LbhBz7UxeL2/jXMpakP0j3AxgB+bKzgHq4bGrtdxWIS628ViNt/VyOdP5z0zczBLLCNyNoNG2bJ9jXFVrWk3zHtATF+mjT7G1kP5ukoOBYtvv+gLXx+E67a/WpvVDL34H9kN6XhF5eZiWPxd7Z/0g1UQX+4gC8tDEmjZRfrbx1UbMzfl5X08sC9d5ePhGH/lVvz0fT4/YP57CWeqnb/G1lZ/pzppeFddZfFaBuTgtfqz2X1TTzWixF1xX+txdj+2ZnvdgmAb/OON3Ovu7mzaHyHF2Oc5GH5XkLIe4crBzl3WinBzP5fMh/N7u3ji5miUX99JDfxh+Ts/94l+G88/k5Dx6aHil8yv2m6bnT77a055jwDhQH8ohrjV6xL3mjnS/pvEL1WIH8+eal87lnpKfc9TzFNeX4OJVfBXFd004K9uP1nE/rQf7+HgDlouNbWbxPADzctzUw/eeMpmzuHxym9W9M/z+xt9lfPeGqaZGdJde100OsovlTnnphbObcT1Er5pir3obLRw09yOvXWwfpL09anMwu3fZl/SzT+tn3hK9Mbf9ruPOMFSOsnuVgrm6htwGxjxHM3vX1daDP9K5AL+LxXKNWs+nF22EbRct18Ltb7Ct4Oc5MX7v+mM4/eP/62WCuP6j1p/HVRvYFuN0Nux99JCGxqyWp+3mf2JOGVp+2LXTdPdDOtOR3+4+PwFXKzmv7v5P+uFT9PFr6kG02hHGC9VYXpz/wFc7dgbQZXr+vwuem/n9FJ/VU59OGjT2V/6Kiivtresb103OnpHv+XrBX3rBM/JcF4am/q/kd7z/Tdjfxd5+8bUz7n3366nVImwugKNremaH7QR/WwukAxXPswUzY8vmyexPsrExEY4xcpX2l3n5LEhf39BPkKOn7ZMaw7NXDZWUozx0c7+YR1oPflZn/b2qs91XzEPY+wL+up/KmfzcQyc9U58xd5caaorjt/k7JvZb3C8m3gWwPFchsxf8G0f5PItNVvvzxF9RHnLDdK6YjsNbQ539plfPF0NN8ZenlTzzPQ+x08Q5b+pj1elZa4//6AvPuN4Lzkr4L89m95Qb907JyQb56mld6ZQ+i2s8jq/l8w99oxctrcPxHnGd1csX8v2g993E3Y/v9sZUxvEYWH7xua7rDeW+gVcfMR/HQyU+3pbX9Wi/gK1t6usmfeUSPs6KeSceRqqtNbDNNq4YPpbgoIyY89NkbnuMeZ7fL9AvhorhVRiu5nMW25Xl+wI8v4vPI+bl19cHrs/s39aL5Uo2c/p/qfs3iSudbSVu87v/9m+Zs7F39eLsdFxohnzL4dnl+qgeORimSXLV6YpMz15MAx/qVzVdG0cnvj6Ju70fIqatuCkit6XkoRl+boDxEjroK+bdfN4Aw2g5a/eWXqG3LbbfKi73VWjryON6nbPdJ/T1W9lLZ2cexeNkWA6Zd7cc7BFnNZx8rD+0xnVv93KKv5Se8S8fJd/Xu+D9KJ33029N824VU6XUy4wJzjHekpvTjxr/FYzOzX/0eWGLEP6WtzMwPU0XO3E8E4958XOaRlan5xv1ON3Yf/gcrS+Vk/Nczrtf0G8ay09vOkv7qlQ3/+Cki/jHiC9p79rcmb39Sp/7svVA+s5HjvvCdhn7z4urjHiOy006b3iWvW78vEq/91rvysPzG/5y0VN6Xpxv39Ibtzn1v/l63RzryXB81Xdtpb385WqyOLxN0vOe3Lagk1oHMzl/Omfm7O9n3Kzi+3N5voIGepk7B/eDXauSPaPtb9lZ83fmvPCj1MPUT3ua+IW/KTANE8tp3/2k89nnXF9ED4/5X9aZ2Xx52mHOabEPE/d+PSNda4PfIWJpREN9rRXFbBi2q4O0Bz+a9iLiqybXfeXwEX2gWtKG3HaDvzO/edV5ET1oJ3v7PI/1xeX36RxHnPP5LuX6KHvph/SZz2l2hvq5zrn5L+K+29pTUp5Hy0k3Ni41troYPpGL763lRdl+zPhV1suWPleRl6xs+low/qT+KqR7cvawe7d6PSiuLOYvwsuxvzPnks/KfQXXLhJjO/ppfzzzLFuSnTI+z8HBctq7SjyPuH7ImrXT2Br4HCmW9caVP5s5j/qAzmZ5PxvmxMEUOb4B5nS+/ljIjP+EVgalcy4czJK7B2F4Eue3uvaPfM+C9x1cbMPxZvHswfv7dJQP3g7irena6fSdkrqeTYO9xDROPleKtbbrnf7O9KbZxnaXo+t9vhKGQ+zO3ZI5Qzic1k39Yw7NNqSr1bR0k/wNha+AvpcTjtQz87O70LyxKRax92DrXDGdgHu/PlhArCknr4vhKDu56WkTDW23BrU0LgueW6fneHP/SmuV75QWiGuC9eA++b0KlpfV303m/EAPH7PzD37TGXN6JnrStSeLZPZgHdnunPJBb77SjD3c+8L1EmJpkM5IzSkOb/o+4lGYg3re6to4e8ouPu8Q118pPrzfzy9zYYI4gtcLbKSeX17P6WV/+I0et9ZnXyvGD+QynY1ciPdheO0slqfkJ53RvZIv0+dX0cISfnOyswq+Zfz2EQd6w4ve56DrS92/AS8XiHe0eeUAmAZT4xyZM9zr6e5+WpqntvfidLW1oy3cL7u+SZz5YW8o59+yu8X47nKZB4cF7dXGWCcaeUb5xficMPZme4e18SSuZ8HwsV7WHHeb9ekX5ayZXG2AJxi/W1xjxDSOnxXw/UFrPX2ulPqJHHbDVS2fr071iY+2eTNrV1faW2FuB/7bHMjEdgh/hWG5F66T4uqgH95QIPOMns7gb6blX+jyrOt3p7UOltU4G+/eu2rg05yZc9Ju8E0y/yJxLkq6F/Or5vXhs1+qNeMKwZD2eYOMO+H/k3rxPd47xohjYC5GNwOTDNTtPjZGwLdervams3SYB7D9iJh64mCRMTPFGq1FpWmpgfE72Axy0cw+owsNpfynPcFCHBZO6zH+dsEyR+8sJpZcclTHs+tl+BvG9zPO4qJr9eHaa/5++dyd9pr2Zl/QWFZfFE5+MrMHm8qXr3nijV6jaDjtkdN53c/6+2xr3CjPjK/j5xu6GH48o8uRcNVRg8v0nFrwTGfjTvgO0W46N7wf18dgrinG+mr9kJr7K52RWp/Sd3ft5ekP/boKTOlMvZke3owuZ+O6ES4602I3Y4pL+t7r7Yn4bkNbL4lpq3x3ltcR4r+AjeH6b1e4yns+eAi25mzcZp2dBU96rrnBuD3pnNbn+ny3FcsY3J6G5ynr3yFYp6iz7sZ8SrutYDItDuHvReOjvG0wpr7rLdLzcrbMmUxNtTwX9oZpr78/EZY546/v2eB99nPj55C19xM8jMVLDvr5nQ7KGvcQDEv1vJ60eC19t5b7XOyX5fMt4+ernbrysJ79dIaT39o3Cb4zYlnsGawOXm/G+SV+O/C7OTthPKM+a4vDT2XCALoqlb5XNfcAvIvcr8Vn+g79kBjvl5NKNJQl7YuM/Z6Gtopxm/dvsrFMTzkF+310n87/HhHr5WKsiBjLYvjG+O/hvVqcs9jra85D+E05Ke03KXer04+crxz1W5yhm7W5qfY07fFpfE77oLespznV60A5SM/4bRyIFaDtjvx9Le7xsDysVx3GYRX1cgTHH9PDTu+P4qq/Z+0H03OZ/Legv3rWod/kvTv/hazfB53zNKS53vaX69LeEg8V7VWbiKU9DEvM609LO/C/Kf2WIZ2ppN8u8H2l3tVHTkbR43/M3aRHX6vf9ZC3LUkLaqYq33969VNff9H7S3KTnklWZM1873SPRrAMjn3qzpYp/iftF//MnN2nc4Qdae9j/zr0SKaP3oqv9EyUnun7y1EhXM7BRyta/9L9K5A+VW03h+dqOSiJm2fx1g5ffgYRNtLc7WJtA9Nu2m8gnjdgzYm/y9j6fWXmjLS+WC415jAOl9IHGce6dFEPrs346KqWLqfhPXyOwMGbfKyH9xf327PjJ1RhhPufuV7nYObcqCct5MPd9jL2frgpiNuVsIxIv6HA4QPivvK3zHr0OH3tS2ertFMVBzPFkn6XsdT/MewMgPEBuUxrUGUYZrF7qRiai+cbOq6vZmzjwm/sdDS2OBtv4/4+PKa1Ip05XS3HjfFzxLXb2KgHQ2ExHlYv53nfUZxvw708fX+G3zXsPGhejvRdSNIQUl52fyNdrE1ag/8EOxVxN1h+3hf7RP07fa/wnld1ennJmGGuVcuXecavGDPf9Twnh4vgKkK77cx/jp8tbKZz5fSbnbVwbWLvWRzvgvskDdWghbIFMmeEL7o2Rw9qDmMpeHrY01bW2w+UzezDuuNmDt93OzPqWlUfwkdb5zC5nWFuSDHzf8KeeIxaHkcDFf22Zwi8rdVyTRz2psEv4Dgujv/Cd4qv53HSRz7SM+tb8vZjjczvC9ayu1Vuyoiljfotxe7LNHEena9I569sfufg8Cg7TT0LzE/Pm7RW1vtrK2V65hzYv9KnpspZVv5zefarlX63Y0wu3FTn5005LypHq60/VdSPcogX7s785udG2J6a4pmFj8fVQwHxTk41TVO99cX0O5TvYH6EnRruX6Y28x7J5DOdwaX9RRW+g3puVT2znn0v5umupz1ydbk5rFa/lodT/OWT03FJl34j9pZ1cIM+/jq8bbyv4HeDs6wfp2ntFtqZS7PjcdZCj79QXxnORslmme+9n5fTLjD39r63NW3ls3qf89It8NfzTJN+Q9DFGWJRdl5Nv/3A5yhrb292Jqj9sXAMveJ/P1uK27qrPbU5CJZ/1P/DenkR31k2SM+dYq+Hs1mHMjWfzgtb6rcNrPsNnL9WdC47yBnrn9bhJmUy34Es83zxo/k9PWsP1F9Lqtuio2CTg6k4bcdnDfmbzHYJnLVKv+fBa7P0+xr94l7+Bxj7LyzpN2cF5XgNzlrf4/tZejklpp3OZYK8zuGnsN95Ltf7z/K9jn4vFttUe5cOsI2zj2zBz+XwjaffXr53n+2ZtRcuD2ogP4vxY5xPfsXa5/eJJeQxB4H0h7PLExmOXlILf6vDx6xDb9JmY+fRpcXaXf8/QGdlfN+WS0y15eAEzLXUxoPW14l4m2m92kXXlzymTsX6o/1VDgd8HW16ztg35R+vFujpelqt+5551t8VvoCai+dcvgfMSScn8XE/baz3W8DdcrlXLabfD9Wizfsl+r9qOP1G4P8A/eWTHg==",
    "IM": "eNol13mcztUeB/Dj0tiypSGyjRSV9Y6tyV4ZDa6EQmUqt4vK8pKU4spyb8KUFpQsI5WkmMSUZZLK1pV9JwqjrqXNXErq3Pfzmj+e1/P8zu+c7/l8P5/P93vOc2J1qfDskRgX1wghpVoIeyqGkHouxrlXhVBlUYxf/xjj5RVCWPTXEBakhHDT5SHsLhJCk1oh9D0Z4z3JIZQvH8J0Y/klQrh9Z4zXG9ueFMKhmTFePB/j8Z9jrJCY80OMqxbGePiXGHtVDuGly0JoKe414pcVa5g1GZdiPHEsxl3vx1j9yxgbfyOevQbEGF//Swgrt8X4kbHOTUJ4aFmM31kzcF+M9TfbC7Zet4Zwm9jtWoWwsUoIyWVDGHfWGjkVh/GXUzHWvRBj5WbmFMQ4UI7TrwzhmZvMld9zcG5qEcI0c5f/GuNrPrOOx/hBuRCOw7/8ZjmeifFIsRAqiZVsz+f34uhijJnFQ9gJ+wBrPqgbwtA/Y5xdFW94aVEmhA2/x7gk4DDBqbl9cLPpuxg/972uVAhjvo0x76sYN4s/8XSMFffHuOF/Me6pH8LLdHnvv/D+EeNqa5+BsSxOKsrxKzzuEz8P5obWlfZ9Sryk6vjFWXkcLaBnHl7uF+ce6yfdGMJjxnfg+wA9DsljC56GNwphBTzR2nlFxYX3J9wetfeoa0KoZ97Vxt/E5yN4vBXWH8UddkUIVfHZWc79Sofw9qYYq+F+qvXlD8EN39Nyre175q4YU82vj7O+tfEoZm1r3rHtnbCV+T7GyTicZO18/K2ly1Q4Z5rzoL1+xXFyQnfxd9NgG/3q4OXIbzF+CFdvceaviLGefHpthxH/WTAnw38j3bL5JxkP4w/HWFOcFJgbqoF/Gdt6Quq0bmWvDrD8W9x5+TGWhLUN/fJ4NdX3Ie9PWlcT97XsPxvPyXKeYO/AJ2uMTZRrTskQLveJfo9XF2P8bi2vGzbG2HJrjLlyexXmh8Qtweet4PvDnHx5pcnnRrFqiD1RvL4H+YLeY+1blS8eg+0qc/ocxavfl/lsrxfCRf6aQZeZlUL4SE7LcZcF8/18cRGOz+zXzqenOelip+NovTyepPHLuP0ex8X5cAYdHlYPv8I5w/vhe3jF84lOIZSjWSrf1BbzC7zuF28vz3XeHeOjeOtWM4T18myA6yzzSsvrtLk9+LM8XdrAWLxBCG3kscnaXbSchIOZdH9BTi3pMstzAx57Dq6z+M9W59P0iRb02Ko35NqjI6zbYCl6fQjV4Bip16yR6yNqtjdvNW2sbuF5lwfKeXeLd9/RYab9vsXzGp6s5bm6z1mYrlSDLXF8BqeP4PkpsbvxdUMY78LlMdgG46ux8X3eV/ZcVd98Vm6b8NVIPh1/irEMz2fhtoIazrHXbLhz8VFb3EHyWnkDPuDvJm4R8ROa1dRHem+J8Stezfecc10Iy2CuIveb8HLb+kKPlxFr4CS86dmn1PXYW0I4jNN8dZq3gQ/0xTE4v3s1L74U488jeO4OfbFLCO1heRi3qxP9xvrzsM/h5brNQ3hqvtw766t8c4f3LWg1Sg4jcdJMHc6+NoTXzf0Bb+ninzOWXEdNybcRf2qlMRufGbxzAN6rVsbYncZlaVSsIf5x00quk3FSYG1z38UvK+T9or1WC9DurhByxUm/UBgj1ZqydOyIk1166jjnRU+55uEvja73fo0buo+wPiXhLbqsVjtf8HwxPexqfp9Klzr0GcHH4+DrTOt8nupg7IFEjfHGYHV/X+nC+t+gP31jbAWdDuLqIA3YK3Qx/3v+X8V/Q3lxKZxZn8TYTf7N8HczX4y0f4Z1o/FTYPwYTavxzX3OxY5qc4ic0nFy2r5/U3/T5PWL/F+0zwS/U/D9JA8kwTnbnnWvdm6a+4r3x9XdZv7tZP/NCZ94N1zNP8mHb8O4DbcNaJOCn/lwHjZWTcwKPPcNn52Xcz85HEoq1LatmqxM/x/0oEZ6y3R9LwvvFXikO83TrFlhTn95toehK17H8+JT+tQcebSHdS3vXSHf/reH8MQ/1NVRZ8OnfNIxxilqsOYC9dg1hBl6x2L7fmxdm0wedP6UwHei78yRfztn3BEkzzvgrKFZUd5v8BH/qt/MHiEM4sf21jxD83xne9Cva8NU7ANnMs+XVBu7jV/p/BoG87i3YhxBw2H0zHLWpyd6Hv6zxbuAwxn2Ga/+/qLW8/F1jufvxkMu3pr+h7/kv9P37Xz9qHiJnjBWPT3Pt5vFzPHc2/gl/nyaYduvc69Zw/sw7cBPQ1p08b4szy2VY8cHnVE8UVYeq/C8BMfp8n+FDi+KMZefSzmPdsh9YRtnt7o6xr+l8HXC7z24bGLNl/z1nDpv5L5yJuFPvG0Uf4/9PlMnnZzd497WK+i8BY6v7TVI/pn2uN68YtYX+D6h9j7FR2N8rsHTFBwMEWOo2u3uzHmDN4fy0iz+6q9+VtJol7U/07AKLCdP/xlrwLoR3++m6hd6yU54h9j/Vty9Zf+zarCt9x/y50Zzz+tbQ+w3m7c74aGDO0CO+1QfHk3cB+5w9vSlwcs4fMfYAjXWE4dvmLtFDb3Ke43FuM68dHmVw022/crzzYNiXqLdOnrVwssT5u6m0XyeXyaPm3m1B880MWeRnLJ9zukdRRJ3Q9jHqMk9/HAaB/3pUmDsaKLm7Fcg72rG9ybOSHNugy/Du676yChW/DscE+S1Ti0NTNSxfrfcnj2tWUK7a+2d4vk6uO5VQ/NgypZfKfW7WN77rOspzly59JLLUrF663U58CW7553SO8uI8bhe/ya/bOeVfXQfry578EIzdbEC1wO8P8CLTfWcW9byTTdnKg62yHsuPbp0COF3Wl8r9xl8vNX+mbSqqE+UxFuqszrdvboBr4xQr/VgSMFDFnwP7Cqs/dVqrZL9apo7erG+bd0FPpqWuMPQOVHXn/BBDo5q6Mv19Z6hif8FOCzCcw/g9jcaV4e3j/E0/WYtTpaLsUy+P8k9l74teO5j2oyaHuNCvp6Mx4flOxFvl8Qfa98MPnyLPmCGhXUKtRnEp1v5ZaB+lkSHvXzRXA3ux+vcxNmtzpfIaaPfE3E4UW4tzH9BT0jDUXN7FLig9ZNHS155HH8veI691czn+inNX7P2EPyH5TRXfveZUxn3pduqN9xP4oETiftLok/j94AzOP0euYqdQ68s6xukO4+SCvv5o/Ipge9Kztdh+K8u3hDatBa75xhr8XDGnH5wD07cB9V+O15sTqd/OnMO4j3Vffc3c7bT/7B8Nw12z8nQb9N4y51svfyH47se/fq1dL+DoxJf1LDPPBftV/WmP61fkuCC3844uybDUsnY+2pvQOJu6ezN3YED/p2gnluJO1LdNFaLrd0bFjsDB1pf0bon4KzfVM2vcl7Q4j29awodbReGTtGL5P8OTGliJMGygFem6lt16TVGvFx1kYybyvh7fpZeda+7k70XwfUjXfqP1rf18qX0jPi6SP/RzovuNF1Ml67+TGTjZcOdapfX986hr+fq8u+Up4d87E4HQ1uefDdTTeqRlWnXXYz9GTjNibHEY2rM+76wn3POlKHhSeOnxSu63Hnov+bixP9e59tkZ9Qs89rguzWPRDWVSc/X4K+QHML/AfynN/U="
}
_BENCHMARK_PRICE_SHA256 = {
    "IC": "967d29bba051421913175bfc9e508fb5d77f221dc850ac06ac149c555c0d1e6a",
    "IM": "8a87af444b3f897d753b47c7488ab17e9f5a8ceb5f1064c60c392c6dd86df4ce"
}

FROZEN = {
    "IC": {
        "sample_start": "2022-09-19",
        "sample_end": "2026-08-14",
        "cagr": 0.3397479107,
        "max_drawdown": -0.1579485749,
        "score": 1.9028254521098469,
        "momentum_120": -0.0341337446011426,
        "core_contract": "IC2608",
        "total_units": 1.0,
        "grid_on": False,
        "put_contract": "510500P2609M07250",
        "put_qty_normalized": 26.0,
        "put_target_delta": 0.50,
        "has_call": False,
        "price": 7990.33,
        "pe": 29.84,
        "pb": 2.49,
        "gov10y": 0.016964,
        "erp": 0.01654806434316354,
        "dividend": 0.012311012805329868,
    },
    "IM": {
        "sample_start": "2022-07-22",
        "sample_end": "2026-08-14",
        "cagr": 0.3178445916,
        "max_drawdown": -0.1498462179,
        "score": 2.0733984122074,
        "momentum_120": -0.0568623871989464,
        "core_contract": "IM2608",
        "total_units": 1.0,
        "grid_on": False,
        "put_contract": "MO2610-P-6600",
        "put_qty_per_core": 4,
        "call_contract": "MO2608-C-8800",
        "call_strike": 8800.0,
        "call_expiry": "2026-08-21",
        "call_coverage": 1.00377,
        "call_delta": 0.00650,
        "threat_roll_count": 0,
        "price": 7769.82,
        "pe": 32.53,
        "pb": 2.46,
        "gov10y": 0.016964,
        "erp": 0.01377685459575776,
        "dividend": 0.009203691969088101,
        "relative_thresholds": (
            1.9763424455071,
            2.09523542263064,
            2.28601924893132,
            2.32518798514896,
        ),
    },
}

# v1.3 is a separate research candidate.  These values are the audited local
# schedule at DATA_CUTOFF; online signal queries roll the state forward by rule.
V13_FROZEN = {
    "IC": {
        "core_units": 0.5,
        "momentum_units_per_weight": 0.5,
        "momentum_weight": 0.5,
        "grid_units": 0.0,
        "total_units": 0.75,
        "put_delta": 0.3125,
        "put_contract": "510500P2609M07250",
        "put_qty_normalized": 51.0,
        "call_contracts": 0.0,
    },
    "IM": {
        "core_units": 0.5,
        "momentum_units_per_weight": 0.5,
        "momentum_weight": 1.0,
        "grid_units": 0.0,
        "total_units": 1.0,
        "put_qty_normalized": 1.5,
        "put_contract": "MO2610-P-6600",
        "call_contracts_normalized": -1.0,
        "call_contract": "MO2608-C-8800",
    },
}

MOMENTUM_RULES = {
    "IC": {
        "ma": 105,
        "days": 24,
        "weight_end": 1.6,
        "formal_start": "2007-01-15",
        "nav_decay_threshold": 0.06,
        "nav_decay_scale": 0.5,
        "annual_cash_yield": 0.02,
        "cost_rate": 0.001,
    },
    "IM": {
        "ma": 35,
        "days": 18,
        "weight_end": 2.5,
        "volume_ma": 160,
        "volume_ratio_threshold": 0.85,
        "volume_warmup_passes": True,
        "hot_score_threshold": 150.0,
        "hot_scale": 0.0,
    },
}
IC_MOMENTUM_PREVIOUS_RULE = {"ma": 110, "days": 24, "weight_end": 2.0}
V13_GRID_RULES = {
    "IC": {"entry": 0.500, "exit": 1.000, "units": 0.5},
    "IM": {"entry": 1.600, "exit": 2.000, "units": 0.5},
}
GRID_POLICY_REVISION = "ic_im_or_fear25_paired_exit50_20261008_v1"
PREVIOUS_GRID_POLICY_REVISION = "ic_im_im_grid160_half_20260914_v1"
IM_GRID_RESTORE_EFFECTIVE_DATE = date(2026, 9, 15)
GRID_POLICY_EFFECTIVE_DATE = date(2026, 9, 14)


def grid_policy_revision(signal_day: date) -> str:
    if signal_day >= fear_grid.EFFECTIVE_SIGNAL_DATE:
        return GRID_POLICY_REVISION
    if signal_day >= IM_GRID_RESTORE_EFFECTIVE_DATE:
        return PREVIOUS_GRID_POLICY_REVISION
    if signal_day >= GRID_POLICY_EFFECTIVE_DATE:
        return "ic_im_grid_half_20260913_v1"
    return "legacy_grid_1x"


def grid_rule(product: str, signal_day: date) -> dict[str, float]:
    if signal_day >= fear_grid.EFFECTIVE_SIGNAL_DATE:
        return {**V13_GRID_RULES[product], "fear_entry": fear_grid.ENTRY_MAX,
                "fear_exit": fear_grid.EXIT_MIN}
    if signal_day >= IM_GRID_RESTORE_EFFECTIVE_DATE:
        return V13_GRID_RULES[product]
    if signal_day >= GRID_POLICY_EFFECTIVE_DATE:
        return {"IC": {"entry": .5, "exit": 1., "units": .5},
                "IM": {"entry": .9, "exit": 1.7, "units": .5}}[product]
    return {"IC": {"entry": .375, "exit": 1., "units": 1.},
            "IM": {"entry": 1.6, "exit": 2., "units": 1.}}[product]

# The immutable formal return blobs end on DATA_CUTOFF. Performance queries
# extend them with actual daily marks. The 2026-08-21 monthly reset is included
# explicitly: that day's P&L uses the old holdings, then the audited close roll,
# option reset, and transaction costs establish the next closing state.
LIVE_CONTINUATION_ANCHOR = {
    "IC": {
        "core_contract": "IC2608",
        "core_settle": 7949.8,
        "put_contract": "510500P2609M07250",
        "put_security_id": "10012080",
        "put_mark": 0.0633,
        "put_qty": 26.0,
        "put_full_qty": 20.0,
        "resize_day": date(2026, 8, 20),
        "resized_put_qty": 25.0,
        "transition_day": date(2026, 8, 21),
        "post_core_contract": "IC2609",
        "post_put_contract": "510500P2612M07500",
        "post_put_security_id": "10012099",
        "post_put_qty": 14.0,
        "post_put_full_qty": 20.0,
        "last_verified_day": date(2026, 8, 24),
        "verified_momentum_weight": 0.5,
        # The 2026-08-24 close signal executes at the 2026-08-25 open.
        "verified_next_momentum_weight": 0.25,
        "verified_grid_units": 0.0,
        "verified_next_grid_units": 0.0,
        "verified_put_qty_normalized": 14.0,
        "verified_core_put_delta": 0.25,
        "verified_momentum_put_delta": 0.0,
        "verified_total_put_delta": 0.25,
        "verified_core_put_driver": "MOM120负动量下限",
        "verified_momentum_put_driver": (
            "估值处于基础观察档，目标0%；动量袖不适用MOM120下限"
        ),
        "verified_call_contracts_normalized": 0.0,
    },
    "IM": {
        "core_contract": "IM2608",
        "core_settle": 7740.6,
        "put_contract": "MO2610-P-6600",
        "put_mark": 53.6,
        # v1.3 Put covers only the 0.5 core sleeve: 1.5 normalized MO Puts
        # times the 100/200 option/future multiplier ratio.
        "put_equivalent_units": 0.75,
        "call_contract": "MO2608-C-8800",
        "call_mark": 0.8,
        # v1.3 sells one normalized MO Call for the 0.5 core sleeve.
        "call_equivalent_units": 0.5,
        "call_strike": 8800.0,
        "transition_day": date(2026, 8, 21),
        "post_core_contract": "IM2609",
        "post_put_contract": "MO2612-P-7200",
        "post_core_put_contract": "MO2612-P-7200",
        "post_momentum_put_contract": None,
        "post_put_equivalent_units": 0.75,
        "post_core_put_equivalent_units": 0.75,
        "post_momentum_put_equivalent_units": 0.0,
        "last_verified_day": date(2026, 8, 24),
        "verified_momentum_weight": 0.0,
        "verified_next_momentum_weight": 0.0,
        "verified_grid_units": 0.0,
        "verified_next_grid_units": 0.0,
        "verified_put_qty_normalized": 1.5,
        "verified_core_put_qty_normalized": 1.5,
        "verified_momentum_put_qty_normalized": 0.0,
        "verified_total_put_qty_normalized": 1.5,
        "verified_parent_puts": 3,
        "verified_call_contracts_normalized": 0.0,
        "verified_call_contract": None,
        "verified_call_expiry": None,
        "verified_call_strike": None,
    },
}

# A persistent server deployment can replace the bootstrap anchors above with
# the latest hash-verified ledger snapshot before every query.  The callback is
# deliberately optional so the original single-file Poe/CLI surface remains
# usable (but without cross-process persistence).
_SIGNAL_OBSERVER: Any = None
STRATEGY_QUERY_LOCK = threading.RLock()


def install_runtime_anchors(anchors: dict[str, dict[str, Any]]) -> None:
    """Install validated runtime anchors without replacing the frozen bootstrap."""
    with STRATEGY_QUERY_LOCK:
        try:
            _install_runtime_anchors(anchors)
        except (RuntimeError, TypeError, KeyError) as exc:
            raise ValueError(f"运行时账本字段校验失败: {exc}") from exc


def _install_runtime_anchors(anchors: dict[str, dict[str, Any]]) -> None:
    if not isinstance(anchors, dict) or set(anchors) != {"IC", "IM"}:
        raise ValueError("运行时账本必须同时包含IC和IM")
    prepared: dict[str, dict[str, Any]] = {}
    for product in ("IC", "IM"):
        if not isinstance(anchors[product], dict):
            raise ValueError(f"{product}运行时账本必须为字段映射")
        anchor = dict(anchors[product])
        if not isinstance(anchor.get("last_verified_day"), date):
            raise ValueError(f"{product}运行时账本缺少合法last_verified_day")
        for key in ("post_core_contract", "post_put_contract", "verified_momentum_weight",
                    "verified_next_momentum_weight", "verified_grid_units",
                    "verified_next_grid_units", "verified_put_qty_normalized",
                    "verified_call_contracts_normalized"):
            if key not in anchor:
                raise ValueError(f"{product}运行时账本缺少{key}")
        numeric_keys = ["verified_momentum_weight", "verified_next_momentum_weight",
                        "verified_grid_units", "verified_next_grid_units",
                        "verified_put_qty_normalized", "verified_call_contracts_normalized"]
        if product == "IC":
            numeric_keys.extend(("post_put_qty", "verified_core_put_delta", "verified_momentum_put_delta",
                                 "verified_total_put_delta"))
        else:
            numeric_keys.extend(("verified_core_put_qty_normalized",
                                 "verified_momentum_put_qty_normalized", "verified_total_put_qty_normalized"))
        for key in numeric_keys:
            if key not in anchor:
                raise ValueError(f"{product}运行时账本缺少{key}")
            value = anchor[key]
            if (isinstance(value, bool) or not isinstance(value, (int, float, np.integer, np.floating))
                    or not math.isfinite(float(value))):
                raise ValueError(f"{product}运行时账本{key}必须为有限数值")
            if key != "verified_call_contracts_normalized" and float(value) < 0:
                raise ValueError(f"{product}运行时账本{key}不能为负数")
            if key in {"verified_core_put_delta", "verified_momentum_put_delta", "verified_total_put_delta"} and float(value) > 1:
                raise ValueError(f"{product}运行时账本{key}不能超过1")
        for key in ("verified_core_put_qty", "verified_momentum_put_qty"):
            if key in anchor and (isinstance(anchor[key], bool)
                    or not isinstance(anchor[key], (int, float, np.integer, np.floating))
                    or not math.isfinite(float(anchor[key]))):
                raise ValueError(f"{product}运行时账本{key}必须为有限数值")
        if product == "IC":
            if not math.isclose(float(anchor["verified_total_put_delta"]),
                                float(anchor["verified_core_put_delta"]) + float(anchor["verified_momentum_put_delta"]),
                                abs_tol=1e-12):
                raise ValueError("IC运行时账本总Delta与分袖Delta不一致")
            try:
                breakdown = _ic_current_quantity_breakdown(anchor)
            except (RuntimeError, TypeError, KeyError) as exc:
                raise ValueError(f"IC运行时账本Put分袖数量无效: {exc}") from exc
            if not math.isclose(float(anchor["verified_put_qty_normalized"]),
                                breakdown["total"], abs_tol=1e-12):
                raise ValueError("IC运行时账本Put兼容总量与分袖总量不一致")
            # Legacy records may only identify a single non-zero sleeve by its
            # verified Delta. Normalize that unambiguous case in memory; never
            # infer a split from today's quote or rewrite the persisted record.
            anchor["verified_core_put_qty"] = breakdown["core"]
            anchor["verified_momentum_put_qty"] = breakdown["momentum"]
        else:
            required = ("post_core_put_contract", "verified_core_put_qty_normalized",
                        "verified_momentum_put_qty_normalized", "verified_total_put_qty_normalized")
            if any(key not in anchor for key in required):
                raise ValueError("IM运行时账本缺少Put分袖字段")
            total = float(anchor["verified_core_put_qty_normalized"]) + float(
                anchor["verified_momentum_put_qty_normalized"])
            if not math.isfinite(total) or not math.isclose(total, float(
                anchor["verified_total_put_qty_normalized"]), abs_tol=1e-12) or not math.isclose(
                total, float(anchor["verified_put_qty_normalized"]), abs_tol=1e-12):
                raise ValueError("IM运行时账本Put分袖与总量不一致")
        v14_policy.validate_extension(product, anchor)
        prepared[product] = anchor
    LIVE_CONTINUATION_ANCHOR.update(prepared)


def install_signal_observer(observer: Any = None) -> None:
    """Register a server-side observer used to append confirmed close states."""
    global _SIGNAL_OBSERVER
    _SIGNAL_OBSERVER = observer

_CFFEX_MONTH_CACHE: dict[str, bytes] = {}
_NETWORK_DEADLINE: contextvars.ContextVar[float | None] = contextvars.ContextVar(
    "poe_ic_im_network_deadline",
    default=None,
)
_SIGNAL_PRODUCT_BUDGET_OVERRIDE: contextvars.ContextVar[float | None] = (
    contextvars.ContextVar("ic_im_signal_product_budget_override", default=None)
)


@dataclass(frozen=True)
class QueryIntent:
    route: str
    products: tuple[str, ...]
    start: date | None = None
    end: date | None = None


def beijing_today() -> date:
    return _now_beijing().date()


def normalize_query(text: str) -> str:
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", text or "")).strip()


_CN_NUM = {
    "零": 0,
    "一": 1,
    "二": 2,
    "两": 2,
    "三": 3,
    "四": 4,
    "五": 5,
    "六": 6,
    "七": 7,
    "八": 8,
    "九": 9,
    "十": 10,
    "半": 0.5,
}


def _number(value: str) -> float:
    if value.isdigit():
        return float(value)
    if value in _CN_NUM:
        return float(_CN_NUM[value])
    if value.count("百") > 1 or value.count("十") > 1 or "半" in value:
        raise ValueError(f"无法识别数字: {value}")
    total = 0
    remainder = value
    if "百" in remainder:
        left, remainder = remainder.split("百", 1)
        if left not in _CN_NUM or left in {"零", "十", "半"}:
            raise ValueError(f"无法识别数字: {value}")
        total = _CN_NUM[left] * 100
        remainder = remainder.removeprefix("零")
    if "十" in remainder:
        left, right = remainder.split("十", 1)
        if left and left not in _CN_NUM:
            raise ValueError(f"无法识别数字: {value}")
        if right and right not in _CN_NUM:
            raise ValueError(f"无法识别数字: {value}")
        total += _CN_NUM.get(left, 1) * 10 + _CN_NUM.get(right, 0)
        remainder = ""
    if remainder:
        if remainder not in _CN_NUM:
            raise ValueError(f"无法识别数字: {value}")
        total += _CN_NUM[remainder]
    if total:
        return float(total)
    raise ValueError(f"无法识别数字: {value}")


def _shift_months(day: date, months: int) -> date:
    # Avoid pandas Timestamp's version-dependent lower bound and clamp an
    # otherwise valid natural-language request to Python's date domain.
    month_index = (day.year - 1) * 12 + day.month - 1 + months
    max_month_index = (date.max.year - 1) * 12 + date.max.month - 1
    if month_index < 0:
        return date.min
    if month_index > max_month_index:
        return date.max
    zero_based_year, zero_based_month = divmod(month_index, 12)
    year = zero_based_year + 1
    month = zero_based_month + 1
    target_day = min(day.day, month_calendar.monthrange(year, month)[1])
    return date(year, month, target_day)


def parse_date_range(
    text: str, now: date | None = None
) -> tuple[date | None, date | None]:
    query = normalize_query(text)
    today = now or beijing_today()

    explicit = re.search(
        r"(20\d{2})[-/.年](\d{1,2})[-/.月](\d{1,2})日?\s*(?:到|至|~|—|-)\s*"
        r"(20\d{2})[-/.年](\d{1,2})[-/.月](\d{1,2})日?",
        query,
    )
    if explicit:
        values = [int(x) for x in explicit.groups()]
        try:
            start, end = date(*values[:3]), date(*values[3:])
        except ValueError as exc:
            raise ValueError("日期区间无效，请使用真实存在的 YYYY-MM-DD 日期") from exc
        return (start, end) if start <= end else (end, start)

    single_day = re.search(r"(?<!\d)(20\d{2})[-/.年](\d{1,2})[-/.月](\d{1,2})日?(?!\d)", query)
    if single_day:
        try:
            day = date(*(int(value) for value in single_day.groups()))
        except ValueError as exc:
            raise ValueError("日期无效，请使用真实存在的 YYYY-MM-DD 日期") from exc
        return day, day

    year_to_month = re.search(
        r"(20\d{2})\s*年\s*(?:到|至|~|—|-)\s*(20\d{2})\s*年\s*(\d{1,2})\s*月",
        query,
    )
    if year_to_month:
        first_year, last_year, last_month = map(int, year_to_month.groups())
        first = date(first_year, 1, 1)
        try:
            last = date(last_year, last_month, month_calendar.monthrange(last_year, last_month)[1])
        except ValueError as exc:
            raise ValueError("年月范围无效") from exc
        if first > last:
            raise ValueError("年月范围起点晚于终点")
        return first, last

    year_range = re.search(
        r"(?:从\s*)?(20\d{2})\s*年?\s*(?:到|至|~|—|-)\s*(20\d{2})\s*年?",
        query,
    )
    if year_range:
        first_year, last_year = map(int, year_range.groups())
        if first_year > last_year:
            first_year, last_year = last_year, first_year
        return date(first_year, 1, 1), date(last_year, 12, 31)

    recent = re.search(
        r"(?:最近|过去|近)\s*([零一二两三四五六七八九十百\d半]+)\s*个?\s*(年半|年|月)",
        query,
    )
    if recent:
        try:
            count = _number(recent.group(1))
        except ValueError as exc:
            raise ValueError("最近/过去时间范围中的数字无法识别") from exc
        unit = recent.group(2)
        if unit == "年半":
            months = max(1, round(count * 12 + 6))
        elif unit == "年":
            months = max(1, round(count * 12))
        else:
            months = max(1, round(count))
        return _shift_months(today, -months), today

    if "今年" in query:
        return date(today.year, 1, 1), today
    if "去年" in query:
        return date(today.year - 1, 1, 1), date(today.year - 1, 12, 31)
    if "前年" in query:
        return date(today.year - 2, 1, 1), date(today.year - 2, 12, 31)

    year_month = re.search(r"(20\d{2})[年/-](\d{1,2})月?", query)
    if year_month:
        year, month = map(int, year_month.groups())
        try:
            first = date(year, month, 1)
        except ValueError as exc:
            raise ValueError(f"月份无效: {year}-{month:02d}") from exc
        last = (pd.Timestamp(first) + pd.offsets.MonthEnd(0)).date()
        if "至今" in query:
            return (first, today) if first <= today else (today, first)
        return first, last

    year = re.search(r"(20\d{2})\s*年", query)
    if year:
        value = int(year.group(1))
        first = date(value, 1, 1)
        if "至今" in query:
            return (first, today) if first <= today else (today, first)
        return first, date(value, 12, 31)
    return None, None


def _products_from_query(query: str) -> tuple[str, ...]:
    upper = query.upper()
    wants_ic = (
        bool(re.search(r"(?<![A-Z])(IC|SC)(?![A-Z])", upper)) or "中证500" in query
    )
    wants_im = bool(re.search(r"(?<![A-Z])IM(?![A-Z])", upper)) or "中证1000" in query
    if wants_ic and not wants_im:
        return ("IC",)
    if wants_im and not wants_ic:
        return ("IM",)
    return ("IC", "IM")


def classify_query(text: str, now: date | None = None) -> QueryIntent:
    query = normalize_query(text)
    products = _products_from_query(query)
    performance = bool(
        re.search(r"表现|净值|回撤|收益曲线|历史收益|年化|夏普|回报", query)
    )
    intraday_signal = bool(re.search(r"(?:实时|盘中)\s*信号", query))
    close_signal = "信号" in query and not intraday_signal
    params = "参数" in query or "规则" in query or "阈值" in query
    parsed_start, parsed_end = parse_date_range(query, now)
    if performance:
        if parsed_start is None:
            today = now or beijing_today()
            parsed_start, parsed_end = _shift_months(today, -12), today
        return QueryIntent("performance", products, parsed_start, parsed_end)
    # Intentional single-route policy: explicit parameter/rule/threshold wording
    # takes precedence over signal wording in an ambiguous combined request.
    if params:
        return QueryIntent("params", products)
    if intraday_signal:
        return QueryIntent("intraday_signal", products)
    if close_signal:
        return QueryIntent("close_signal", products)
    if parsed_start is not None:
        return QueryIntent("performance", products, parsed_start, parsed_end)
    return QueryIntent("snapshot", products)


def decode_returns(product: str) -> pd.Series:
    raw = zlib.decompress(base64.b64decode(_RETURN_BLOBS[product]))
    digest = hashlib.sha256(raw).hexdigest()
    if digest != _RETURN_SHA256[product]:
        raise RuntimeError(f"{product} 历史收益内嵌数据哈希校验失败")
    frame = pd.read_csv(io.BytesIO(raw), parse_dates=["date"])
    series = frame.set_index("date")["ret"].astype(float).sort_index()
    if series.index.has_duplicates or not series.index.is_monotonic_increasing:
        raise RuntimeError(f"{product} 历史收益日期异常")
    return series


def decode_benchmark_prices(product: str, index: pd.DatetimeIndex) -> pd.Series:
    raw = zlib.decompress(base64.b64decode(_BENCHMARK_PRICE_BLOBS[product]))
    digest = hashlib.sha256(raw).hexdigest()
    if digest != _BENCHMARK_PRICE_SHA256[product]:
        raise RuntimeError(f"{product} 指数价格内嵌数据哈希校验失败")
    deltas = np.frombuffer(raw, dtype="<i4")
    if len(deltas) != len(index):
        raise RuntimeError(
            f"{product} 指数价格行数 {len(deltas)} 与正式收益 {len(index)} 不一致"
        )
    prices = np.cumsum(deltas, dtype=np.int64).astype(float) / 100.0
    series = pd.Series(prices, index=index, name="benchmark_price")
    if not np.isfinite(series).all() or (series <= 0).any():
        raise RuntimeError(f"{product} 指数价格内嵌数据异常")
    return series


@contextmanager
def _network_budget(seconds: float):
    """Bound HTTP calls without allowing a child scope to extend its parent."""

    parent = _NETWORK_DEADLINE.get()
    candidate = time_module.monotonic() + seconds
    deadline = min(parent, candidate) if parent is not None else candidate
    token = _NETWORK_DEADLINE.set(deadline)
    try:
        yield
    finally:
        _NETWORK_DEADLINE.reset(token)


def _bounded_timeout(cap: float) -> float:
    deadline = _NETWORK_DEADLINE.get()
    if deadline is None:
        return cap
    remaining = deadline - time_module.monotonic()
    if remaining <= 0.25:
        raise RuntimeError("联网请求超过总时间预算，已停止继续取数")
    return max(0.25, min(cap, remaining))


def _remaining_network_budget() -> float | None:
    deadline = _NETWORK_DEADLINE.get()
    if deadline is None:
        return None
    return max(0.0, deadline - time_module.monotonic())


@contextmanager
def signal_product_budget_override(seconds: float | None):
    """Give the one-shot digest more time without changing Poe request limits."""

    if seconds is not None and (
        not math.isfinite(seconds) or seconds <= 0 or seconds > 300
    ):
        raise ValueError("逐品种联网预算必须在0到300秒之间")
    token = _SIGNAL_PRODUCT_BUDGET_OVERRIDE.set(seconds)
    try:
        yield
    finally:
        _SIGNAL_PRODUCT_BUDGET_OVERRIDE.reset(token)


def _signal_product_network_budget(product_count: int) -> float:
    if product_count <= 0:
        raise ValueError("信号品种数必须为正")
    override = _SIGNAL_PRODUCT_BUDGET_OVERRIDE.get()
    if override is not None:
        return override
    return min(
        SIGNAL_PRODUCT_NETWORK_BUDGET_SECONDS,
        SIGNAL_NETWORK_BUDGET_SECONDS / product_count,
    )


def _cffex_month_archive(month: pd.Timestamp) -> bytes:
    key = month.strftime("%Y%m")
    # The remote archive mutates in the actual current month. Use wall time,
    # not the historical replay/collection clock, for cache invalidation.
    use_cache = key != datetime.now(BEIJING).strftime("%Y%m")
    if not use_cache or key not in _CFFEX_MONTH_CACHE:
        path = f"www.cffex.com.cn/sj/historysj/{key}/zip/{key}.zip"
        # Do not fall back to HTTP: a PK header is not an integrity check for
        # historical marks that may enter a persisted research ledger.
        url = f"https://{path}"
        failures: list[str] = []
        response = None
        try:
            response = _evidence_http_get(
                url,
                timeout=_bounded_timeout(5),
                headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"},
                stream=True,
            )
            response.raise_for_status()
            declared_size = response.headers.get("Content-Length")
            if declared_size:
                try:
                    size = int(declared_size)
                except ValueError as exc:
                    raise RuntimeError(f"中金所 {key} 月度行情包长度标头非法") from exc
                if size > MAX_CFFEX_DOWNLOAD_BYTES:
                    raise RuntimeError(f"中金所 {key} 月度行情包超过下载上限")
            chunks: list[bytes] = []
            downloaded = 0
            stream = iter(response.iter_content(chunk_size=64 * 1024))
            while True:
                # Requests' socket timeout applies to each read, not the whole
                # response. Never accept or cache a body beyond our shared budget.
                _bounded_timeout(5)
                try:
                    chunk = next(stream)
                except StopIteration:
                    break
                _bounded_timeout(5)
                if not chunk:
                    continue
                downloaded += len(chunk)
                if downloaded > MAX_CFFEX_DOWNLOAD_BYTES:
                    raise RuntimeError(f"中金所 {key} 月度行情包超过下载上限")
                chunks.append(chunk)
            content = b"".join(chunks)
            _bounded_timeout(5)
            if not content.startswith(b"PK"):
                raise RuntimeError(f"中金所 {key} 月度行情包格式异常")
            if use_cache:
                _CFFEX_MONTH_CACHE[key] = content
            else:
                return content
        except (
            requests.ConnectionError,
            requests.Timeout,
            requests.exceptions.ChunkedEncodingError,
        ) as exc:
            failures.append(f"HTTPS {type(exc).__name__}: {exc}")
            # Requests maps a broken streaming connection to ChunkedEncodingError.
            # Normalize only that transport failure to the existing bounded retry.
            error_type = (
                requests.ConnectionError
                if isinstance(exc, requests.exceptions.ChunkedEncodingError)
                else type(exc)
            )
            raise error_type(
                f"中金所 {key} 月度行情包HTTPS传输失败｜{type(exc).__name__}: {exc}",
                request=exc.request,
                response=exc.response,
            ) from exc
        except (requests.RequestException, RuntimeError) as exc:
            failures.append(f"HTTPS {type(exc).__name__}: {exc}")
        finally:
            if response is not None:
                response.close()
        if not use_cache or key not in _CFFEX_MONTH_CACHE:
            raise RuntimeError(
                f"中金所 {key} 月度行情包HTTPS下载失败｜"
                + "｜".join(failures)
            )
    return _CFFEX_MONTH_CACHE[key]


def _cffex_historical_quote_frame(
    product: str, day: date, clock: datetime
) -> pd.DataFrame:
    """Reject a failed archive at every parse/validation boundary, then retry fresh."""
    try:
        return _cffex_historical_quote_frame_impl(product, day, clock)
    except Exception:
        # Schema/encoding/numeric errors after ZIP extraction are just as
        # invalid as bad ZIP structure. Never pin a failed historical body.
        _CFFEX_MONTH_CACHE.pop(f"{day:%Y%m}", None)
        raise


def _cffex_historical_quote_frame_impl(
    product: str, day: date, clock: datetime
) -> pd.DataFrame:
    """Load one official completed session from CFFEX's monthly archive."""

    member_name = f"{day:%Y%m%d}_1.csv"
    key = f"{day:%Y%m}"
    for attempt in range(2):
        raw = _cffex_month_archive(pd.Timestamp(day))
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                members = archive.infolist()
                if len(members) > MAX_CFFEX_ZIP_MEMBERS:
                    raise RuntimeError("中金所月度行情包成员数量超过安全上限")
                if any(info.flag_bits & 0x1 for info in members):
                    raise RuntimeError("中金所月度行情包含加密成员")
                if len({info.filename for info in members}) != len(members):
                    raise RuntimeError("中金所月度行情包成员重复")
                if any(info.file_size > MAX_CFFEX_ZIP_MEMBER_BYTES for info in members):
                    raise RuntimeError("中金所月度行情包单个成员超过安全上限")
                if sum(info.file_size for info in members) > MAX_CFFEX_ZIP_UNCOMPRESSED_BYTES:
                    raise RuntimeError("中金所月度行情包解压体积超过安全上限")
                matches = [info for info in members if info.filename.endswith(member_name)]
                if len(matches) != 1:
                    _CFFEX_MONTH_CACHE.pop(key, None)
                    if not matches and attempt == 0:
                        continue  # One bounded refresh; never use the stale body.
                    raise RuntimeError(f"中金所月度行情包缺少唯一日文件 {member_name}")
                daily = pd.read_csv(io.BytesIO(archive.read(matches[0])), encoding="gbk", low_memory=False)
            break
        except zipfile.BadZipFile as exc:
            _CFFEX_MONTH_CACHE.pop(key, None)
            raise RuntimeError("中金所月度行情包ZIP结构或校验异常") from exc
        except RuntimeError:
            _CFFEX_MONTH_CACHE.pop(key, None)
            raise
    daily.columns = [str(column).strip().lstrip("\ufeff") for column in daily.columns]
    field_map = {
        "合约代码": "instrument",
        "今开盘": "openprice",
        "最高价": "highest",
        "最低价": "lowest",
        "成交量": "volume",
        "持仓量": "position",
        "今收盘": "lastprice",
    }
    missing = sorted(set(field_map).difference(daily.columns))
    if missing:
        raise RuntimeError(
            f"中金所 {day} 日行情缺少字段: {', '.join(missing)}"
        )
    frame = daily.rename(columns=field_map)[list(field_map.values())].copy()
    frame["raw_close"] = pd.to_numeric(frame["lastprice"], errors="coerce")
    frame["lastprice"] = frame["raw_close"].astype(float)
    frame["settle"] = pd.to_numeric(daily.get("今结算", pd.Series(index=daily.index, dtype=float)), errors="coerce")
    frame["pricing_basis"] = "official_close"
    frame["instrument"] = frame["instrument"].astype(str).str.strip().str.upper()
    pattern = rf"{product}\d{{4}}" if product in {"IC", "IM"} else r"MO\d{4}-[CP]-\d+"
    frame = frame.loc[frame["instrument"].str.fullmatch(pattern)].copy()
    if frame.empty:
        raise RuntimeError(f"中金所 {day} 日行情没有 {product} 合约")
    # A zero-volume option's reported close can be carried from an older day.
    # Retain it as evidence, but use today's official settlement as an explicit
    # valuation estimate. This does not assert an executable fill or alter Call.
    zero_volume_put = (
        frame["instrument"].str.fullmatch(r"MO\d{4}-P-\d+")
        & pd.to_numeric(frame["volume"], errors="coerce").eq(0)
    )
    if zero_volume_put.any():
        settlement = frame.loc[zero_volume_put, "settle"]
        valid_settlement = np.isfinite(settlement) & settlement.gt(0)
        frame.loc[zero_volume_put, "lastprice"] = settlement.where(valid_settlement, np.nan)
        frame.loc[zero_volume_put, "pricing_basis"] = "official_settlement_estimate_zero_volume"
        frame.loc[settlement.index[~valid_settlement], "pricing_basis"] = "unavailable_zero_volume_no_valid_settlement"
    frame["source_date"] = day
    frame["source_time"] = "15:15:00"
    return _validate_quote_frame(frame, product, clock, "中金所官方日行情")


def fetch_cffex_daily_marks(
    contracts: Iterable[str], start: date, end: date
) -> pd.DataFrame:
    wanted = set(contracts)
    rows: list[dict[str, Any]] = []
    for month in pd.period_range(start=start, end=end, freq="M"):
        raw = _cffex_month_archive(month.to_timestamp())
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            members = archive.infolist()
            if len(members) > MAX_CFFEX_ZIP_MEMBERS:
                raise RuntimeError("中金所月度行情包成员数量超过安全上限")
            if any(info.file_size > MAX_CFFEX_ZIP_MEMBER_BYTES for info in members):
                raise RuntimeError("中金所月度行情包单个成员超过安全上限")
            if sum(info.file_size for info in members) > MAX_CFFEX_ZIP_UNCOMPRESSED_BYTES:
                raise RuntimeError("中金所月度行情包解压体积超过安全上限")
            if any(info.flag_bits & 0x1 for info in members):
                raise RuntimeError("中金所月度行情包含加密成员")
            for info in members:
                name = info.filename
                match = re.search(r"(20\d{6})_1\.csv$", name)
                if not match:
                    continue
                day = pd.Timestamp(match.group(1)).date()
                if day < start or day > end:
                    continue
                daily = pd.read_csv(
                    io.BytesIO(archive.read(info)), encoding="gbk", low_memory=False
                )
                daily.columns = [str(column).strip().lstrip("\ufeff") for column in daily.columns]
                field_map = {
                    "合约代码": "contract",
                    "今收盘": "close",
                    "今结算": "settle",
                    "前结算": "pre_settle",
                }
                missing_fields = set(field_map).difference(daily.columns)
                if missing_fields:
                    raise RuntimeError(
                        f"中金所 {day} 日行情缺少字段: {', '.join(sorted(missing_fields))}"
                    )
                daily = daily.rename(columns=field_map)
                contract_values = daily["contract"].astype(str).str.strip()
                selected = daily.loc[contract_values.isin(wanted)]
                for _, item in selected.iterrows():
                    rows.append(
                        {
                            "date": pd.Timestamp(day),
                            "contract": str(item["contract"]).strip(),
                            "close": float(pd.to_numeric(item["close"], errors="raise")),
                            "settle": float(pd.to_numeric(item["settle"], errors="raise")),
                            "pre_settle": float(
                                pd.to_numeric(item["pre_settle"], errors="raise")
                            ),
                        }
                    )
    if not rows:
        raise RuntimeError("中金所尚未提供所选区间的日行情")
    frame = pd.DataFrame(rows).sort_values(["date", "contract"])
    if frame.duplicated(["date", "contract"]).any():
        raise RuntimeError("中金所日行情出现重复合约记录")
    return frame.set_index(["date", "contract"])


def fetch_sina_option_closes(security_id: str) -> pd.Series:
    url = (
        "https://stock.finance.sina.com.cn/futures/api/jsonp_v2.php//"
        "StockOptionDaylineService.getSymbolInfo"
    )
    response = _evidence_http_get(
        url,
        params={"symbol": security_id},
        timeout=_bounded_timeout(8),
        headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"},
    )
    try:
        response.raise_for_status()
        _response_with_size_limit(response, f"新浪期权 {security_id} 历史收盘价")
        body = response.text
    finally:
        close = getattr(response, "close", None)
        if callable(close):
            close()
    match = re.search(r"\((\[.*\])\)\s*;?\s*$", body, flags=re.DOTALL)
    if not match:
        raise RuntimeError(f"上交所期权 {security_id} 历史行情响应格式异常")
    payload = json.loads(match.group(1))
    if not isinstance(payload, list):
        raise RuntimeError(f"上交所期权 {security_id} 历史行情结构异常")
    points = {}
    for item in payload:
        if not isinstance(item, dict) or item.get("c") in (None, ""):
            raise RuntimeError(f"上交所期权 {security_id} 历史行情字段缺失")
        stamp = pd.Timestamp(adjusted_put_migration.day(item.get("d")))
        if stamp in points:
            raise RuntimeError(f"上交所期权 {security_id} 历史行情日期重复")
        if isinstance(item["c"], bool):
            raise RuntimeError(f"上交所期权 {security_id} 历史收盘价无效")
        value = float(item["c"])
        if not math.isfinite(value) or value <= 0:
            raise RuntimeError(f"上交所期权 {security_id} 历史收盘价无效")
        points[stamp] = value
    if not points:
        raise RuntimeError(f"上交所期权 {security_id} 未返回日收盘价")
    return pd.Series(points, dtype=float, name="put_mark").sort_index()


def fetch_eastmoney_option_closes(security_id: str) -> pd.Series:
    """Fetch one SSE option's unadjusted daily closes from Eastmoney."""

    if not re.fullmatch(r"[0-9]{8}", str(security_id)):
        raise ValueError(f"东方财富期权证券代码格式异常: {security_id}")
    payload = _request_json(
        "https://push2his.eastmoney.com/api/qt/stock/kline/get",
        {
            "secid": f"10.{security_id}",
            "klt": "101",
            "fqt": "0",
            "lmt": "10000",
            "end": "20500101",
            "fields1": "f1,f2,f3,f4,f5,f6",
            "fields2": "f51,f52,f53,f54,f55,f56,f57",
        },
    )
    data = payload.get("data") or {}
    if str(data.get("code") or "") != str(security_id) or int(
        data.get("market", -1)
    ) != 10:
        raise RuntimeError(f"东方财富期权 {security_id} 返回证券身份不一致")
    points: dict[pd.Timestamp, float] = {}
    for raw in data.get("klines") or []:
        fields = str(raw).split(",")
        if len(fields) < 3:
            raise RuntimeError(f"东方财富期权 {security_id} 历史行情字段不足")
        stamp = pd.Timestamp(fields[0])
        close = float(fields[2])
        if stamp in points:
            raise RuntimeError(f"东方财富期权 {security_id} 历史行情日期重复")
        if not np.isfinite(close) or close <= 0:
            raise RuntimeError(f"东方财富期权 {security_id} 历史收盘价无效")
        points[stamp] = close
    if not points:
        raise RuntimeError(f"东方财富期权 {security_id} 未返回日收盘价")
    result = pd.Series(points, dtype=float, name="put_mark").sort_index()
    result.attrs["source"] = "Eastmoney"
    return result


def fetch_option_closes(security_id: str, required_day: date | str | None = None) -> pd.Series:
    """Fetch SSE option closes with audited Sina -> Eastmoney failover."""

    failures: list[str] = []
    source_errors: list[Exception] = []
    for source, fetcher in (
        ("Sina", fetch_sina_option_closes),
        ("Eastmoney", fetch_eastmoney_option_closes),
    ):
        try:
            result = fetcher(security_id)
            if (
                result.empty
                or result.index.has_duplicates
                or not result.index.is_monotonic_increasing
            ):
                raise RuntimeError(f"{source}期权历史日期为空、重复或乱序")
            values = result.to_numpy(dtype=float)
            if not np.isfinite(values).all() or (values <= 0).any():
                raise RuntimeError(f"{source}期权历史收盘价无效")
            if required_day is not None and pd.Timestamp(required_day) not in result.index:
                raise RuntimeError(f"{source}期权历史缺少所需交易日 {required_day}")
            result.attrs["source"] = source
            result.attrs["source_failures"] = list(failures)
            return result
        except Exception as exc:  # noqa: BLE001 - continue to the validated backup.
            failures.append(f"{source}: {type(exc).__name__}: {exc}")
            source_errors.append(exc)
    raise _source_failure_error(
        f"上交所期权 {security_id} 历史行情全部来源失败：{'；'.join(failures)}", source_errors
    ) from source_errors[-1]


def fetch_option_dated_open(security_id: str, day: date) -> tuple[float, str]:
    """Read this contract's dated opening price; never substitute a close."""
    if not re.fullmatch(r"[0-9]{8}", str(security_id)):
        raise ValueError("IC Put证券代码格式异常")
    day = adjusted_put_migration.day(day)
    failures: list[str] = []
    source_errors: list[Exception] = []
    response = None
    try:
        response = _evidence_http_get(
            "https://stock.finance.sina.com.cn/futures/api/jsonp_v2.php//StockOptionDaylineService.getSymbolInfo",
            params={"symbol": security_id}, timeout=_bounded_timeout(8),
            headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"},
        )
        response.raise_for_status()
        _response_with_size_limit(response, "新浪期权历史开盘价")
        match = re.search(r"\((\[.*\])\)\s*;?\s*$", response.text, flags=re.DOTALL)
        if match is None:
            raise RuntimeError("新浪开盘行情格式异常")
        payload = json.loads(match.group(1))
        if not isinstance(payload, list) or any(not isinstance(item, dict) for item in payload):
            raise RuntimeError("新浪开盘行情结构异常")
        rows = [item for item in payload if adjusted_put_migration.day(item.get("d")) == day]
        if not rows:
            raise RuntimeError("新浪缺少指定交易日期开盘记录")
        if any(isinstance(item.get("o"), (bool, np.bool_)) for item in rows):
            raise RuntimeError("新浪指定交易日期开盘价不能为布尔值")
        openings = {float(item["o"]) for item in rows}
        if len(openings) != 1:
            raise RuntimeError("新浪同日开盘记录相互冲突")
        opening = openings.pop()
        if not math.isfinite(opening) or opening <= 0:
            raise RuntimeError("新浪指定交易日期缺少正开盘价")
        return opening, "Sina:dated_open"
    except Exception as exc:
        failures.append(f"Sina:{type(exc).__name__}:{exc}")
        source_errors.append(exc)
    finally:
        close = getattr(response, "close", None)
        if callable(close):
            close()
    try:
        payload = _request_json(
            "https://push2his.eastmoney.com/api/qt/stock/kline/get",
            {"secid": f"10.{security_id}", "klt": "101", "fqt": "0", "lmt": "10000",
             "end": "20500101", "fields1": "f1,f2,f3,f4,f5,f6",
             "fields2": "f51,f52,f53,f54,f55,f56,f57"},
        )
        data = payload.get("data") or {}
        if str(data.get("code") or "") != str(security_id) or int(data.get("market", -1)) != 10:
            raise RuntimeError("东方财富期权证券身份不一致")
        rows = [str(raw).split(",") for raw in data.get("klines") or []]
        matches = [fields for fields in rows if fields and adjusted_put_migration.day(fields[0]) == day]
        if len(matches) != 1 or len(matches[0]) < 3:
            raise RuntimeError("东方财富指定交易日期开盘记录不唯一")
        opening = float(matches[0][1])
        if not math.isfinite(opening) or opening <= 0:
            raise RuntimeError("东方财富指定交易日期缺少正开盘价")
        return opening, "Eastmoney:dated_open"
    except Exception as exc:
        failures.append(f"Eastmoney:{type(exc).__name__}:{exc}")
        source_errors.append(exc)
    raise _source_failure_error(
        f"IC Put {security_id} {day} 开盘价不可核验；" + "；".join(failures), source_errors
    ) from source_errors[-1]


def fetch_sina_510500_security_id(contract: str) -> str:
    match = re.fullmatch(r"510500P([0-9]{4})([MA])([0-9]{5})", contract)
    if not match:
        raise RuntimeError(f"无法为IC Put解析新浪证券代码: {contract}")
    yymm, style, _ = match.groups()
    if style != "M":
        raise RuntimeError("510500 adjusted contract master and multiplier unavailable")
    chain, _ = fetch_sina_510500_chain(yymm)
    matches = chain.loc[chain["contract"].eq(contract)]
    if len(matches) != 1:
        raise RuntimeError(f"新浪证券代码映射不唯一: {contract}")
    security_id = str(matches.iloc[0]["security_id"])
    if not re.fullmatch(r"[0-9]{8}", security_id):
        raise RuntimeError(f"新浪证券代码格式无效: {contract}")
    return security_id


def _ic_put_selected_security_id(selected: pd.Series) -> str:
    # Sina rows already bind identity and price in the same validated response.
    # SSE rows do not carry this field and require the same strict mapping path.
    if not re.fullmatch(r"510500P[0-9]{4}M[0-9]{5}", str(selected["contract"])):
        raise RuntimeError("IC Put选约的交易代码格式无效或调整身份未支持")
    if "security_id" in selected:
        security_id = str(selected["security_id"])
        if not re.fullmatch(r"[0-9]{8}", security_id):
            raise RuntimeError("IC Put选约的证券代码格式无效")
        return security_id
    return fetch_sina_510500_security_id(str(selected["contract"]))


def _require_held_ic_put_identity(
    contract: str, security_id: str | None, row: pd.Series, day: date
) -> None:
    """A re-listed M trading code cannot prove continuity of a held security."""
    actual = row.get("security_id")
    strict = day >= sse_identity.EFFECTIVE_SIGNAL_DATE
    if strict:
        if (not re.fullmatch(r"[0-9]{8}", str(security_id or ""))
                or not re.fullmatch(r"[0-9]{8}", str(actual or ""))):
            raise RuntimeError("IC既有Put证券ID证据缺失或格式无效，禁止仅按同名M代码续接")
        if str(row.get("contract")) != str(contract):
            raise RuntimeError("IC既有Put证券与交易代码未绑定")
        match = re.fullmatch(r"510500P[0-9]{4}M([0-9]{5})", str(contract))
        if not match:
            raise RuntimeError("IC adjusted contract master and multiplier unavailable; preserve held identity")
        strike = float(row.get("strike", float("nan")))
        if not math.isfinite(strike) or not math.isclose(strike, int(match.group(1))/1000., rel_tol=0, abs_tol=1e-9):
            raise RuntimeError("IC既有Put标准行权价与证券身份不一致")
    if actual is not None and str(actual) != str(security_id):
        raise RuntimeError("IC既有Put同名合约证券ID不同，禁止用重新挂牌M合约替代原持仓")


def _contract_daily_marks(
    marks: pd.DataFrame, contract: str, product: str, leg: str
) -> pd.DataFrame:
    try:
        return marks.xs(contract, level="contract").sort_index()
    except KeyError as exc:
        raise RuntimeError(
            f"{product} {leg}日行情缺少合约 {contract}"
        ) from exc


def latest_continuation_frame(product: str, end: date) -> pd.DataFrame:
    """The old r6 continuation is disabled; never invent a post-cutoff return."""
    if end <= DATA_CUTOFF:
        return pd.DataFrame(columns=["ret", "benchmark_price", "is_live", "is_transition"])
    if end >= quarter_roll.EFFECTIVE_DATE:
        raise RuntimeError("r7季度规则生效后的绩效尚未生成；禁止用r6月度续接冒充r7收益")
    raise RuntimeError(
        "1.3逐日仓位、期权与网格续接账本尚未形成；禁止用固定1倍期货桥接冒充1.3绩效，"
        f"绩效仅可降级到已哈希冻结的 {DATA_CUTOFF}"
    )


def performance_frame(
    product: str, start: date, end: date, *, refresh_latest: bool = False,
    allow_invalidated_im_history: bool = False,
) -> pd.DataFrame:
    if product == "IM" and not allow_invalidated_im_history:
        raise RuntimeError(
            "IM旧r6绩效使用未修正的Put月度执行，已撤回有效绩效资格；"
            "请使用2026-09-07修复后整轮报告。历史审计须显式启用旧路径。"
        )
    returns = decode_returns(product)
    benchmark_prices = decode_benchmark_prices(product, returns.index)
    live_flags = pd.Series(False, index=returns.index, dtype=bool)
    transition_flags = pd.Series(False, index=returns.index, dtype=bool)
    if refresh_latest and end > DATA_CUTOFF:
        latest_continuation_frame(product, end)
    for label, series in (
        ("策略收益", returns),
        ("指数价格", benchmark_prices),
        ("数据段标记", live_flags),
        ("换仓日标记", transition_flags),
    ):
        if series.index.has_duplicates:
            duplicated = series.index[series.index.duplicated()][0]
            raise RuntimeError(
                f"{product} {label}存在重复交易日 {pd.Timestamp(duplicated).date()}"
            )
    selected = returns.loc[
        (returns.index.date >= start) & (returns.index.date <= end)
    ]
    if selected.empty:
        raise ValueError(f"{product} 在所选区间没有可核验收益数据")
    nav = (1.0 + selected).cumprod()
    drawdown = nav / nav.cummax() - 1.0
    benchmark_price = benchmark_prices.reindex(selected.index)
    if benchmark_price.isna().any():
        raise RuntimeError(f"{product} 指数价格与策略收益交易日未完全对齐")
    benchmark_nav = benchmark_price / float(benchmark_price.iloc[0])
    chart_nav = nav / float(nav.iloc[0])
    return pd.DataFrame(
        {
            "ret": selected,
            "nav": nav,
            "chart_nav": chart_nav,
            "drawdown": drawdown,
            "benchmark_price": benchmark_price,
            "benchmark_nav": benchmark_nav,
            "is_live": live_flags.reindex(selected.index).fillna(False).astype(bool),
            "is_transition": transition_flags.reindex(selected.index)
            .fillna(False)
            .astype(bool),
        }
    )


def performance_metrics(frame: pd.DataFrame) -> dict[str, float]:
    observations = len(frame)
    final_nav = float(frame["nav"].iloc[-1])
    std = float(frame["ret"].std(ddof=1)) if observations > 1 else 0.0
    return {
        "final_nav": final_nav,
        "return": final_nav - 1.0,
        "cagr": final_nav ** (252.0 / observations) - 1.0,
        "volatility": std * np.sqrt(252.0),
        "sharpe": float(frame["ret"].mean()) / std * np.sqrt(252.0) if std > 0 else 0.0,
        "max_drawdown": float(frame["drawdown"].min()),
        "observations": float(observations),
    }


def render_nav_drawdown_chart(product: str, frame: pd.DataFrame, start: date) -> bytes:
    color = "#1f77b4" if product == "IC" else "#d95f02"
    fig, (nav_ax, dd_ax) = plt.subplots(
        2, 1, figsize=(11.5, 7.5), sharex=True, gridspec_kw={"height_ratios": [3, 1]}
    )
    benchmark_name = "CSI 500 Price Index" if product == "IC" else "CSI 1000 Price Index"
    nav_ax.plot(
        frame.index,
        frame["chart_nav"],
        color=color,
        linewidth=1.9,
        label=f"{product} v1.3 NAV",
    )
    if frame["is_live"].any():
        first_live = int(np.flatnonzero(frame["is_live"].to_numpy())[0])
        live_part = frame.iloc[max(0, first_live - 1) :]
        nav_ax.plot(
            live_part.index,
            live_part["chart_nav"],
            color="#7b3294",
            linewidth=2.2,
            label="Actual-market continuation",
        )
        if frame.index.min().date() <= DATA_CUTOFF:
            nav_ax.axvline(
                pd.Timestamp(DATA_CUTOFF),
                color="#7b3294",
                linewidth=0.9,
                linestyle=":",
            )
    nav_ax.plot(
        frame.index,
        frame["benchmark_nav"],
        color="#4d4d4d",
        linewidth=1.4,
        linestyle="--",
        label=f"{benchmark_name} (normalized)",
    )
    nav_ax.axhline(1.0, color="#777777", linewidth=0.8, linestyle="--")
    nav_ax.set_title(
        f"{product} v1.3 Frozen r6 History (continuation disabled) vs {benchmark_name} | "
        f"{start} to {frame.index[-1].date()}"
    )
    nav_ax.set_ylabel("NAV (start = 1.0)")
    nav_ax.legend(loc="best", frameon=False)
    nav_ax.grid(alpha=0.25)
    dd_ax.fill_between(frame.index, frame["drawdown"], 0, color="#c44e52", alpha=0.4)
    dd_ax.plot(frame.index, frame["drawdown"], color="#a23b3b", linewidth=1.0)
    dd_ax.set_ylabel("Drawdown")
    dd_ax.set_xlabel("Date")
    dd_ax.grid(alpha=0.25)
    dd_ax.yaxis.set_major_formatter(lambda value, _pos: f"{value:.0%}")
    fig.tight_layout()
    buffer = io.BytesIO()
    fig.savefig(buffer, format="png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    return buffer.getvalue()


def valuation_score(pb: float, erp: float, dividend: float) -> float:
    pressures = ((pb - 1.50) / 0.50, (0.045 - erp) / 0.015, (0.030 - dividend) / 0.010)
    return float(np.median(pressures))


def _tier(score: float, thresholds: Iterable[float]) -> int:
    return sum(score + 1e-12 >= threshold for threshold in thresholds)


def _tier_band_label(
    tier: int, thresholds: tuple[float, ...], *, unit: str = ""
) -> str:
    if tier <= 0:
        return f"基础观察档（低于{thresholds[0]:.3f}{unit}）"
    if tier >= len(thresholds):
        return f"第{tier}保护档（不低于{thresholds[-1]:.3f}{unit}）"
    return (
        f"第{tier}保护档（{thresholds[tier - 1]:.3f}至"
        f"低于{thresholds[tier]:.3f}{unit}）"
    )


def ic_targets(
    score: float, momentum_120: float, *, mom120_floor_active: bool | None = None
) -> dict[str, Any]:
    thresholds = (1.90, 1.95, 2.00, 2.05)
    tier = _tier(score, thresholds)
    valuation_delta = (0.0, 0.25, 0.50, 0.75, 1.00)[tier]
    mom120_floor = 0.50 if (
        momentum_120 < 0 if mom120_floor_active is None else mom120_floor_active
    ) else 0.0
    delta = max(valuation_delta, mom120_floor)
    if valuation_delta > mom120_floor:
        driver = "估值档"
    elif mom120_floor > valuation_delta:
        driver = (
            "MOM120负动量下限"
            if momentum_120 < 0.0
            else "MOM120防抖保护未解除（需连续两日均严格>+1%）"
        )
    elif delta > 0:
        driver = "估值档与MOM120下限同时命中同一目标"
    else:
        driver = "基础观察档，未触发Put"
    return {
        "put_delta": delta,
        "valuation_tier": tier,
        "valuation_tier_label": _tier_band_label(tier, thresholds),
        "valuation_put_delta": valuation_delta,
        "mom120_floor_delta": mom120_floor,
        "put_driver": driver,
        "grid_next": score <= 0.375,
        "grid_exit": score >= 1.000,
    }


def im_targets(
    score: float, momentum_120: float, *, mom120_floor_active: bool | None = None
) -> dict[str, Any]:
    absolute_thresholds = (2.45, 2.50, 2.60)
    relative_thresholds = tuple(FROZEN["IM"]["relative_thresholds"])
    absolute = _tier(score, absolute_thresholds)
    relative = _tier(score, relative_thresholds)
    valuation_puts = max(absolute, relative)
    mom120_floor = 3 if (
        momentum_120 < 0 if mom120_floor_active is None else mom120_floor_active
    ) else 0
    puts = max(valuation_puts, mom120_floor)
    if valuation_puts > mom120_floor:
        driver = "估值档"
    elif mom120_floor > valuation_puts:
        driver = (
            "MOM120负动量下限"
            if momentum_120 < 0.0
            else "MOM120防抖保护未解除（需连续两日均严格>+1%）"
        )
    elif puts > 0:
        driver = "估值档与MOM120下限同时命中同一目标"
    else:
        driver = "估值两轴均在基础观察档，未触发Put"
    return {
        "puts_per_core": min(4, puts),
        "absolute_valuation_tier": absolute,
        "absolute_valuation_tier_label": _tier_band_label(
            absolute, absolute_thresholds
        ),
        "relative_valuation_tier": relative,
        "relative_valuation_tier_label": _tier_band_label(
            relative, relative_thresholds
        ),
        "valuation_puts_per_full_core": valuation_puts,
        "mom120_floor_puts_per_full_core": mom120_floor,
        "put_driver": driver,
        "grid_next": score <= 1.60,
        "grid_exit": score >= 2.00,
    }


def calc_v13_momentum_score(
    product: str, close: pd.Series, *, rule_override: dict | None = None
) -> pd.Series:
    """Exact weighted bias-momentum score inherited from A-share v1.3."""

    rule = rule_override if rule_override is not None else MOMENTUM_RULES[product]
    prices = pd.to_numeric(close, errors="coerce").to_numpy(dtype=float)
    result = np.full(len(prices), np.nan)
    ma_days = int(rule["ma"])
    momentum_days = int(rule["days"])
    ma = pd.Series(prices, index=close.index).rolling(ma_days).mean().to_numpy(dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        bias = np.where((ma > 1e-10) & np.isfinite(prices), prices / ma, np.nan)
    x = np.arange(momentum_days, dtype=float)
    weights = np.linspace(1.0, float(rule["weight_end"]), momentum_days)
    weight_sum = float(weights.sum())
    x_bar = float((weights * x).sum() / weight_sum)
    denominator = float((weights * (x - x_bar) ** 2).sum())
    for end in range(ma_days + momentum_days - 1, len(prices)):
        y = bias[end - momentum_days + 1 : end + 1]
        if not np.isfinite(y).all() or y[0] <= 1e-10:
            continue
        y_bar = float((weights * y).sum() / weight_sum)
        slope = float((weights * (x - x_bar) * (y - y_bar)).sum() / denominator)
        result[end] = slope / float(y[0]) * 10000.0
    return pd.Series(result, index=close.index, name="momentum_score")


def _recovery_confirmed(
    value: pd.Series, *, threshold: float = 0.01, days: int = 2
) -> pd.Series:
    """Immediate risk-off at <=0; require consecutive strictly-positive recovery."""
    active, streak, result = False, 0, []
    for item in pd.to_numeric(value, errors="coerce"):
        if not np.isfinite(item) or item <= 0.0:
            active, streak = False, 0
        elif active:
            streak = 0
        elif item > threshold:
            streak += 1
            if streak >= days:
                active, streak = True, 0
        else:
            streak = 0
        result.append(active)
    return pd.Series(result, index=value.index, dtype=bool)


def _mom120_floor_state(close: pd.Series) -> pd.Series:
    """Apply the dated MOM120 floor release rule without rewriting old signals."""
    momentum = close / close.shift(120) - 1.0
    active, streak, result = False, 0, []
    for stamp, item in momentum.items():
        if not np.isfinite(item):
            result.append(active)
            continue
        if stamp.date() < MOMENTUM_DEBOUNCE_EFFECTIVE_DATE:
            active, streak = item < 0.0, 0
        elif item < 0.0:
            active, streak = True, 0
        elif active and item > 0.01:
            streak += 1
            if streak >= 2:
                active, streak = False, 0
        elif active:
            streak = 0
        result.append(active)
    return pd.Series(result, index=close.index, dtype=bool, name="mom120_floor_active")


class DailyOHLCVNotReady(RuntimeError):
    """No complete daily bar yet; never promote an intraday volume placeholder."""
    status = "waiting_for_completed_daily_ohlcv"


class DailyOHLCVSourcesUnavailable(RuntimeError):
    """Mixed source failures; some daily bars may still be awaiting publication."""
    status = "daily_ohlcv_sources_unavailable"


_OHLCV_FRESHNESS_PROBE = contextvars.ContextVar("ohlcv_freshness_probe", default=False)


def _validate_v13_ohlcv(product: str, frame: pd.DataFrame, clock: datetime) -> pd.DataFrame:
    clock = _beijing_clock(clock)
    if frame.empty:
        raise RuntimeError(f"{product} OHLCV为空")
    required = ["open", "high", "low", "close", "volume"]
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise RuntimeError(f"{product} OHLCV缺列: {missing}")
    result = frame[required].copy()
    index = pd.DatetimeIndex(pd.to_datetime(result.index, errors="raise"))
    if index.tz is not None:
        index = index.tz_convert(BEIJING).tz_localize(None)
    result.index = index.normalize()
    placeholders = (pd.Series(frame["realtime_volume_placeholder"].fillna(False).astype(bool).to_numpy(),
                              index=result.index)
                    if "realtime_volume_placeholder" in frame else None)
    if result.index.has_duplicates or not result.index.is_monotonic_increasing:
        raise RuntimeError(f"{product} OHLCV日期重复或乱序")
    result = result.apply(pd.to_numeric, errors="coerce").astype(float)
    if not np.isfinite(result.to_numpy(dtype=float)).all():
        raise RuntimeError(f"{product} OHLCV含NaN或无穷值")
    prices = result[["open", "high", "low", "close"]]
    if (prices <= 0.0).any().any():
        raise RuntimeError(f"{product} OHLCV含非正价格")
    if (result["high"] < prices[["open", "close"]].max(axis=1)).any():
        raise RuntimeError(f"{product} OHLCV最高价关系错误")
    if (result["low"] > prices[["open", "close"]].min(axis=1)).any():
        raise RuntimeError(f"{product} OHLCV最低价关系错误")
    if (result["volume"] <= 0.0).any():
        raise RuntimeError(f"{product} OHLCV成交量非正")
    recent_volume_median = float(result["volume"].tail(min(len(result), 60)).median())
    if not 1_000_000.0 <= recent_volume_median <= 1_000_000_000_000.0:
        raise RuntimeError(f"{product} OHLCV成交量单位/数量级异常")
    replay_day = _HISTORICAL_REPLAY_DAY.get()
    if replay_day is not None:
        result = result.loc[result.index.date <= replay_day]
    if result.empty or result.index[-1].date() > clock.date():
        raise RuntimeError(f"{product} OHLCV日期范围无效")
    expected = _latest_completed_exchange_day(clock)
    if (placeholders is not None and
            (placeholders.reindex(result.index) & (result.index.date <= expected)).any()):
        raise RuntimeError(f"{product} OHLCV含已知盘中成交量占位，禁止作为完整日线确认")
    if result.index[-1].date() < expected:
        message = f"{product} OHLCV已过期：最新 {result.index[-1].date()}，应覆盖 {expected}"
        if expected == clock.date() and _market_phase(clock) == "收盘后":
            raise DailyOHLCVNotReady(message + "；等待当日完整日线（含成交量）更新，暂停收盘确认")
        raise RuntimeError(message)
    history_start, history_rows, expected_history_hash = V13_HISTORY_DATE_INDEX[product]
    fixed_dates = result.loc[
        (result.index.date >= history_start) & (result.index.date <= DATA_CUTOFF)
    ].index
    fixed_payload = "\n".join(fixed_dates.strftime("%Y-%m-%d")) + "\n"
    actual_history_hash = hashlib.sha256(fixed_payload.encode("utf-8")).hexdigest()
    if len(fixed_dates) != history_rows or actual_history_hash != expected_history_hash:
        raise RuntimeError(
            f"{product} OHLCV在{history_start}至{DATA_CUTOFF}的交易日索引不完整或被改写"
        )
    coverage_start = DATA_CUTOFF + timedelta(days=1)
    expected_days: set[date] = set()
    cursor = coverage_start
    last_day = result.index[-1].date()
    while cursor <= last_day:
        if _is_exchange_trading_day(cursor):
            expected_days.add(cursor)
        cursor += timedelta(days=1)
    actual_days = set(result.index.date)
    unexpected_days = sorted(
        day for day in actual_days
        if day >= coverage_start and day not in expected_days
    )
    if unexpected_days:
        preview = ", ".join(day.isoformat() for day in unexpected_days[:5])
        raise RuntimeError(
            f"{product} OHLCV混入非交易日，发现{len(unexpected_days)}日：{preview}"
        )
    missing_days = sorted(expected_days - actual_days)
    if missing_days:
        preview = ", ".join(day.isoformat() for day in missing_days[:5])
        raise RuntimeError(
            f"{product} OHLCV交易日序列不完整，缺失{len(missing_days)}日：{preview}"
        )
    return result


def v13_momentum_schedule(
    product: str, close: pd.Series, ohlcv: pd.DataFrame | None = None
) -> pd.DataFrame:
    indicator_close = close.copy()
    score = calc_v13_momentum_score(product, indicator_close)
    abs20 = (indicator_close / indicator_close.shift(20) - 1.0).rename("abs20")
    abs40 = (indicator_close / indicator_close.shift(40) - 1.0).rename("abs40")
    if product == "IC":
        old_score = calc_v13_momentum_score(
            product, indicator_close, rule_override=IC_MOMENTUM_PREVIOUS_RULE
        )
        score = old_score.where(
            indicator_close.index < pd.Timestamp(IC_MOMENTUM_EFFECTIVE_SIGNAL_DATE), score
        )
        formal_start = pd.Timestamp(MOMENTUM_RULES[product]["formal_start"])
        close = indicator_close.loc[indicator_close.index >= formal_start]
        if close.empty or close.index[0] != formal_start:
            raise RuntimeError(
                "IC OHLCV必须完整覆盖2007-01-15起正式期；截断历史会重置NAV防御高水位"
            )
        score = score.reindex(close.index)
        abs20 = abs20.reindex(close.index)
        abs40 = abs40.reindex(close.index)
        if not np.isfinite(float(score.iloc[0])) or not np.isfinite(float(abs20.iloc[0])):
            raise RuntimeError("IC OHLCV缺少正式期起点所需指标暖机历史")
    abs20_reentry_confirmed = _recovery_confirmed(abs20)
    legacy_abs20_on = abs20 > 0
    abs20_on = legacy_abs20_on.where(
        close.index < pd.Timestamp(MOMENTUM_DEBOUNCE_EFFECTIVE_DATE),
        abs20_reentry_confirmed,
    )
    if product == "IC":
        old_signal_day = close.index < pd.Timestamp(IC_MOMENTUM_EFFECTIVE_SIGNAL_DATE)
        active_abs = abs20.where(old_signal_day, abs40).rename("abs_momentum")
        active_abs_days = pd.Series(
            np.where(old_signal_day, 20, 40), index=close.index, name="abs_momentum_days"
        )
        active_abs_on = abs20_on.where(old_signal_day, abs40.gt(0.0))
        abs_debounce_active = pd.Series(False, index=close.index, name="abs_debounce_active")
        abs_debounce_active.loc[old_signal_day] = (
            close.index[old_signal_day] >= pd.Timestamp(MOMENTUM_DEBOUNCE_EFFECTIVE_DATE)
        )
    else:
        active_abs = abs20.rename("abs_momentum")
        active_abs_days = pd.Series(20, index=close.index, name="abs_momentum_days")
        active_abs_on = abs20_on
        abs_debounce_active = pd.Series(
            close.index >= pd.Timestamp(MOMENTUM_DEBOUNCE_EFFECTIVE_DATE),
            index=close.index, name="abs_debounce_active"
        )
    base_target = (score > 0).astype(float) * (0.5 + 0.5 * active_abs_on.astype(float))
    volume_ratio = pd.Series(np.nan, index=close.index, name="volume_ratio")
    volume_pass = pd.Series(True, index=close.index, name="volume_pass")
    volume_placeholder = pd.Series(False, index=close.index, name="volume_placeholder")
    score_hot_signal = pd.Series(False, index=close.index, name="score_hot_signal")
    base_nav = pd.Series(np.nan, index=close.index, name="base_nav_for_dd")
    base_dd = pd.Series(np.nan, index=close.index, name="base_dd_for_gate")
    nav_decay_signal = pd.Series(False, index=close.index, name="nav_decay_signal")
    target = base_target.copy()
    if product == "IC":
        if ohlcv is None:
            raise RuntimeError("IC 1.3 NAV防守必须使用可验证OHLCV")
        rule = MOMENTUM_RULES[product]
        base_execution = base_target.shift(1, fill_value=0.0)
        raw_ret = close.pct_change().fillna(0.0)
        turnover = base_execution.diff().abs().fillna(base_execution.abs())
        daily_cash = (1.0 + float(rule["annual_cash_yield"])) ** (1.0 / 244.0) - 1.0
        cash_ret = (1.0 - base_execution).clip(lower=0.0, upper=1.0) * daily_cash
        if not cash_ret.empty:
            cash_ret.iloc[0] = 0.0
        base_ret = (
            base_execution * raw_ret
            + cash_ret
            - float(rule["cost_rate"]) * turnover
        )
        base_nav = (1.0 + base_ret).cumprod().rename("base_nav_for_dd")
        base_dd = (base_nav / base_nav.cummax() - 1.0).rename("base_dd_for_gate")
        nav_decay_signal = base_dd.le(-float(rule["nav_decay_threshold"])).rename(
            "nav_decay_signal"
        )
        target = base_target.where(
            ~nav_decay_signal,
            base_target * float(rule["nav_decay_scale"]),
        )
    elif product == "IM":
        if ohlcv is None:
            raise RuntimeError("IM 1.3动量必须使用可验证OHLCV，不能只传收盘价")
        aligned = ohlcv.reindex(close.index)
        if aligned[["volume"]].isna().any().any():
            raise RuntimeError("IM 1.3 OHLCV与收盘价日期错位")
        volume = pd.to_numeric(aligned["volume"], errors="coerce")
        rule = MOMENTUM_RULES[product]
        volume_ratio = (
            volume / volume.rolling(int(rule["volume_ma"])).mean()
        ).rename("volume_ratio")
        if "realtime_volume_placeholder" in aligned.columns:
            volume_placeholder = aligned["realtime_volume_placeholder"].eq(True)
            volume_ratio.loc[volume_placeholder] = volume_ratio.shift(1).loc[volume_placeholder]
        volume_pass = (
            (volume_ratio >= float(rule["volume_ratio_threshold"]))
            .where(volume_ratio.notna(), bool(rule["volume_warmup_passes"]))
            .astype(bool)
            .rename("volume_pass")
        )
        if volume_placeholder.any():
            volume_pass.loc[volume_placeholder] = volume_pass.shift(
                1, fill_value=True
            ).loc[volume_placeholder]
        target = base_target.where(volume_pass, 0.0)
        score_hot_signal = (
            (score >= float(rule["hot_score_threshold"])) & target.gt(0.0)
        ).rename("score_hot_signal")
        target = target.where(
            ~score_hot_signal, target * float(rule["hot_scale"])
        )
    target = target.rename("signal_target")
    return pd.DataFrame(
        {
            "close": close,
            "momentum_score": score,
            "abs20": abs20,
            "abs40": abs40,
            "abs20_reentry_confirmed": abs20_reentry_confirmed,
            "abs_momentum": active_abs,
            "abs_momentum_days": active_abs_days,
            "abs_momentum_on": active_abs_on,
            "abs_debounce_active": abs_debounce_active,
            "base_signal_target": base_target,
            "volume_ratio": volume_ratio,
            "volume_pass": volume_pass,
            "volume_placeholder": volume_placeholder,
            "score_hot_signal": score_hot_signal,
            "base_nav_for_dd": base_nav,
            "base_dd_for_gate": base_dd,
            "nav_decay_signal": nav_decay_signal,
            "signal_target": target,
            "execution_weight": target.shift(1, fill_value=0.0),
        }
    )


def _proxy_score_for_price(product: str, price: float) -> float:
    ratio = float(price) / float(FROZEN[product]["price"])
    proxy_pb = float(FROZEN[product]["pb"]) * ratio
    proxy_pe = float(FROZEN[product]["pe"]) * ratio
    proxy_erp = 1.0 / proxy_pe - float(FROZEN[product]["gov10y"])
    return valuation_score(proxy_pb, proxy_erp, float(FROZEN[product]["dividend"]))


def _momentum_120_at(close: pd.Series, index: int) -> float:
    if len(close) < 122 or abs(index) > len(close):
        raise RuntimeError("价格历史不足以计算前一日MOM120")
    position = index if index >= 0 else len(close) + index
    anchor = position - 120
    if anchor < 0:
        raise RuntimeError("价格历史不足以计算前一日MOM120")
    return float(close.iloc[position] / close.iloc[anchor] - 1.0)


def _replay_v13_grid(product: str, prices: pd.Series) -> tuple[float, float]:
    """Return current grid units and the newest T-close target for T+1 open."""

    state = float(V13_FROZEN[product]["grid_units"])
    eligible = prices[prices.index.date > DATA_CUTOFF]
    if eligible.empty:
        return state, state
    for stamp, value in eligible.iloc[:-1].items():
        rule = grid_rule(product, stamp.date())
        state = min(state, rule["units"])
        score = _proxy_score_for_price(product, float(value))
        if score <= rule["entry"]:
            state = rule["units"]
        elif score >= rule["exit"]:
            state = 0.0
    rule = grid_rule(product, eligible.index[-1].date())
    target = min(state, rule["units"])
    last_score = _proxy_score_for_price(product, float(eligible.iloc[-1]))
    if last_score <= rule["entry"]:
        target = rule["units"]
    elif last_score >= rule["exit"]:
        target = 0.0
    return state, target


def _request_json(url: str, params: dict[str, Any]) -> dict[str, Any]:
    error: Exception | None = None
    for timeout in (5, 8):
        try:
            response = _evidence_http_get(
                url,
                params=params,
                timeout=_bounded_timeout(timeout),
                headers={
                    "User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                },
            )
            response.raise_for_status()
            return response.json()
        except requests.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else None
            if status is not None and status < 500 and status not in {408, 429}:
                raise RuntimeError(f"行情接口拒绝请求（HTTP {status}）") from exc
            error = exc
        except (requests.ConnectionError, requests.Timeout, ValueError) as exc:
            error = exc
    raise RuntimeError(f"行情接口不可用: {error}")


def _validate_live_index_stamp(
    product: str, stamp: datetime, clock: datetime, observation_clock: datetime,
) -> None:
    """Keep a live index observation on its signal day and before receipt time.

    Lunch quotes may retain the morning update; there is deliberately no new
    minute-age threshold. The 09:15 lower bound matches the existing cash-market
    quote guard, and 15:00 is the end of the cash-index trading session.
    """
    clock = _beijing_clock(clock)
    observed = _beijing_clock(observation_clock)
    if observed.tzinfo is None:
        observed = observed.replace(tzinfo=BEIJING)
    if stamp.tzinfo is None:
        raise ValueError(f"{product} 指数报价缺少带时区的供应商时间")
    stamp = stamp.astimezone(BEIJING)
    if stamp.date() != clock.date():
        raise ValueError(f"{product} 指数报价日期与当前信号日不一致")
    if not time(9, 15) <= stamp.time() <= time(15, 0):
        raise ValueError(f"{product} 指数报价时间不在有效交易时段")
    if stamp > observed:
        raise ValueError(f"{product} 指数报价时间晚于实际采集时刻")


def fetch_live_price_quote(product: str) -> dict[str, Any]:
    # Tencent is the low-latency primary quote. EastMoney remains a compatible
    # fallback because Poe egress rules can differ between deployments.
    clock = _beijing_clock(_now_beijing())
    collection_started = time_module.monotonic()
    symbol = TENCENT_SYMBOLS[product]
    try:
        response = _evidence_http_get(
            f"https://qt.gtimg.cn/q={symbol}",
            timeout=_bounded_timeout(6),
            headers={
                "User-Agent": "Mozilla/5.0",
                "Referer": "https://finance.qq.com/",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
            },
        )
        response.raise_for_status()
        # The request is for one symbol. A whole-response match rejects wrong
        # variable names, prefixed identifiers and duplicate/conflicting rows.
        match = re.fullmatch(
            rf'\s*(?:var\s+)?v_{re.escape(symbol)}\s*=\s*"([^"\r\n]*)"\s*;?\s*',
            response.content.decode("gbk"),
        )
        if match is None:
            raise ValueError("腾讯指数变量身份不一致或响应不唯一")
        fields = match.group(1).split("~")
        if len(fields) < 31 or fields[2] != symbol[2:]:
            raise ValueError("腾讯指数内嵌代码不一致或报价字段不足")
        price = float(fields[3])
        if not re.fullmatch(r"[0-9]{14}", fields[30]):
            raise ValueError("腾讯指数供应商时间格式无效")
        stamp = datetime.strptime(fields[30], "%Y%m%d%H%M%S").replace(
            tzinfo=BEIJING
        )
        _validate_live_index_stamp(
            product, stamp, clock, _iv_observation_clock(clock, collection_started),
        )
        if math.isfinite(price) and price > 0:
            return {
                "price": price,
                "source": "腾讯财经",
                "source_date": stamp.date(),
                "source_time": stamp.strftime("%H:%M:%S"),
            }
    except (requests.RequestException, ValueError, IndexError):
        pass

    payload = _request_json(
        "https://push2.eastmoney.com/api/qt/stock/get",
        {
            "secid": EASTMONEY_SECIDS[product],
            "fields": "f43,f44,f45,f57,f58,f60,f86",
            "ut": "fa5fd1943c7b386f172d6893dbfba10b",
        },
    )
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict) or data.get("f57") != EASTMONEY_SECIDS[product].split(".", 1)[1]:
        raise RuntimeError(f"东方财富 {product} 指数报价标的身份缺失或不一致")
    try:
        if isinstance(data.get("f43"), bool):
            raise ValueError("boolean price")
        price = float(data.get("f43", 0)) / 100.0
    except (TypeError, ValueError, OverflowError) as exc:
        raise RuntimeError(f"{product} 未取得有效实时价格") from exc
    if not math.isfinite(price) or price <= 0:
        raise RuntimeError(f"{product} 未取得有效实时价格")
    try:
        if isinstance(data["f86"], bool):
            raise ValueError("boolean timestamp")
        raw_stamp = float(data["f86"])
        if not math.isfinite(raw_stamp):
            raise ValueError("non-finite timestamp")
        stamp = datetime.fromtimestamp(raw_stamp, tz=BEIJING)
        if not 2000 <= stamp.year <= 2100:
            raise ValueError("timestamp out of range")
    except (KeyError, TypeError, ValueError, OSError, OverflowError) as exc:
        raise RuntimeError(f"东方财富 {product} 指数报价缺少有效供应商更新时间") from exc
    try:
        _validate_live_index_stamp(
            product, stamp, clock, _iv_observation_clock(clock, collection_started),
        )
    except ValueError as exc:
        raise RuntimeError(f"东方财富 {product} 指数报价供应商时间无效: {exc}") from exc
    return {
        "price": price,
        "source": "东方财富",
        "source_date": stamp.date(),
        "source_time": stamp.strftime("%H:%M:%S"),
    }


def fetch_live_price(product: str) -> float:
    return float(fetch_live_price_quote(product)["price"])


def fetch_price_history(product: str) -> pd.Series:
    try:
        key = TENCENT_SYMBOLS[product]
        payload = _request_json(
            "https://web.ifzq.gtimg.cn/appstock/app/kline/kline",
            {"param": f"{key},day,,,260"},
        )
        rows = ((payload.get("data") or {}).get(key) or {}).get("day") or []
        points = [
            (pd.Timestamp(row[0]), float(row[2])) for row in rows if len(row) >= 3
        ]
        if len(points) >= 121:
            return pd.Series(dict(points), dtype=float).sort_index()
    except (requests.RequestException, RuntimeError, ValueError, TypeError, IndexError):
        pass

    payload = _request_json(
        "https://push2his.eastmoney.com/api/qt/stock/kline/get",
        {
            "secid": EASTMONEY_SECIDS[product],
            "klt": "101",
            "fqt": "0",
            "lmt": "260",
            "end": "20500101",
            "fields1": "f1,f2,f3,f4,f5,f6",
            "fields2": "f51,f52,f53,f54,f55,f56",
            "ut": "fa5fd1943c7b386f172d6893dbfba10b",
        },
    )
    klines = (payload.get("data") or {}).get("klines") or []
    points = [
        (pd.Timestamp(parts[0]), float(parts[2]))
        for row in klines
        if len(parts := row.split(",")) >= 3
    ]
    if len(points) < 121:
        raise RuntimeError(f"{product} 价格历史不足120个交易日")
    return pd.Series(dict(points), dtype=float).sort_index()


class SignalTransportError(RuntimeError, requests.ConnectionError):
    """All attempted sources failed in transport, not data validation."""


def _source_failure_error(message: str, errors: list[Exception]) -> RuntimeError:
    """Keep retries for wholly transient source failures, never malformed data."""
    if (signal_evidence.current_reader.get() is not None
            and any(isinstance(exc, signal_evidence.EvidenceUnavailable) for exc in errors)):
        # A failed primary may be absent when an archived alternate succeeds.
        # If none succeeds, preserve the evidence diagnosis instead of making
        # an offline missing-input failure look like an ordinary source outage.
        return signal_evidence.EvidenceUnavailable("原日存证缺失或无效；" + message)
    transport = (requests.ConnectionError, requests.Timeout, requests.exceptions.ChunkedEncodingError)
    if errors and all(isinstance(exc, transport) for exc in errors):
        return SignalTransportError(message)
    return RuntimeError(message)


def _fetch_tencent_ohlcv_history(product: str, clock: datetime) -> pd.DataFrame:
    """Fetch Tencent daily index OHLCV in same-source pages and validate once."""

    symbol = TENCENT_SYMBOLS[product]
    history_start = V13_HISTORY_DATE_INDEX[product][0]
    expected_day = _latest_completed_exchange_day(clock)
    all_rows: dict[date, tuple[str, ...]] = {}
    page_manifest: list[dict[str, Any]] = []
    probing = bool(_OHLCV_FRESHNESS_PROBE.get())
    year = history_start.year
    first_page = True
    page_number = 0

    while True:
        page_start = (max(history_start, expected_day - timedelta(days=30)) if probing
                      else history_start if first_page else date(year, 1, 1))
        page_end = (expected_day if probing else min(
            date(year + TENCENT_OHLCV_PAGE_STEP_YEARS, 1, 31), expected_day
        ))
        if page_end < page_start:
            raise RuntimeError(
                f"{product} Tencent分页日期无效：{page_start}至{page_end}"
            )

        page_number += 1
        params = {
            "param": (
                f"{symbol},day,{page_start.isoformat()},{page_end.isoformat()},"
                f"{TENCENT_OHLCV_PAGE_COUNT},qfq"
            )
        }
        started_at = datetime.now(BEIJING)
        timeout_seconds = _bounded_timeout(TENCENT_OHLCV_TIMEOUT_SECONDS)
        response = None
        raw = b""
        downloaded = 0
        declared_size: int | None = None
        response_url = TENCENT_OHLCV_HISTORY_URL
        http_status: Any = "unknown"
        try:
            try:
                response = _evidence_http_get(
                    TENCENT_OHLCV_HISTORY_URL,
                    params=params,
                    timeout=timeout_seconds,
                    headers={
                        "User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
                        "Referer": "https://gu.qq.com/",
                        "Cache-Control": "no-cache",
                        "Pragma": "no-cache",
                    },
                    stream=True,
                )
            except requests.exceptions.ChunkedEncodingError as exc:
                ended_at = datetime.now(BEIJING)
                message = (
                    f"{product} Tencent分页连接中断：window={page_start}..{page_end}; "
                    f"started={started_at.isoformat()}; ended={ended_at.isoformat()}; "
                    f"error={exc}"
                )
                raise requests.ConnectionError(
                    message, request=exc.request, response=exc.response
                ) from exc
            except (requests.ConnectionError, requests.Timeout) as exc:
                ended_at = datetime.now(BEIJING)
                message = (
                    f"{product} Tencent分页连接失败：window={page_start}..{page_end}; "
                    f"timeout={timeout_seconds:.3f}s; started={started_at.isoformat()}; "
                    f"ended={ended_at.isoformat()}; error={exc}"
                )
                raise type(exc)(message) from exc

            response_url = str(getattr(response, "url", TENCENT_OHLCV_HISTORY_URL))
            http_status = getattr(response, "status_code", "unknown")
            _bounded_timeout(TENCENT_OHLCV_TIMEOUT_SECONDS)
            response.raise_for_status()
            response_headers = getattr(response, "headers", {}) or {}
            declared_header = response_headers.get("Content-Length")
            if declared_header not in (None, ""):
                try:
                    declared_size = int(declared_header)
                except (TypeError, ValueError) as exc:
                    raise RuntimeError(
                        f"{product} Tencent分页Content-Length非法：{declared_header!r}"
                    ) from exc
                if declared_size < 0:
                    raise RuntimeError(
                        f"{product} Tencent分页Content-Length为负数：{declared_size}"
                    )
                if declared_size > MAX_QUOTE_RESPONSE_BYTES:
                    raise RuntimeError(
                        f"{product} Tencent分页响应声明大小超过"
                        f"{MAX_QUOTE_RESPONSE_BYTES}字节：{declared_size}"
                    )

            chunks: list[bytes] = []
            stream = iter(response.iter_content(chunk_size=64 * 1024))
            while True:
                # The request timeout is per socket read. Check the shared
                # product budget both before and after every streamed chunk.
                _bounded_timeout(TENCENT_OHLCV_TIMEOUT_SECONDS)
                try:
                    chunk = next(stream)
                except StopIteration:
                    break
                _bounded_timeout(TENCENT_OHLCV_TIMEOUT_SECONDS)
                if not chunk:
                    continue
                if not isinstance(chunk, (bytes, bytearray)):
                    raise RuntimeError(
                        f"{product} Tencent分页流返回非字节块：{type(chunk).__name__}"
                    )
                if len(chunk) > MAX_QUOTE_RESPONSE_BYTES - downloaded:
                    raise RuntimeError(
                        f"{product} Tencent分页响应累计大小超过"
                        f"{MAX_QUOTE_RESPONSE_BYTES}字节"
                    )
                downloaded += len(chunk)
                chunks.append(bytes(chunk))
                _bounded_timeout(TENCENT_OHLCV_TIMEOUT_SECONDS)

            raw = b"".join(chunks)
            ended_at = datetime.now(BEIJING)
            response_sha256 = hashlib.sha256(raw).hexdigest()
            response_audit = (
                f"window={page_start}..{page_end}; url={response_url}; "
                f"http={http_status}; bytes={downloaded}; "
                f"content_length={declared_size}; sha256={response_sha256}; "
                f"started={started_at.isoformat()}; ended={ended_at.isoformat()}"
            )
            _bounded_timeout(TENCENT_OHLCV_TIMEOUT_SECONDS)
            try:
                payload = json.loads(raw)
            except (UnicodeDecodeError, ValueError) as exc:
                raise RuntimeError(
                    f"{product} Tencent分页JSON解析失败：{response_audit}; error={exc}"
                ) from exc
            _bounded_timeout(TENCENT_OHLCV_TIMEOUT_SECONDS)
        except requests.exceptions.ChunkedEncodingError as exc:
            ended_at = datetime.now(BEIJING)
            message = (
                f"{product} Tencent分页流连接中断：window={page_start}..{page_end}; "
                f"url={response_url}; http={http_status}; bytes={downloaded}; "
                f"started={started_at.isoformat()}; ended={ended_at.isoformat()}; "
                f"error={exc}"
            )
            raise requests.ConnectionError(
                message, request=exc.request, response=exc.response or response
            ) from exc
        except requests.HTTPError as exc:
            ended_at = datetime.now(BEIJING)
            raise RuntimeError(
                f"{product} Tencent分页HTTP失败：window={page_start}..{page_end}; "
                f"url={response_url}; http={http_status}; "
                f"started={started_at.isoformat()}; ended={ended_at.isoformat()}; "
                f"error={exc}"
            ) from exc
        except (requests.ConnectionError, requests.Timeout) as exc:
            ended_at = datetime.now(BEIJING)
            message = (
                f"{product} Tencent分页连接失败：window={page_start}..{page_end}; "
                f"url={response_url}; http={http_status}; bytes={downloaded}; "
                f"started={started_at.isoformat()}; ended={ended_at.isoformat()}; "
                f"error={exc}"
            )
            raise type(exc)(message) from exc
        finally:
            if response is not None:
                response.close()

        if not isinstance(payload, dict):
            raise RuntimeError(
                f"{product} Tencent分页响应JSON类型错误：{type(payload).__name__}; "
                f"{response_audit}"
            )
        api_code = payload.get("code")
        api_message = payload.get("msg")
        if api_code not in (0, "0") or api_message not in (None, "", "ok"):
            raise RuntimeError(
                f"{product} Tencent OHLCV API拒绝请求：code={api_code!r}, "
                f"msg={api_message!r}; {response_audit}"
            )

        data = payload.get("data")
        node = data.get(symbol) if isinstance(data, dict) else None
        if not isinstance(node, dict):
            raise RuntimeError(
                f"{product} Tencent分页缺少{symbol}数据节点，"
                f"{response_audit}"
            )
        row_key = next(
            (key for key in ("qfqday", "day") if node.get(key)), None
        )
        raw_rows = node.get(row_key) if row_key else None
        if not isinstance(raw_rows, list) or not raw_rows:
            raise RuntimeError(
                f"{product} Tencent分页无日线数据，window={page_start}..{page_end}; "
                f"node_keys={list(node)}; {response_audit}"
            )

        page_dates: list[date] = []
        page_seen: set[date] = set()
        filtered_before_history_start = 0
        accepted_rows: list[tuple[date, tuple[str, ...]]] = []
        for item in raw_rows:
            if not isinstance(item, (list, tuple)) or len(item) < 6:
                raise RuntimeError(
                    f"{product} Tencent分页行字段不足6项，"
                    f"window={page_start}..{page_end}"
                )
            row = tuple(str(value) for value in item[:6])
            try:
                row_day = date.fromisoformat(row[0][:10])
            except ValueError as exc:
                raise RuntimeError(
                    f"{product} Tencent分页日期非法：{row[0]!r}"
                ) from exc
            if row_day in page_seen:
                raise RuntimeError(
                    f"{product} Tencent分页内部日期重复：{row_day}"
                )
            page_seen.add(row_day)
            page_dates.append(row_day)
            if row_day > expected_day:
                raise RuntimeError(
                    f"{product} Tencent分页含未来日期：{row_day} > {expected_day}"
                )
            if row_day < history_start:
                filtered_before_history_start += 1
                continue
            accepted_rows.append((row_day, row))

        for row_day, row in accepted_rows:
            prior = all_rows.get(row_day)
            if prior is not None and prior != row:
                raise RuntimeError(
                    f"{product} Tencent分页重叠行冲突：{row_day}; "
                    f"prior={prior!r}; current={row!r}"
                )

        # Do not accept page rows or continue to another request after the
        # shared signal budget has expired while parsing this response.
        _bounded_timeout(TENCENT_OHLCV_TIMEOUT_SECONDS)
        for row_day, row in accepted_rows:
            all_rows[row_day] = row

        page_manifest.append(
            {
                "page": page_number,
                "purpose": "freshness_probe" if probing else "history_page",
                "window_start": page_start.isoformat(),
                "window_end": page_end.isoformat(),
                "started_at": started_at.isoformat(),
                "ended_at": ended_at.isoformat(),
                "elapsed_seconds": round((ended_at - started_at).total_seconds(), 3),
                "http_status": int(http_status),
                "request_url": response_url,
                "params": params,
                "response_bytes": downloaded,
                "response_sha256": response_sha256,
                "api_code": api_code,
                "api_msg": api_message,
                "row_key": row_key,
                "raw_row_count": len(raw_rows),
                "filtered_before_history_start": filtered_before_history_start,
                "first_response_date": min(page_dates).isoformat(),
                "last_response_date": max(page_dates).isoformat(),
                "accepted_row_count": len(accepted_rows),
                "count_cap_reached": len(raw_rows) >= TENCENT_OHLCV_PAGE_COUNT,
            }
        )

        if probing:
            probe_values = np.asarray(
                [[float(value) for value in row[1:6]] for _, row in accepted_rows],
                dtype=float,
            )
            if (probe_values.size == 0 or not np.isfinite(probe_values).all()
                    or (probe_values <= 0).any()
                    or (probe_values[:, 2] < probe_values[:, :2].max(axis=1)).any()
                    or (probe_values[:, 3] > probe_values[:, :2].min(axis=1)).any()
                    or not 1_000_000.0 <= float(np.median(probe_values[:, 4]))
                    * TENCENT_OHLCV_VOLUME_TO_SHARES <= 1_000_000_000_000.0):
                raise RuntimeError(f"{product} Tencent最新页OHLCV价格或成交量无效")
            if max(page_dates) < expected_day:
                raise DailyOHLCVNotReady(
                    f"{product} Tencent最新日线尚未更新：最新{max(page_dates)}，"
                    f"应覆盖{expected_day}；等待完整日线（含成交量）后重试"
                )
            # The recent page proves only freshness, never warmup/history
            # completeness. Fetch and validate the full same-source history.
            # Keep its rows so conflicting overlap is still rejected.
            probing = False
            continue
        if page_end >= expected_day:
            break
        year += TENCENT_OHLCV_PAGE_STEP_YEARS
        first_page = False

    if not all_rows:
        raise RuntimeError(f"{product} Tencent OHLCV合并后为空")
    records = []
    for row_day in sorted(all_rows):
        row = all_rows[row_day]
        records.append(
            {
                "date": row_day,
                "open": float(row[1]),
                "close": float(row[2]),
                "high": float(row[3]),
                "low": float(row[4]),
                "volume": float(row[5]) * TENCENT_OHLCV_VOLUME_TO_SHARES,
            }
        )
    frame = (
        pd.DataFrame(records)
        .assign(date=lambda value: pd.to_datetime(value["date"], errors="raise"))
        .set_index("date")
        .sort_index()
    )
    frame.attrs.update(
        {
            "source": "Tencent",
            "source_api": "Tencent newfqkline",
            "source_adjustment": "qfq",
            "source_volume_scale": TENCENT_OHLCV_VOLUME_TO_SHARES,
            "source_page_manifest": page_manifest,
        }
    )
    _bounded_timeout(TENCENT_OHLCV_TIMEOUT_SECONDS)
    validated = _validate_v13_ohlcv(product, frame, clock)
    _bounded_timeout(TENCENT_OHLCV_TIMEOUT_SECONDS)
    validated.attrs.update(frame.attrs)
    return validated


def fetch_ohlcv_history(product: str) -> pd.DataFrame:
    """Fetch raw daily index OHLCV using the A-share v1.3 source order."""

    symbol = TENCENT_SYMBOLS[product]
    errors: list[str] = []
    causes: list[Exception] = []
    try:
        response = _evidence_http_get(
            "https://money.finance.sina.com.cn/quotes_service/api/json_v2.php"
            f"/CN_MarketData.getKLineData?symbol={symbol}&scale=240&ma=no&datalen=10000",
            timeout=_bounded_timeout(10),
            headers={"User-Agent": "Mozilla/5.0", "Referer": "https://finance.sina.com.cn/"},
        )
        response.raise_for_status()
        payload = response.json()
        rows = [
            {
                "date": item["day"],
                "open": float(item["open"]),
                "high": float(item["high"]),
                "low": float(item["low"]),
                "close": float(item["close"]),
                "volume": float(item["volume"]),
            }
            for item in payload
        ]
        if len(rows) >= 180:
            frame = pd.DataFrame(rows).assign(date=lambda x: pd.to_datetime(x["date"])).set_index("date").sort_index()
            frame.attrs["source"] = "Sina"
            _validate_v13_ohlcv(product, frame, _now_beijing())
            return frame
        raise RuntimeError("Sina OHLCV不足180行")
    except Exception as exc:
        errors.append(f"Sina: {type(exc).__name__}: {exc}")
        causes.append(exc)
    try:
        payload = _request_json(
            "https://push2his.eastmoney.com/api/qt/stock/kline/get",
            {
                "secid": EASTMONEY_SECIDS[product],
                "klt": "101",
                "fqt": "0",
                "lmt": "10000",
                "end": "20500101",
                "fields1": "f1,f2,f3,f4,f5,f6",
                "fields2": "f51,f52,f53,f54,f55,f56,f57",
                "ut": "fa5fd1943c7b386f172d6893dbfba10b",
            },
        )
        klines = (payload.get("data") or {}).get("klines") or []
        rows = []
        for row in klines:
            parts = str(row).split(",")
            if len(parts) < 6:
                raise RuntimeError("Eastmoney OHLCV字段不足")
            rows.append(
                {
                    "date": parts[0], "open": float(parts[1]), "close": float(parts[2]),
                    "high": float(parts[3]), "low": float(parts[4]), "volume": float(parts[5]),
                }
            )
        if len(rows) >= 180:
            frame = pd.DataFrame(rows).assign(date=lambda x: pd.to_datetime(x["date"])).set_index("date").sort_index()
            frame.attrs["source"] = "Eastmoney"
            _validate_v13_ohlcv(product, frame, _now_beijing())
            frame.attrs["source_failures"] = list(errors)
            return frame
        raise RuntimeError("Eastmoney OHLCV不足180行")
    except Exception as exc:
        errors.append(f"Eastmoney: {type(exc).__name__}: {exc}")
        causes.append(exc)
    probe_token = _OHLCV_FRESHNESS_PROBE.set(
        any(isinstance(exc, DailyOHLCVNotReady) for exc in causes)
    )
    try:
        try:
            frame = _fetch_tencent_ohlcv_history(product, _now_beijing())
            frame.attrs["source_failures"] = list(errors)
            return frame
        except Exception as exc:
            errors.append(f"Tencent: {type(exc).__name__}: {exc}")
            causes.append(exc)
    finally:
        _OHLCV_FRESHNESS_PROBE.reset(probe_token)
    if causes and all(isinstance(exc, DailyOHLCVNotReady) for exc in causes):
        error_type = DailyOHLCVNotReady
    elif causes and all(isinstance(exc, (requests.ConnectionError, requests.Timeout)) for exc in causes):
        error_type = SignalTransportError
    else:
        error_type = DailyOHLCVSourcesUnavailable
    error = error_type(f"{product} OHLCV全部来源失败：{'；'.join(errors)}")
    error.source_failures = [
        {"source": source, "type": type(cause).__name__, "reason": str(cause),
         "status": getattr(cause, "status", None)}
        for source, cause in zip(("Sina", "Eastmoney", "Tencent"), causes)
    ]
    error.waiting_sources = [
        source for source, cause in zip(("Sina", "Eastmoney", "Tencent"), causes)
        if isinstance(cause, DailyOHLCVNotReady)
    ]
    raise error


def _validated_price_history(
    product: str, history: pd.Series, clock: datetime
) -> pd.Series:
    result = pd.to_numeric(history.copy(), errors="coerce")
    index = pd.DatetimeIndex(pd.to_datetime(result.index, errors="raise"))
    if index.tz is not None:
        index = index.tz_convert(BEIJING).tz_localize(None)
    index = index.normalize()
    result.index = index
    replay_day = _HISTORICAL_REPLAY_DAY.get()
    if replay_day is not None:
        if replay_day != clock.date():
            raise RuntimeError(
                f"{product}历史重放日 {replay_day} 与运行时钟 {clock.date()} 不一致"
            )
        result = result.loc[result.index.date <= replay_day]
    if result.empty or result.index.has_duplicates or not result.index.is_monotonic_increasing:
        raise RuntimeError(f"{product} 价格历史日期为空、重复或乱序")
    values = result.to_numpy(dtype=float)
    if not np.isfinite(values).all() or (values <= 0).any():
        raise RuntimeError(f"{product} 价格历史含NaN、无穷值或非正价格，暂停生成信号")
    if result.index[-1].date() > clock.date():
        raise RuntimeError(
            f"{product} 价格历史日期 {result.index[-1].date()} 晚于北京时间 {clock.date()}"
        )
    expected = _latest_completed_exchange_day(clock)
    if result.index[-1].date() < expected:
        raise RuntimeError(
            f"{product} 价格历史已过期：最新 {result.index[-1].date()}，"
            f"至少应覆盖最近已完成交易日 {expected}；暂停生成信号"
        )
    return result


def live_proxy(product: str, clock: datetime | None = None) -> dict[str, Any]:
    clock = _beijing_clock(clock or _now_beijing())
    ohlcv: pd.DataFrame | None = None
    if product in {"IC", "IM"}:
        with runtime_clock(clock):
            ohlcv = _validate_v13_ohlcv(product, fetch_ohlcv_history(product), clock)
        history = ohlcv["close"].copy()
    else:
        history = _validated_price_history(product, fetch_price_history(product), clock)
    replay_day = _HISTORICAL_REPLAY_DAY.get()
    if replay_day is not None:
        if history.index[-1].date() != replay_day:
            raise RuntimeError(
                f"{product}价格历史缺少待补账交易日 {replay_day} 的正式收盘"
            )
        live_price = float(history.iloc[-1])
        live_quote = {
            "price": live_price,
            "source": "指数公开日线历史收盘",
            "source_date": replay_day,
            "source_time": "15:00:00",
        }
    elif _market_phase(clock) not in {"集合竞价", "盘中", "午间休市"}:
        live_price = float(history.iloc[-1])
        live_quote = {"price": live_price, "source": "指数公开日线历史收盘",
                      "source_date": history.index[-1].date(), "source_time": "15:00:00"}
    else:
        with runtime_clock(clock), collection_clock(clock):
            live_quote = fetch_live_price_quote(product)
            # Validate at the consuming boundary too: a named/cache adapter
            # must not turn a same-day future or missing-time tick into a bar.
            try:
                raw_time = live_quote.get("source_time")
                if not isinstance(raw_time, str) or not re.fullmatch(r"[0-9]{2}:[0-9]{2}:[0-9]{2}", raw_time):
                    raise ValueError("指数报价缺少完整供应商时间")
                source_day = live_quote.get("source_date")
                if type(source_day) is not date:
                    raise ValueError("指数报价缺少有效供应商日期")
                stamp = datetime.combine(
                    source_day, datetime.strptime(raw_time, "%H:%M:%S").time(), tzinfo=BEIJING,
                )
                _validate_live_index_stamp(product, stamp, clock, _iv_observation_clock(clock))
            except (TypeError, ValueError) as exc:
                raise RuntimeError(f"{product} 实时报价时间校验失败: {exc}") from exc
        live_price = float(live_quote["price"])
        if not math.isfinite(live_price) or live_price <= 0:
            raise RuntimeError(f"{product} 实时报价含NaN、无穷值或非正价格")
    phase = _market_phase(clock)
    live_day = pd.Timestamp(clock.date())
    if replay_day is not None:
        pass
    elif (
        _is_exchange_trading_day(clock.date())
        and phase in {"集合竞价", "盘中", "午间休市", "收盘后"}
        and history.index[-1].date() < clock.date()
    ):
        if live_quote.get("source_date") != clock.date():
            raise RuntimeError(
                f"{product} 实时报价缺少{clock.date()}可验证时间戳，"
                "禁止把陈旧价格写成当日盘中价"
            )
        history.loc[live_day] = live_price
        if ohlcv is not None:
            previous_volume = float(ohlcv["volume"].iloc[-1])
            ohlcv.loc[live_day, ["open", "high", "low", "close", "volume"]] = [
                live_price, live_price, live_price, live_price, previous_volume
            ]
            ohlcv.loc[live_day, "realtime_volume_placeholder"] = True
    elif (
        _is_exchange_trading_day(clock.date())
        and phase in {"集合竞价", "盘中", "午间休市"}
        and history.index[-1].date() == clock.date()
    ):
        if live_quote.get("source_date") != clock.date():
            raise RuntimeError(f"{product} 当日未收盘K线缺少同日实时报价复核")
        history.iloc[-1] = live_price
        if ohlcv is not None:
            if len(ohlcv) < 2:
                raise RuntimeError(f"{product} OHLCV不足以冻结盘中成交量状态")
            previous_volume = float(ohlcv["volume"].iloc[-2])
            ohlcv.loc[live_day, ["open", "high", "low", "close", "volume"]] = [
                live_price, live_price, live_price, live_price, previous_volume
            ]
            ohlcv.loc[live_day, "realtime_volume_placeholder"] = True
    else:
        # Completed daily bars remain authoritative, including before opening
        # and on holidays. A latest quote is not a historical closing price.
        live_price = float(history.iloc[-1])
        live_quote = {
            "price": live_price, "source": "指数公开日线历史收盘",
            "source_date": history.index[-1].date(), "source_time": "15:00:00",
        }
    history = history[~history.index.duplicated(keep="last")].sort_index()
    if not np.isfinite(history.to_numpy(dtype=float)).all() or (history <= 0).any():
        raise RuntimeError(f"{product} 合并实时价格后的历史数据无效")
    if len(history) < 135:
        raise RuntimeError(f"{product} 价格历史不足以计算1.3动量分袖")
    ratio = live_price / float(FROZEN[product]["price"])
    proxy_pb = float(FROZEN[product]["pb"]) * ratio
    proxy_pe = float(FROZEN[product]["pe"]) * ratio
    proxy_erp = 1.0 / proxy_pe - float(FROZEN[product]["gov10y"])
    score = valuation_score(proxy_pb, proxy_erp, float(FROZEN[product]["dividend"]))
    valuation = daily_valuation.resolve(
        product, history.index[-1].date(), clock, price=live_price,
        frozen=FROZEN[product], anchor_day=DATA_CUTOFF,
    )
    gov10y = _resolve_gov10y_evidence(history.index[-1].date(), clock,
                              float(FROZEN[product]["gov10y"]), DATA_CUTOFF)
    valuation["provenance"]["gov10y"] = gov10y
    valuation["provenance"]["auxiliary_inputs"] = "股息和相对估值阈值沿用原冻结口径"
    used_erp = 1.0 / valuation["pe"] - gov10y["yield_decimal"]
    score = valuation_score(valuation["pb"], used_erp, float(FROZEN[product]["dividend"]))
    momentum = _momentum_120_at(history, -1)
    mom120_floor_active = bool(_mom120_floor_state(history).iloc[-1])
    targets = (
        ic_targets(score, momentum, mom120_floor_active=mom120_floor_active)
        if product == "IC"
        else im_targets(score, momentum, mom120_floor_active=mom120_floor_active)
    )
    momentum_schedule = v13_momentum_schedule(product, history, ohlcv=ohlcv)
    current_momentum_weight = float(momentum_schedule["execution_weight"].iloc[-1])
    next_momentum_weight = float(momentum_schedule["signal_target"].iloc[-1])
    if not np.isfinite(current_momentum_weight):
        current_momentum_weight = float(V13_FROZEN[product]["momentum_weight"])
    prior_price = float(history.iloc[-2])
    prior_score = _proxy_score_for_price(product, prior_price)
    prior_mom120 = _momentum_120_at(history, -2)
    prior_mom120_floor_active = bool(_mom120_floor_state(history).iloc[-2])
    prior_targets = (
        ic_targets(prior_score, prior_mom120, mom120_floor_active=prior_mom120_floor_active)
        if product == "IC"
        else im_targets(prior_score, prior_mom120, mom120_floor_active=prior_mom120_floor_active)
    )
    grid_current, grid_target = _replay_v13_grid(product, history)
    if product == "IC":
        current_core_put = 0.5 * float(prior_targets["put_delta"])
        current_momentum_put = (
            0.5
            * current_momentum_weight
            * float(prior_targets["valuation_put_delta"])
        )
        current_put = current_core_put + current_momentum_put
        next_core_put = 0.5 * float(targets["put_delta"])
        next_momentum_put = (
            0.5
            * next_momentum_weight
            * float(targets["valuation_put_delta"])
        )
        next_put = next_core_put + next_momentum_put
        if current_momentum_weight <= 0:
            current_momentum_put_driver = "动量袖空仓，按规则Put归零"
        elif float(prior_targets["valuation_put_delta"]) > 0:
            current_momentum_put_driver = "估值档约束（动量袖不适用MOM120下限）"
        else:
            current_momentum_put_driver = (
                "估值处于基础观察档，目标0%；动量袖不适用MOM120下限"
            )
        if next_momentum_weight <= 0:
            momentum_put_driver = "动量袖空仓，按规则Put归零"
        elif float(targets["valuation_put_delta"]) > 0:
            momentum_put_driver = "估值档约束（动量袖不适用MOM120下限）"
        else:
            momentum_put_driver = (
                "估值处于基础观察档，目标0%；动量袖不适用MOM120下限"
            )
        option_state = {
            "v13_current_put_delta": current_put,
            "v13_current_core_put_delta": current_core_put,
            "v13_current_momentum_put_delta": current_momentum_put,
            "v13_put_target_delta": next_put,
            "v13_core_put_delta": next_core_put,
            "v13_momentum_put_delta": next_momentum_put,
            "valuation_tier": targets["valuation_tier"],
            "valuation_tier_label": targets["valuation_tier_label"],
            "valuation_put_delta": targets["valuation_put_delta"],
            "mom120_floor_delta": targets["mom120_floor_delta"],
            "mom120_floor_active": mom120_floor_active,
            "current_core_put_driver": prior_targets["put_driver"],
            "current_momentum_put_driver": current_momentum_put_driver,
            "core_put_driver": targets["put_driver"],
            "momentum_put_driver": momentum_put_driver,
        }
    else:
        option_state = {
            "v13_current_parent_puts": int(prior_targets["puts_per_core"]),
            "v13_parent_puts_per_full_core": int(targets["puts_per_core"]),
            "v13_current_put_qty_normalized": 0.5
            * int(prior_targets["puts_per_core"]),
            "v13_put_target_qty_normalized": 0.5
            * int(targets["puts_per_core"]),
            "absolute_valuation_tier": targets["absolute_valuation_tier"],
            "absolute_valuation_tier_label": targets[
                "absolute_valuation_tier_label"
            ],
            "relative_valuation_tier": targets["relative_valuation_tier"],
            "relative_valuation_tier_label": targets[
                "relative_valuation_tier_label"
            ],
            "valuation_puts_per_full_core": targets[
                "valuation_puts_per_full_core"
            ],
            "mom120_floor_puts_per_full_core": targets[
                "mom120_floor_puts_per_full_core"
            ],
            "mom120_floor_active": mom120_floor_active,
            "core_put_driver": targets["put_driver"],
        }
    return {
        "price": live_price,
        "live_price_source": live_quote.get("source", "未知"),
        "live_price_source_date": live_quote.get("source_date"),
        "live_price_source_time": live_quote.get("source_time"),
        "proxy_pb": proxy_pb,
        "proxy_pe": proxy_pe,
        "proxy_erp": proxy_erp,
        "valuation_provenance": valuation["provenance"],
        "score": score,
        "momentum_120": momentum,
        "history_date": history.index[-1].date(),
        "momentum_score": float(momentum_schedule["momentum_score"].iloc[-1]),
        "momentum_abs20": float(momentum_schedule["abs20"].iloc[-1]),
        "momentum_abs": float(momentum_schedule["abs_momentum"].iloc[-1]),
        "momentum_abs_days": int(momentum_schedule["abs_momentum_days"].iloc[-1]),
        "momentum_abs_on": bool(momentum_schedule["abs_momentum_on"].iloc[-1]),
        "momentum_abs_debounce_active": bool(
            momentum_schedule["abs_debounce_active"].iloc[-1]
        ),
        "momentum_abs20_reentry_confirmed": bool(
            momentum_schedule["abs20_reentry_confirmed"].iloc[-1]
        ),
        "momentum_volume_ratio": float(momentum_schedule["volume_ratio"].iloc[-1]),
        "momentum_volume_pass": bool(momentum_schedule["volume_pass"].iloc[-1]),
        "momentum_volume_placeholder": bool(momentum_schedule["volume_placeholder"].iloc[-1]),
        "momentum_score_hot": bool(momentum_schedule["score_hot_signal"].iloc[-1]),
        "momentum_base_nav": float(momentum_schedule["base_nav_for_dd"].iloc[-1]),
        "momentum_base_dd": float(momentum_schedule["base_dd_for_gate"].iloc[-1]),
        "momentum_nav_defense": bool(momentum_schedule["nav_decay_signal"].iloc[-1]),
        "momentum_ohlcv_source": (ohlcv.attrs.get("source", "未知") if ohlcv is not None else None),
        "momentum_ohlcv_source_audit": (
            list(ohlcv.attrs.get("source_page_manifest") or [])
            if ohlcv is not None
            else []
        ),
        "momentum_ohlcv_source_failures": (
            list(ohlcv.attrs.get("source_failures") or [])
            if ohlcv is not None
            else []
        ),
        "momentum_ohlcv_source_volume_scale": (
            ohlcv.attrs.get("source_volume_scale") if ohlcv is not None else None
        ),
        "momentum_current_weight": current_momentum_weight,
        "momentum_next_weight": next_momentum_weight,
        "momentum_signal_date": history.index[-1].date(),
        "momentum_current_source_date": history.index[-2].date(),
        "grid_current_units": grid_current,
        "grid_target_units": grid_target,
        **option_state,
        **targets,
    }


def _numeric_frame(
    frame: pd.DataFrame, skip: tuple[str, ...] = ("instrument",)
) -> pd.DataFrame:
    result = frame.copy()
    for column in result.columns:
        if column not in skip:
            result[column] = pd.to_numeric(result[column], errors="coerce")
    return result


def _response_with_size_limit(response: Any, label: str) -> bytes:
    declared = response.headers.get("Content-Length")
    if declared:
        try:
            size = int(declared)
        except (TypeError, ValueError) as exc:
            raise RuntimeError(f"{label}响应长度标头非法") from exc
        if size < 0:
            raise RuntimeError(f"{label}响应长度标头非法")
        if size > MAX_QUOTE_RESPONSE_BYTES:
            raise RuntimeError(f"{label}响应声明大小超过{MAX_QUOTE_RESPONSE_BYTES}字节")
    content = response.content
    if len(content) > MAX_QUOTE_RESPONSE_BYTES:
        raise RuntimeError(f"{label}响应大小超过{MAX_QUOTE_RESPONSE_BYTES}字节")
    return content


def _bounded_response_bytes(response: Any, label: str) -> bytes:
    """Bound a streamed identity response, including the shared collection budget."""
    declared = response.headers.get("Content-Length")
    if declared:
        try:
            size = int(declared)
        except (ValueError, TypeError) as exc:
            raise RuntimeError(f"{label}响应长度标头非法") from exc
        if size < 0 or size > MAX_QUOTE_RESPONSE_BYTES:
            raise RuntimeError(f"{label}响应声明大小超过上限或非法")
    chunks, downloaded = [], 0
    stream = iter(response.iter_content(chunk_size=64*1024))
    while True:
        _bounded_timeout(8)
        try:
            chunk = next(stream)
        except StopIteration:
            break
        _bounded_timeout(8)
        if not chunk:
            continue
        downloaded += len(chunk)
        if downloaded > MAX_QUOTE_RESPONSE_BYTES:
            raise RuntimeError(f"{label}响应实际大小超过上限")
        chunks.append(chunk)
    _bounded_timeout(8)
    return b"".join(chunks)


def _http_source_stamp(response: Any, label: str) -> datetime:
    raw = response.headers.get("Last-Modified")
    if not raw:
        raise RuntimeError(f"{label}缺少可验证的Last-Modified行情时间")
    try:
        stamp = parsedate_to_datetime(raw)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{label}的Last-Modified行情时间非法") from exc
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=ZoneInfo("UTC"))
    return stamp.astimezone(BEIJING)


def _validate_quote_frame(
    frame: pd.DataFrame,
    product: str,
    clock: datetime,
    source: str,
) -> pd.DataFrame:
    required = {"instrument", "lastprice", "volume", "position", "source_date"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise RuntimeError(f"{source} {product}行情缺少标准列: {','.join(missing)}")
    result = frame.copy()
    result["instrument"] = result["instrument"].astype(str).str.strip().str.upper()
    pattern = rf"{product}\d{{4}}" if product in {"IC", "IM"} else r"MO\d{4}-[CP]-\d+"
    if result.empty:
        raise RuntimeError(f"{source} {product}没有格式有效的合约")
    if not bool(result["instrument"].str.fullmatch(pattern).all()):
        invalid = result.loc[
            ~result["instrument"].str.fullmatch(pattern), "instrument"
        ].iloc[0]
        raise RuntimeError(f"{source} {product}含非法合约代码: {invalid}")
    if result["instrument"].duplicated().any():
        duplicate = result.loc[result["instrument"].duplicated(), "instrument"].iloc[0]
        raise RuntimeError(f"{source} {product}行情包含重复合约: {duplicate}")
    # Source dates belong to the raw listing rows, not only to rows that happen
    # to have a positive trade.  Validate them before filtering no-trade rows so
    # a future/stale dated invalid quote cannot disappear silently.
    try:
        result["source_date"] = result["source_date"].map(
            lambda value: value
            if isinstance(value, date) and not isinstance(value, datetime)
            else date.fromisoformat(str(value)[:10])
        )
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{source} {product}含非法行情日期") from exc
    source_days = sorted(set(result["source_date"]))
    if len(source_days) != 1:
        raise RuntimeError(f"{source} {product}行情日期不一致: {source_days}")
    source_day = source_days[0]
    expected = _latest_completed_exchange_day(clock)
    if source_day > clock.date():
        raise RuntimeError(f"{source} {product}行情日期 {source_day} 晚于北京时间")
    if source_day < expected:
        raise RuntimeError(
            f"{source} {product}行情已过期：最新 {source_day}，至少应覆盖 {expected}"
        )
    snapshot_evidence = {}
    if source in {"新浪财经", "东方财富"}:
        snapshot_evidence = quote_snapshot_guard.vendor_snapshot_evidence(
            result.to_dict("records"), _iv_observation_clock(clock), expected,
            f"{source} {product}",
        )
    listing_frame = result[["instrument"]].copy()
    for column in ("lastprice", "volume", "position", "bprice", "sprice"):
        if column in result:
            result[column] = pd.to_numeric(result[column], errors="coerce")
    for column in ("volume", "position"):
        counts = result[column].to_numpy(dtype=float)
        fractional = np.isfinite(counts) & (counts >= 0) & (counts != np.floor(counts))
        if fractional.any():
            raise RuntimeError(f"{source} {product} {column}必须为整数张数，拒绝分数成交量/持仓量")
    valid = (
        np.isfinite(result["lastprice"].to_numpy(dtype=float))
        & result["lastprice"].gt(0)
        & np.isfinite(result["volume"].to_numpy(dtype=float))
        & result["volume"].ge(0)
        & np.isfinite(result["position"].to_numpy(dtype=float))
        & result["position"].ge(0)
    )
    result = result[valid].copy()
    if result.empty:
        raise RuntimeError(f"{source} {product}没有有限正价行情")
    for column in ("bprice", "sprice"):
        if column in result:
            finite_or_missing = result[column].isna() | (
                np.isfinite(result[column].fillna(0).to_numpy(dtype=float))
                & result[column].fillna(0).ge(0)
            )
            if not bool(finite_or_missing.all()):
                raise RuntimeError(f"{source} {product}含非法买卖报价")
    result["source"] = source
    result = result.sort_values("instrument").reset_index(drop=True)
    if product in {"IC", "IM"}:
        _validate_complete_future_structure(
            result,
            product,
            source_day,
            source,
            set(listing_frame["instrument"]),
        )
    else:
        _validate_complete_mo_chain(result, source_day, source, listing_frame)
    result.attrs.update(
        source=source,
        source_date=source_day,
        source_failures=[],
        source_audit=[],
        listed_instruments=sorted(set(listing_frame["instrument"])),
        listed_mo_months=(
            sorted(
                set(
                    listing_frame["instrument"].str.extract(
                        r"^(MO\d{4})", expand=False
                    )
                )
            )
            if product == "MO"
            else []
        ),
    )
    result.attrs.update(snapshot_evidence)
    return result


def _month_after(year: int, month: int, offset: int = 1) -> tuple[int, int]:
    ordinal = year * 12 + (month - 1) + offset
    return ordinal // 12, ordinal % 12 + 1


def _front_listed_month(as_of: date) -> tuple[int, int]:
    year, month = as_of.year, as_of.month
    if as_of > _third_friday(year, month):
        return _month_after(year, month)
    return year, month


def _following_quarter_months(
    after_year: int,
    after_month: int,
    count: int,
) -> list[tuple[int, int]]:
    result: list[tuple[int, int]] = []
    year, month = after_year, after_month
    while len(result) < count:
        year, month = _month_after(year, month)
        if month in {3, 6, 9, 12}:
            result.append((year, month))
    return result


def _expected_future_contracts(product: str, as_of: date) -> set[str]:
    front = _front_listed_month(as_of)
    next_month = _month_after(*front)
    months = [front, next_month, *_following_quarter_months(*next_month, 2)]
    return {f"{product}{year % 100:02d}{month:02d}" for year, month in months}


def _expected_mo_months(as_of: date) -> set[str]:
    front = _front_listed_month(as_of)
    next_one = _month_after(*front)
    next_two = _month_after(*front, 2)
    months = [front, next_one, next_two, *_following_quarter_months(*next_two, 3)]
    return {f"MO{year % 100:02d}{month:02d}" for year, month in months}


def _validate_complete_future_structure(
    frame: pd.DataFrame,
    product: str,
    as_of: date,
    source: str,
    listed_instruments: set[str] | None = None,
) -> None:
    actual = listed_instruments or set(frame["instrument"])
    expected = _expected_future_contracts(product, as_of)
    if actual != expected:
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        raise RuntimeError(
            f"{source} {product}挂牌结构不完整：as-of {as_of}应为"
            f"{sorted(expected)}，缺失{missing}，多余{extra}"
        )
    front_year, front_month = _front_listed_month(as_of)
    front_contract = f"{product}{front_year % 100:02d}{front_month:02d}"
    if front_contract not in set(frame["instrument"]):
        raise RuntimeError(
            f"{source} {product}最近月 {front_contract} 缺少有限正价，"
            "禁止用远月替代活跃合约"
        )
    nearest_days = min(
        abs((_third_friday(*_contract_month(contract)) - as_of).days)
        for contract in actual
    )
    if nearest_days > 45:
        raise RuntimeError(
            f"{source} {product}最近挂牌月距源日期{nearest_days}天，拒绝陈旧合约结构"
        )


def _mo_month_set(frame: pd.DataFrame) -> set[str]:
    listed = frame.attrs.get("listed_mo_months")
    if listed:
        return set(listed) | set(
            frame["instrument"].str.extract(r"^(MO\d{4})", expand=False)
        )
    return set(frame["instrument"].str.extract(r"^(MO\d{4})", expand=False))


def _validate_complete_mo_chain(
    frame: pd.DataFrame,
    as_of: date,
    source: str,
    listing_frame: pd.DataFrame | None = None,
) -> None:
    structure = listing_frame if listing_frame is not None else frame[["instrument"]]
    parsed = structure["instrument"].str.extract(
        r"MO(\d{2})(\d{2})-([CP])-(\d+)"
    )
    expiries = [
        _third_friday(2000 + int(year), int(month))
        for year, month in zip(parsed[0], parsed[1], strict=True)
    ]
    work = structure.assign(
        expiry=expiries,
        option_type=parsed[2].to_numpy(),
        strike=pd.to_numeric(parsed[3], errors="coerce").to_numpy(),
    )
    actual_months = set(
        structure["instrument"].str.extract(r"^(MO\d{4})", expand=False)
    )
    expected_months = _expected_mo_months(as_of)
    if actual_months != expected_months:
        missing = sorted(expected_months - actual_months)
        extra = sorted(actual_months - expected_months)
        raise RuntimeError(
            f"{source} MO备用链不完整：as-of {as_of}应挂牌"
            f"{sorted(expected_months)}，缺失{missing}，多余{extra}"
        )
    live = work[work["expiry"].ge(as_of)]
    live_expiries = sorted(set(live["expiry"]))
    for expiry in live_expiries:
        month = live[live["expiry"].eq(expiry)]
        calls = set(month.loc[month["option_type"].eq("C"), "strike"])
        puts = set(month.loc[month["option_type"].eq("P"), "strike"])
        if len(calls & puts) < 3:
            raise RuntimeError(
                f"{source} MO备用链不完整：{expiry} Call/Put共同有效行权价少于3个"
            )


def _live_mo_put_quote_basis(frame: pd.DataFrame) -> pd.DataFrame:
    """Zero-trade live Puts use explicit two-sided estimates, never old last/settle."""
    result = frame.copy()
    result["raw_lastprice"] = result["lastprice"]
    result["lastprice"] = pd.to_numeric(result["lastprice"], errors="coerce").astype(float)
    result["pricing_basis"] = "source_last_quote"
    zero_put = result["instrument"].astype(str).str.fullmatch(r"MO\d{4}-P-\d+") & pd.to_numeric(result["volume"], errors="coerce").eq(0)
    bid = pd.to_numeric(result.get("bprice", pd.Series(np.nan, index=result.index)), errors="coerce")
    ask = pd.to_numeric(result.get("sprice", pd.Series(np.nan, index=result.index)), errors="coerce")
    valid = zero_put & np.isfinite(bid) & np.isfinite(ask) & bid.gt(0) & ask.ge(bid)
    result.loc[zero_put, "lastprice"] = np.nan
    result.loc[zero_put, "pricing_basis"] = "unavailable_zero_volume_no_valid_two_sided_quote"
    result.loc[valid, "lastprice"] = (bid[valid] + ask[valid]) / 2.0
    result.loc[valid, "pricing_basis"] = "live_bid_ask_mid_estimate_zero_volume"
    return result


def _fetch_cffex_official_quotes(product: str, clock: datetime) -> pd.DataFrame:
    if product not in {"IC", "IM", "MO"}:
        raise ValueError(f"不支持的中金所品种: {product}")
    response = _evidence_http_get(
        f"https://www.cffex.com.cn/quote_{product}.txt",
        timeout=_bounded_timeout(QUOTE_OFFICIAL_SOURCE_BUDGET_SECONDS),
        headers={
            "User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        },
    )
    response.raise_for_status()
    stamp = _http_source_stamp(response, f"中金所官方 {product}")
    snapshot_evidence = quote_snapshot_guard.official_snapshot_evidence(
        stamp, _iv_observation_clock(clock), _latest_completed_exchange_day(clock),
        f"中金所官方 {product}",
    )
    content = _response_with_size_limit(response, f"中金所官方 {product}")
    lines = content.decode(response.encoding or "utf-8", errors="replace").splitlines()
    header_index = next(
        (
            index
            for index, line in enumerate(lines)
            if line.lstrip("\ufeff").lower().startswith("instrument,")
        ),
        None,
    )
    if header_index is None:
        raise RuntimeError(f"中金所 {product} 延时行情缺少CSV表头")
    frame = pd.read_csv(io.StringIO("\n".join(lines[header_index:])))
    if "instrument" not in frame or frame.empty:
        raise RuntimeError(f"中金所 {product} 延时行情为空")
    frame["instrument"] = frame["instrument"].astype(str).str.strip()
    frame = _numeric_frame(frame)
    frame["source_date"] = stamp.date()
    frame["source_time"] = stamp.strftime("%H:%M:%S")
    if product == "MO":
        frame = _live_mo_put_quote_basis(frame)
    validated = _validate_quote_frame(frame, product, clock, "中金所官方")
    validated.attrs.update(snapshot_evidence)
    return validated


def _fetch_sina_future_quotes(product: str, clock: datetime) -> pd.DataFrame:
    node = {"IC": "zzgz_qh", "IM": "im_qh"}[product]
    response = _evidence_http_get(
        "https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/"
        "Market_Center.getHQFuturesData",
        params={
            "page": 1,
            "num": 40,
            "sort": "position",
            "asc": 0,
            "node": node,
            "base": "futures",
        },
        timeout=_bounded_timeout(6),
        headers={
            "User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
            "Referer": "https://vip.stock.finance.sina.com.cn/",
            "Cache-Control": "no-cache",
        },
    )
    response.raise_for_status()
    _response_with_size_limit(response, f"新浪财经 {product}")
    payload = response.json()
    if not isinstance(payload, list) or not payload:
        raise RuntimeError(f"新浪财经 {product}行情为空")
    rows = []
    for item in payload:
        instrument = str(item.get("symbol", "")).upper()
        if not re.fullmatch(rf"{product}\d{{4}}", instrument):
            continue
        rows.append(
            {
                "instrument": instrument,
                "openprice": item.get("open"),
                "highest": item.get("high"),
                "lowest": item.get("low"),
                "lastprice": item.get("trade"),
                "bprice": item.get("bidprice1"),
                "sprice": item.get("askprice1"),
                "volume": item.get("volume"),
                "position": item.get("position"),
                "source_date": item.get("tradedate"),
                "source_time": item.get("ticktime"),
            }
        )
    frame = pd.DataFrame(rows)
    if not frame.empty:
        parsed_days = pd.to_datetime(frame["source_date"], errors="coerce").dt.date
        valid_days = [day for day in parsed_days if isinstance(day, date)]
        if valid_days:
            latest_day = max(valid_days)
            frame = frame.loc[parsed_days.eq(latest_day)].copy()
    return _validate_quote_frame(frame, product, clock, "新浪财经")


def _fetch_eastmoney_future_quotes(product: str, clock: datetime) -> pd.DataFrame:
    response = _evidence_http_get(
        "https://futsseapi.eastmoney.com/list/220",
        params={
            "orderBy": "dm",
            "sort": "asc",
            "pageSize": 200,
            "pageIndex": 0,
            "token": EASTMONEY_FUTURES_TOKEN,
        },
        timeout=_bounded_timeout(6),
        headers={
            "User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
            "Referer": "https://quote.eastmoney.com/",
            "Cache-Control": "no-cache",
        },
    )
    response.raise_for_status()
    _response_with_size_limit(response, f"东方财富 {product}")
    payload = response.json()
    raw_rows = payload.get("list") if isinstance(payload, dict) else None
    if not isinstance(raw_rows, list) or not raw_rows:
        raise RuntimeError(f"东方财富 {product}期货行情为空")
    rows = []
    for item in raw_rows:
        instrument = str(item.get("dm", "")).upper()
        if not re.fullmatch(rf"{product}\d{{4}}", instrument):
            continue
        try:
            stamp = datetime.fromtimestamp(float(item["utime"]), tz=BEIJING)
        except (KeyError, TypeError, ValueError, OSError) as exc:
            raise RuntimeError(f"东方财富 {instrument}缺少有效供应商更新时间") from exc
        rows.append(
            {
                "instrument": instrument,
                "openprice": item.get("o"),
                "highest": item.get("h"),
                "lowest": item.get("l"),
                "lastprice": item.get("p"),
                "bprice": item.get("mrj"),
                "sprice": item.get("mcj"),
                "volume": item.get("vol"),
                "position": item.get("ccl"),
                "source_date": stamp.date(),
                "source_time": stamp.strftime("%H:%M:%S"),
            }
        )
    return _validate_quote_frame(pd.DataFrame(rows), product, clock, "东方财富")


def _fetch_eastmoney_mo_quotes(clock: datetime) -> pd.DataFrame:
    response = _evidence_http_get(
        "https://futsseapi.eastmoney.com/list/option/221",
        params={
            "orderBy": "dm",
            "sort": "asc",
            "pageSize": 20000,
            "pageIndex": 0,
            "token": EASTMONEY_FUTURES_TOKEN,
        },
        timeout=_bounded_timeout(8),
        headers={
            "User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
            "Referer": "https://quote.eastmoney.com/",
            "Cache-Control": "no-cache",
        },
    )
    response.raise_for_status()
    _response_with_size_limit(response, "东方财富 MO")
    payload = response.json()
    raw_rows = payload.get("list") if isinstance(payload, dict) else None
    if not isinstance(raw_rows, list) or not raw_rows:
        raise RuntimeError("东方财富 MO期权链为空")
    rows = []
    for item in raw_rows:
        instrument = str(item.get("dm", "")).upper()
        if not re.fullmatch(r"MO\d{4}-[CP]-\d+", instrument):
            continue
        try:
            stamp = datetime.fromtimestamp(float(item["utime"]), tz=BEIJING)
        except (KeyError, TypeError, ValueError, OSError) as exc:
            raise RuntimeError(f"东方财富 {instrument}缺少有效更新时间") from exc
        rows.append(
            {
                "instrument": instrument,
                "openprice": item.get("o"),
                "lastprice": item.get("p"),
                "bprice": item.get("mrj"),
                "sprice": item.get("mcj"),
                "volume": item.get("vol"),
                "position": item.get("ccl"),
                "source_date": stamp.date(),
                "source_time": stamp.strftime("%H:%M:%S"),
            }
        )
    return _validate_quote_frame(_live_mo_put_quote_basis(pd.DataFrame(rows)), "MO", clock, "东方财富")


def _audit_quote_sources(
    preferred: pd.DataFrame,
    secondary: pd.DataFrame,
    product: str,
) -> str:
    preferred_day = preferred.attrs.get("source_date")
    secondary_day = secondary.attrs.get("source_date")
    if preferred_day != secondary_day:
        raise RuntimeError(
            f"{product}行情源as-of不一致：{preferred.attrs['source']}={preferred_day}，"
            f"{secondary.attrs['source']}={secondary_day}"
        )
    if product in {"IC", "IM"}:
        preferred_contracts = set(
            preferred.attrs.get("listed_instruments", preferred["instrument"])
        ) | set(preferred["instrument"])
        secondary_contracts = set(
            secondary.attrs.get("listed_instruments", secondary["instrument"])
        ) | set(secondary["instrument"])
        if preferred_contracts != secondary_contracts:
            raise RuntimeError(
                f"{product}行情源挂牌集合冲突：{preferred.attrs['source']}="
                f"{sorted(preferred_contracts)}，{secondary.attrs['source']}="
                f"{sorted(secondary_contracts)}"
            )
    else:
        preferred_months = _mo_month_set(preferred)
        secondary_months = _mo_month_set(secondary)
        if preferred_months != secondary_months:
            raise RuntimeError(
                f"MO行情源到期月集合冲突：{preferred.attrs['source']}="
                f"{sorted(preferred_months)}，{secondary.attrs['source']}="
                f"{sorted(secondary_months)}"
            )
    left = preferred[["instrument", "lastprice"]].rename(columns={"lastprice": "left"})
    right = secondary[["instrument", "lastprice"]].rename(columns={"lastprice": "right"})
    common = left.merge(right, on="instrument", how="inner")
    minimum = 2 if product in {"IC", "IM"} else 10
    if len(common) < minimum:
        raise RuntimeError(
            f"{product}行情源合约交集不足：{preferred.attrs['source']}与"
            f"{secondary.attrs['source']}仅{len(common)}个"
        )
    denominator = common[["left", "right"]].abs().max(axis=1)
    relative = (common["left"] - common["right"]).abs() / denominator
    if product in {"IC", "IM"}:
        severe = relative.gt(0.01) & (common["left"] - common["right"]).abs().gt(10.0)
        conflict = bool(severe.any())
    else:
        conflict = bool(relative.median() > 0.03 or relative.quantile(0.9) > 0.15)
    if conflict:
        raise RuntimeError(
            f"{product}行情源严重冲突：{preferred.attrs['source']}与"
            f"{secondary.attrs['source']}共同合约价格偏差超限"
        )
    return (
        f"{preferred.attrs['source']}与{secondary.attrs['source']}交叉审计通过："
        f"共同合约{len(common)}个，中位相对偏差{relative.median():.3%}"
    )


def _source_failure(source: str, exc: Exception) -> str:
    detail = re.sub(r"\s+", " ", str(exc)).strip()[:240]
    return f"{source}: {type(exc).__name__}: {detail}"


def fetch_cffex_quotes(
    product: str,
    clock: datetime | None = None,
) -> pd.DataFrame:
    """Fetch standardized CFFEX quotes with ordered, audited fallbacks."""

    if product not in {"IC", "IM", "MO"}:
        raise ValueError(f"不支持的中金所品种: {product}")
    now = clock or _now_beijing()
    replay_day = _HISTORICAL_REPLAY_DAY.get()
    if replay_day is not None:
        if replay_day != now.date():
            raise RuntimeError(
                f"{product}历史重放日 {replay_day} 与运行时钟 {now.date()} 不一致"
            )
        try:
            return _cffex_historical_quote_frame(product, replay_day, now)
        except (requests.ConnectionError, requests.Timeout) as archive_error:
            # Before a new session starts, the ordinary quote endpoints can
            # still expose the exact previous completed close. Never use this
            # for an older missed day or substitute the current session's data.
            actual_clock = datetime.now(BEIJING)
            if replay_day != _latest_completed_exchange_day(actual_clock):
                raise
            token = _HISTORICAL_REPLAY_DAY.set(None)
            try:
                frame = fetch_cffex_quotes(product, now).copy()
            finally:
                _HISTORICAL_REPLAY_DAY.reset(token)
            retrieved_clock = datetime.now(BEIJING)
            if replay_day != _latest_completed_exchange_day(retrieved_clock):
                raise RuntimeError("补录取数完成后目标已不是最近完成交易日，拒绝快照替代") from archive_error
            if frame.attrs.get("source_date") != replay_day or any(
                day != replay_day for day in frame["source_date"]
            ):
                raise RuntimeError("补录备用快照必须完整属于最近已完成的同一交易日") from archive_error
            if product == "MO":
                # A historical zero-volume Put requires an official settlement;
                # an old bid/ask midpoint cannot stand in for that evidence.
                unavailable = frame["instrument"].str.fullmatch(r"MO\d{4}-P-\d+") & frame["volume"].eq(0)
                if unavailable.any():
                    # The ordinary router has already validated the entire raw
                    # listing and its snapshot. Only remove these price rows;
                    # revalidating a filtered frame would lose listed contracts
                    # that the first validation correctly kept as unavailable.
                    frame = frame.loc[~unavailable].copy()
                    if frame.empty:
                        raise RuntimeError("MO历史快照没有可核验的非零成交价格") from archive_error
            frame.attrs.setdefault("source_failures", []).append(
                _source_failure("中金所历史包", archive_error)
            )
            frame.attrs.setdefault("source_audit", []).append(
                f"retrospective_replay：仅使用最近已完成{replay_day}的合格收盘快照；实际获取{retrieved_clock.isoformat()}"
            )
            frame.attrs["historical_replay_source"] = "latest_completed_close_snapshot"
            frame.attrs["historical_replay_retrieved_at"] = retrieved_clock.isoformat()
            return frame
    successes: list[pd.DataFrame] = []
    failures: list[str] = []
    causes: list[Exception] = []

    def attempt(source: str, fetcher: Any, source_budget: float) -> None:
        try:
            with _network_budget(source_budget):
                successes.append(fetcher(product, now))
        except Exception as exc:  # noqa: BLE001 - aggregate every source result.
            failures.append(_source_failure(source, exc))
            causes.append(exc)

    remaining = _remaining_network_budget()
    official_required = (
        QUOTE_OFFICIAL_SOURCE_BUDGET_SECONDS + QUOTE_FALLBACK_RESERVE_SECONDS
    )
    if remaining is not None and remaining < official_required:
        failures.append(
            _source_failure(
                "中金所官方",
                RuntimeError(
                    f"剩余联网预算{remaining:.1f}秒，已跳过官方源并为备用源预留时间"
                ),
            )
        )
    else:
        attempt(
            "中金所官方",
            _fetch_cffex_official_quotes,
            QUOTE_OFFICIAL_SOURCE_BUDGET_SECONDS,
        )
    if product in {"IC", "IM"}:
        attempt(
            "新浪财经",
            _fetch_sina_future_quotes,
            QUOTE_VENDOR_SOURCE_BUDGET_SECONDS,
        )
        # Eastmoney is the second fallback.  If Sina already recovered a failed
        # official source, preserve the remaining request budget for ETF/options.
        # When the official source works, fetch one backup for conflict auditing.
        if not successes or successes[0].attrs.get("source") == "中金所官方":
            if len(successes) < 2:
                attempt(
                    "东方财富",
                    _fetch_eastmoney_future_quotes,
                    QUOTE_VENDOR_SOURCE_BUDGET_SECONDS,
                )
    else:
        attempt(
            "东方财富",
            lambda _product, stamp: _fetch_eastmoney_mo_quotes(stamp),
            QUOTE_VENDOR_SOURCE_BUDGET_SECONDS,
        )
    if not successes:
        error_type = SignalTransportError if causes and all(
            isinstance(exc, (requests.ConnectionError, requests.Timeout)) for exc in causes
        ) else RuntimeError
        raise error_type(f"{product}所有行情源失败｜" + "｜".join(failures))
    preferred = successes[0]
    audits = [
        _audit_quote_sources(preferred, secondary, product)
        for secondary in successes[1:]
    ]
    preferred.attrs["source_failures"] = failures
    preferred.attrs["source_audit"] = audits
    return preferred


def verify_sina_option_quote(
    contract: str,
    expected_date: date,
    expected_price: float,
    clock: datetime,
    pricing_basis: str = "source_last_quote",
) -> dict[str, Any]:
    match = re.fullmatch(r"MO(\d{4})-([CP])-(\d+)", contract.upper())
    if not match:
        raise ValueError(f"新浪MO复核无法识别合约: {contract}")
    symbol = f"mo{match.group(1)}{match.group(2)}{match.group(3)}"
    response = _evidence_http_get(
        "https://hq.sinajs.cn/etag.php",
        params={"list": f"P_OP_{symbol}"},
        timeout=_bounded_timeout(6),
        headers={
            "User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
            "Referer": "https://stock.finance.sina.com.cn/",
            "Cache-Control": "no-cache",
        },
    )
    response.raise_for_status()
    raw = _response_with_size_limit(response, f"新浪MO详报价 {contract}")
    try:
        packets = signal_evidence.sina_mo_quote_variables(raw, [f"P_OP_{symbol}"])
    except signal_evidence.EvidenceUnavailable as exc:
        raise RuntimeError(f"新浪MO详报价 {contract} 返回合约与请求不一致") from exc
    fields = packets[f"P_OP_{symbol}"][0].decode("gb18030", errors="strict").split(",")
    if len(fields) <= 40:
        raise RuntimeError(f"新浪MO详报价 {contract} 字段不足")
    try:
        stamp = datetime.strptime(fields[32], "%Y-%m-%d %H:%M:%S").replace(
            tzinfo=BEIJING
        )
        raw_lastprice = pd.to_numeric(fields[2], errors="coerce")
        lastprice = raw_lastprice
        volume = pd.to_numeric(fields[40], errors="coerce")
        position = float(fields[5])
        if pricing_basis == "live_bid_ask_mid_estimate_zero_volume":
            if match.group(2) != "P":
                raise ValueError("双边中价复核只允许Put")
            bid, ask = float(fields[1]), float(fields[3])
            if not all(math.isfinite(value) and value > 0 for value in (bid, ask)) or bid > ask:
                raise ValueError("新浪Put双边报价无效")
            lastprice = (bid + ask) / 2.0
    except (IndexError, TypeError, ValueError) as exc:
        raise RuntimeError(f"新浪MO详报价 {contract} 字段非法") from exc
    if not all(
        math.isfinite(value) and value >= 0
        for value in ((position,) if pricing_basis == "live_bid_ask_mid_estimate_zero_volume" else (volume, position))
    ) or not math.isfinite(lastprice) or lastprice <= 0:
        raise RuntimeError(f"新浪MO详报价 {contract} 含NaN、无穷值或非正价格")
    source_date = stamp.date()
    observation_clock = _iv_observation_clock(clock)
    if observation_clock.tzinfo is None:
        observation_clock = observation_clock.replace(tzinfo=BEIJING)
    if stamp > observation_clock:
        raise RuntimeError(f"新浪MO详报价 {contract} 行情时间晚于当前运行时间")
    if pricing_basis == "live_bid_ask_mid_estimate_zero_volume":
        if source_date != expected_date:
            raise RuntimeError(f"新浪Put双边报价日期 {source_date} 与 {expected_date} 不一致")
        try:
            _validate_iv_monitor_times(expected_date, stamp, stamp, _iv_observation_clock(clock),
                                       expected_date < clock.date() or clock.hour >= 15)
        except ValueError as exc:
            raise RuntimeError(f"新浪Put双边报价时间无效：{exc}") from exc
    if source_date < expected_date:
        raise RuntimeError(
            f"新浪MO详报价 {contract} 已过期：最新 {source_date}，应覆盖 {expected_date}"
        )
    if source_date > clock.date():
        raise RuntimeError(f"新浪MO详报价 {contract} 日期 {source_date} 晚于北京时间")
    price = float(expected_price)
    relative = abs(lastprice - price) / max(lastprice, price)
    if source_date == expected_date and abs(lastprice - price) > 2.0 and relative > 0.15:
        raise RuntimeError(
            f"MO行情源严重冲突：东方财富 {contract}={price:g}，"
            f"新浪详报价={lastprice:g}（{source_date}）"
        )
    return {
        "source": "新浪财经详报价",
        "source_date": source_date,
        "lastprice": lastprice,
        "contract": contract,
        "pricing_basis": pricing_basis,
        "raw_lastprice": float(raw_lastprice) if math.isfinite(raw_lastprice) else None,
    }


def verify_sina_option_open(
    contract: str, expected_date: date, expected_open: float, clock: datetime
) -> dict[str, Any]:
    """Independently check an Eastmoney MO opening mark before paper execution."""
    match = re.fullmatch(r"MO(\d{4})-([CP])-(\d+)", contract.upper())
    if not match:
        raise ValueError(f"新浪MO开盘复核无法识别合约: {contract}")
    symbol = f"mo{match.group(1)}{match.group(2)}{match.group(3)}"
    response = _evidence_http_get(
        "https://hq.sinajs.cn/etag.php",
        params={"list": f"P_OP_{symbol}"},
        timeout=_bounded_timeout(6),
        headers={
            "User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
            "Referer": "https://stock.finance.sina.com.cn/",
            "Cache-Control": "no-cache",
        },
    )
    response.raise_for_status()
    raw = _response_with_size_limit(response, f"新浪MO开盘价 {contract}")
    try:
        packets = signal_evidence.sina_mo_quote_variables(raw, [f"P_OP_{symbol}"])
    except signal_evidence.EvidenceUnavailable as exc:
        raise RuntimeError(f"新浪MO开盘复核 {contract} 返回合约与请求不一致或为空") from exc
    fields = packets[f"P_OP_{symbol}"][0].decode("gb18030", errors="strict").split(",")
    if len(fields) <= 32:
        raise RuntimeError(f"新浪MO开盘复核 {contract} 字段不足")
    try:
        stamp = datetime.strptime(fields[32], "%Y-%m-%d %H:%M:%S").replace(
            tzinfo=BEIJING
        )
        strike = float(fields[7])
        openprice = float(fields[9])
        vendor_open = float(expected_open)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"新浪MO开盘复核 {contract} 字段非法") from exc
    if (not math.isclose(strike, float(match.group(3)), abs_tol=1e-9)
            or stamp.date() != expected_date
            # CFFEX option opening auction matches during 09:29-09:30;
            # a contract may have no continuous-session update afterward.
            or stamp.time() < time(9, 29)
            or stamp > clock + timedelta(minutes=2)):
        raise RuntimeError(f"新浪MO开盘复核 {contract} 合约或行情日期不匹配")
    if not all(math.isfinite(value) and value > 0 for value in (openprice, vendor_open)):
        raise RuntimeError(f"新浪MO开盘复核 {contract} 缺少双源正开盘价")
    if abs(openprice - vendor_open) > 0.200001:
        raise RuntimeError(
            f"MO开盘价源冲突：东方财富 {contract}={vendor_open:g}，"
            f"新浪={openprice:g}（{expected_date}）"
        )
    return {"source": "新浪财经详报价", "source_date": stamp.date(),
            "openprice": openprice, "contract": contract}


def _sse_quote_json(path: str, params: dict[str, Any]) -> dict[str, Any]:
    response = _evidence_http_get(
        f"https://yunhq.sse.com.cn:32042/{path.lstrip('/')}",
        params=params,
        stream=True,
        timeout=_bounded_timeout(8),
        headers={
            "User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
            "Referer": "https://www.sse.com.cn/assortment/options/price/",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        },
    )
    try:
        response.raise_for_status()
        if callable(getattr(response, "iter_content", None)):
            raw = _bounded_response_bytes(response, "上交所行情")
        else:
            raw = _response_with_size_limit(response, "上交所行情")
        return json.loads(raw)
    finally:
        close = getattr(response, "close", None)
        if callable(close):
            close()


def _sse_session_time(value: Any, label: str) -> str:
    """Normalize a supplied SSE time without turning missing data into midnight."""
    if value is None or isinstance(value, (bool, np.bool_)):
        raise RuntimeError(f"{label}缺少有效行情时间")
    raw = str(value).strip()
    if not re.fullmatch(r"[0-9]{1,6}", raw):
        raise RuntimeError(f"{label}行情时间格式无效")
    normalized = raw.zfill(6)
    try:
        observed = datetime.strptime(normalized, "%H%M%S").time()
    except ValueError as exc:
        raise RuntimeError(f"{label}行情时间无效") from exc
    if observed < time(9, 15):
        raise RuntimeError(f"{label}行情时间早于09:15，不能作为有效盘中行情")
    return normalized


def _sse_projection_rows(payload: Any, label: str) -> list[Any]:
    """Do not accept an explicitly truncated SSE select projection."""
    if not isinstance(payload, dict) or not isinstance(payload.get("list"), list):
        raise RuntimeError(f"{label}行情结构异常")
    rows = payload["list"]
    # Older supplied projections can omit pagination altogether. Once the
    # source advertises pagination, all three fields must prove a full page;
    # missing/malformed metadata cannot silently shrink the candidate set.
    if any(name in payload for name in ("total", "begin", "end")):
        for name, expected in (("total", len(rows)), ("begin", 0), ("end", len(rows))):
            value = payload.get(name)
            if type(value) is not int or value != expected:
                raise RuntimeError(f"{label}行情分页不完整或未经核验")
    return rows


def fetch_sse_510500_quote() -> dict[str, Any]:
    payload = _sse_quote_json(
        "v1/sh1/list/self/510500",
        {
            "select": "code,cpxxextendname,last,change,chg_rate,amp_rate,volume,amount,prev_close"
        },
    )
    rows = _sse_projection_rows(payload, "上交所510500ETF")
    if not rows:
        raise RuntimeError("上交所未返回有效510500ETF行情")
    if (len(rows) != 1 or not isinstance(rows[0], list) or len(rows[0]) != 9
            or str(rows[0][0]) != "510500"):
        raise RuntimeError("上交所510500ETF行情标的或字段不匹配")
    prices = rows[0][2], rows[0][8]
    if any(isinstance(value, (bool, np.bool_)) for value in prices):
        raise RuntimeError("上交所510500ETF行情价格不能为布尔值")
    try:
        last, prev_close = map(float, prices)
    except (TypeError, ValueError, OverflowError) as exc:
        raise RuntimeError("上交所510500ETF行情价格格式无效") from exc
    if not all(math.isfinite(value) and value > 0 for value in (last, prev_close)):
        raise RuntimeError("上交所510500ETF行情含NaN、无穷值或非正价格")
    return {
        "date": str(payload.get("date", "")),
        "time": _sse_session_time(payload.get("time"), "上交所510500ETF"),
        "last": last,
        "prev_close": prev_close,
    }


def _public_quote_bytes(url: str, label: str, *, params=None) -> bytes:
    """Keep each actual response bounded and separately available to replay."""
    response = _evidence_http_get(
        url, params=params, stream=True, timeout=_bounded_timeout(8),
        headers={"User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
                 "Referer": "https://stock.finance.sina.com.cn/" if "sina" in url
                 else "https://stockapp.finance.qq.com/", "Cache-Control": "no-cache"})
    try:
        response.raise_for_status()
        if callable(getattr(response, "iter_content", None)):
            return _bounded_response_bytes(response, label)
        return _response_with_size_limit(response, label)
    finally:
        close = getattr(response, "close", None)
        if callable(close):
            close()


def _exact_quote_variables(raw: bytes, prefix: str) -> dict[str, str]:
    packets = re.findall(r'(?<![A-Za-z0-9_$])' + re.escape(prefix) + r'([A-Za-z0-9_]+)="([^"\r\n]*)"',
                         raw.decode("gb18030", errors="strict"))
    values = {}
    for symbol, payload in packets:
        if symbol in values or not payload:
            raise RuntimeError("行情变量重复或为空，禁止当作完整报价")
        values[symbol] = payload
    if not values:
        raise RuntimeError("未返回精确匹配的行情变量")
    return values


def _etf_quote_prices(last, previous) -> tuple[float, float]:
    if any(isinstance(value, (bool, np.bool_)) for value in (last, previous)):
        raise RuntimeError("510500ETF行情价格不能为布尔值")
    try:
        last, previous = float(last), float(previous)
    except (TypeError, ValueError, OverflowError) as exc:
        raise RuntimeError("510500ETF行情价格格式无效") from exc
    if not all(math.isfinite(value) and value > 0 for value in (last, previous)):
        raise RuntimeError("510500ETF行情含非有限或非正价格")
    return last, previous


def _validated_etf_quote(last, previous, observed: datetime, source: str) -> dict[str, Any]:
    last, previous = _etf_quote_prices(last, previous)
    return {"date": observed.strftime("%Y%m%d"), "time": observed.strftime("%H%M%S"),
            "last": last, "prev_close": previous, "source": source}


def fetch_tencent_510500_quote() -> dict[str, Any]:
    raw = _public_quote_bytes("https://qt.gtimg.cn/q=sh510500", "腾讯510500ETF")
    packets = _exact_quote_variables(raw, "v_")
    if set(packets) != {"sh510500"}:
        raise RuntimeError("腾讯510500ETF行情标的不一致")
    fields = packets["sh510500"].split("~")
    if len(fields) <= 30 or fields[2] != "510500" or not re.fullmatch(r"[0-9]{14}", fields[30]):
        raise RuntimeError("腾讯510500ETF字段或真实时间缺失")
    try:
        observed = datetime.strptime(fields[30], "%Y%m%d%H%M%S")
    except ValueError as exc:
        raise RuntimeError("腾讯510500ETF真实时间无效") from exc
    return _validated_etf_quote(fields[3], fields[4], observed, "腾讯510500ETF行情")


def fetch_sina_510500_quote() -> dict[str, Any]:
    raw = _public_quote_bytes("https://hq.sinajs.cn/", "新浪510500ETF", params={"list": "sh510500"})
    packets = _exact_quote_variables(raw, "hq_str_")
    if set(packets) != {"sh510500"}:
        raise RuntimeError("新浪510500ETF行情标的不一致")
    fields = packets["sh510500"].split(",")
    if len(fields) <= 31 or not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", fields[30]) or not re.fullmatch(r"[0-9]{2}:[0-9]{2}:[0-9]{2}", fields[31]):
        raise RuntimeError("新浪510500ETF字段或真实时间缺失")
    try:
        observed = datetime.strptime(fields[30] + " " + fields[31], "%Y-%m-%d %H:%M:%S")
    except ValueError as exc:
        raise RuntimeError("新浪510500ETF真实时间无效") from exc
    return _validated_etf_quote(fields[3], fields[2], observed, "新浪510500ETF行情")


def fetch_510500_quote_with_failover(reference_day: date | None = None) -> dict[str, Any]:
    day, clock = reference_day or _now_beijing().date(), _now_beijing()
    started = time_module.monotonic()
    errors, failures = [], []
    for source, fetcher in (("上交所510500ETF", fetch_sse_510500_quote),
                            ("腾讯510500ETF", fetch_tencent_510500_quote),
                            ("新浪510500ETF", fetch_sina_510500_quote)):
        try:
            value = dict(fetcher())
            value.setdefault("source", source)
            _validate_chain_stamp_matches(source, value, day, _iv_observation_clock(clock, started))
            _etf_quote_prices(value["last"], value["prev_close"])
            if failures:
                value["source_failures"] = list(failures)
            return value
        except Exception as exc:
            errors.append(exc)
            failures.append(f"{source}: {type(exc).__name__}: {exc}")
    raise _source_failure_error("510500ETF所有来源均不可用；" + "；".join(failures), errors) from errors[-1]


def _sina_put_detail_batches(ids: list[str]) -> list[tuple[str, str]]:
    packets = []
    size = _SINA_OPTION_QUOTE_BATCH_SIZE
    if type(size) is not int or not 1 <= size <= 64:
        raise RuntimeError("新浪510500 Put技术批大小无效")
    def fetch_batch(batch):
        url = "https://hq.sinajs.cn/list=" + ",".join("CON_OP_" + value for value in batch)
        for attempt in range(2):
            try:
                raw = _public_quote_bytes(url, "新浪510500 Put分批详情")
                break
            except (requests.ConnectionError, requests.Timeout, requests.exceptions.ChunkedEncodingError):
                if attempt:
                    raise
        values = _exact_quote_variables(raw, "hq_str_CON_OP_")
        if set(values) != set(batch):
            raise RuntimeError("新浪510500 Put分批证券集合缺失或未请求，禁止跳选其他行权价")
        return list(values.items())
    with _network_budget(SIGNAL_PRODUCT_NETWORK_BUDGET_SECONDS):
        batches = [ids[start:start + size] for start in range(0, len(ids), size)]
        for values in _collect_quote_batches(fetch_batch, batches):
            packets.extend(values)
    return packets


def fetch_sse_510500_chain(expiry_ym: str) -> tuple[pd.DataFrame, dict[str, str]]:
    match = re.fullmatch(r"(20)?(\d{2})(\d{2})", str(expiry_ym))
    if not match:
        raise ValueError(f"非法ETF期权月份: {expiry_ym}")
    yy, month = match.group(2), match.group(3)
    payload = _sse_quote_json(
        f"v1/sho/list/tstyle/510500_{month}",
        {
            "select": "contractid,last,chg_rate,presetpx,exepx,code",
            "order": "contractid,ase",
        },
    )
    rows = sse_identity.validate_chain_rows(payload, f"{yy}{month}")
    columns = ["contract", "last", "chg_rate", "pre_settle", "strike", "security_id"]
    frame = _numeric_frame(pd.DataFrame(rows, columns=columns), skip=("contract", "security_id"))
    return frame, {
        "date": str(payload.get("date", "")),
        "time": _sse_session_time(payload.get("time"), "上交所510500期权链"),
        "source": "上交所行情接口",
    }


def fetch_sina_510500_chain(expiry_ym: str) -> tuple[pd.DataFrame, dict[str, str]]:
    """Fetch a live 510500 Put chain from Sina as an audited SSE outage fallback."""
    match = re.fullmatch(r"(20)?(\d{2})(\d{2})", str(expiry_ym))
    if not match:
        raise ValueError(f"非法ETF期权月份: {expiry_ym}")
    yy, month = match.group(2), match.group(3)
    listing = _public_quote_bytes("https://hq.sinajs.cn/", "新浪510500 Put列表",
                                  params={"list": f"OP_DOWN_510500{yy}{month}"})
    listing_packets = _exact_quote_variables(listing, "hq_str_")
    if set(listing_packets) != {f"OP_DOWN_510500{yy}{month}"}:
        raise RuntimeError("新浪510500 Put列表月份或标的不一致")
    symbols = [value for value in listing_packets[f"OP_DOWN_510500{yy}{month}"].split(",") if value]
    if not symbols or len(symbols) > 512 or len(symbols) != len(set(symbols)):
        raise RuntimeError("新浪510500 Put列表为空、重复或超过上限")
    if any(not re.fullmatch(r"CON_OP_[0-9]{8}", symbol) for symbol in symbols):
        raise RuntimeError("新浪510500 Put证券代码必须为八位ASCII数字")
    ids = sorted(value.removeprefix("CON_OP_") for value in symbols)
    rows: list[dict[str, Any]] = []
    stamps: list[datetime] = []
    unresolved_adjusted: list[dict[str, Any]] = []
    packets = _sina_put_detail_batches(ids)
    returned_ids = [security_id for security_id, _ in packets]
    if len(returned_ids) != len(set(returned_ids)) or set(returned_ids) != set(ids):
        raise RuntimeError("新浪510500 Put证券集合缺失、未请求或重复，禁止跳选其他行权价")
    expected_expiry = _fourth_wednesday(2000 + int(yy), int(month))
    contracts: set[str] = set()
    for security_id, payload in packets:
        fields = payload.split(",")
        if len(fields) <= 46 or fields[43] not in {"M", "A"} or fields[45] != "P":
            raise RuntimeError("新浪510500 Put详情字段或合约类型不一致")
        if fields[36].strip() != "510500":
            raise RuntimeError("新浪510500 Put详情标的证券不一致")
        expiry = str(fields[46]).replace("-", "")
        if expiry != expected_expiry.strftime("%Y%m%d"):
            raise RuntimeError("新浪510500 Put详情完整到期日与目标月份日历不一致")
        try:
            strike = float(fields[7])
            # CON_OP [2] is the latest trade; [3] is the current ask.
            # Last may legitimately be outside a subsequently changed spread.
            last = float(fields[2])
            observed = datetime.strptime(fields[32], "%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError) as exc:
            raise RuntimeError("新浪510500 Put详情含无效价格或时间戳") from exc
        if not (math.isfinite(strike) and math.isfinite(last) and strike > 0 and last >= 0):
            raise RuntimeError("新浪510500 Put详情含非有限价格或行权价")
        style = fields[43]
        if style == "A":
            # Adjustment changes actual strike/unit, but SSE retains the
            # ORIGINAL strike digits in the trading code. CON_OP does not
            # supply that code or an independently verified contract unit.
            # Keep the raw identity for diagnosis; never manufacture a code.
            unresolved_adjusted.append({"security_id": security_id,
                                        "strike": strike, "expiry": expiry,
                                        "source_stamp": observed.replace(tzinfo=BEIJING)})
            continue
        contract = f"510500P{yy}{month}{style}{int(round(strike * 1000)):05d}"
        if (contract in contracts
                or not math.isclose(strike, int(round(strike * 1000))/1000., rel_tol=0, abs_tol=1e-9)):
            raise RuntimeError("新浪510500 Put交易合约重复或标准行权价精度无效")
        contracts.add(contract)
        rows.append(
            {
                "contract": contract,
                "last": last,
                "chg_rate": None,
                # [40] is session low. The extended settlement field has no
                # independently verified contract here; do not guess [44].
                "pre_settle": None,
                "security_id": security_id,
                "strike": strike,
                "expiry": expected_expiry,
                "source_stamp": observed.replace(tzinfo=BEIJING),
            }
        )
        stamps.append(observed)
    if not rows:
        if unresolved_adjusted:
            raise RuntimeError("510500 adjusted contract master and multiplier unavailable; cannot price held A contracts")
        raise RuntimeError(f"新浪未返回有效510500 Put月份 {yy}{month} 行情")
    # Keep stale rows identifiable.  Dropping one here could silently move a
    # nearest-strike selection to another contract; selected rows are checked.
    latest = max(stamps)
    source_day, source_time = latest.strftime("%Y%m%d"), latest.strftime("%H%M%S")
    frame = pd.DataFrame(rows)
    frame.attrs["unresolved_adjusted_contracts"] = unresolved_adjusted
    return frame, {
        "date": source_day,
        "time": source_time,
        "source": "新浪财经期权详报价（上交所回退）",
    }


def fetch_510500_chain_with_failover(expiry_ym: str) -> tuple[pd.DataFrame, dict[str, str]]:
    """Use SSE first, then Sina; never substitute stale or malformed quotes."""
    failures: list[str] = []
    source_errors: list[Exception] = []
    for source, fetcher in (
        ("上交所行情接口", fetch_sse_510500_chain),
        ("新浪财经期权详报价", fetch_sina_510500_chain),
    ):
        try:
            chain, stamp = fetcher(expiry_ym)
            required = {"contract", "last", "strike"}
            if not required.issubset(chain.columns) or chain.empty:
                raise RuntimeError("期权链为空或缺少必要字段")
            normalized_stamp = dict(stamp)
            normalized_stamp.setdefault("source", source)
            reference_day = _OPTION_CHAIN_REFERENCE_DAY.get()
            if reference_day is not None and reference_day >= sse_identity.EFFECTIVE_SIGNAL_DATE:
                _validate_chain_stamp_matches(source, normalized_stamp, reference_day, _now_beijing())
            return chain, normalized_stamp
        except Exception as exc:
            failures.append(f"{source}: {type(exc).__name__}: {exc}")
            source_errors.append(exc)
    raise _source_failure_error(
        "510500期权链所有来源均不可用；" + "；".join(failures), source_errors
    ) from source_errors[-1]


def _fetch_510500_chain_for_day(expiry_ym: str, reference_day: date):
    """Let source selection reject a wrong-day/bad-clock primary before fallback."""
    cache = _IC_QUOTE_QUERY_CACHE.get()
    key = (evidence_adapter.canonical_ic_month(expiry_ym), reference_day, _HISTORICAL_REPLAY_DAY.get(),
           id(signal_evidence.current_reader.get()), id(signal_evidence.current_session.get()))
    if cache is not None and key in cache:
        chain, stamp = deepcopy(cache[key])
        if reference_day >= sse_identity.EFFECTIVE_SIGNAL_DATE:
            _validate_chain_stamp_matches("510500期权链", stamp, reference_day, _now_beijing())
        return chain, stamp
    token = _OPTION_CHAIN_REFERENCE_DAY.set(reference_day)
    try:
        chain, stamp = fetch_510500_chain_with_failover(expiry_ym)
        if reference_day >= sse_identity.EFFECTIVE_SIGNAL_DATE:
            _validate_chain_stamp_matches("510500期权链", stamp, reference_day, _now_beijing())
        if cache is not None:
            cache[key] = deepcopy((chain, stamp))
        return chain, stamp
    finally:
        _OPTION_CHAIN_REFERENCE_DAY.reset(token)


def _require_current_510500_expiry_months(months: list[str]) -> None:
    """Validate observed listings; never create an unobserved contract month."""
    reference_day = _now_beijing().date()
    first = (reference_day.year, reference_day.month)
    if reference_day > _fourth_wednesday(*first):
        first = _month_after(*first)
    second = _month_after(*first)
    expected = [f"{year:04d}{month:02d}" for year, month in
                [first, second, *_following_quarter_months(*second, 2)]]
    if months != expected:
        raise RuntimeError("510500挂牌月份陈旧或缺少当前挂牌月份，禁止按残缺月份选约")


def fetch_sse_510500_expiries() -> list[str]:
    payload = _sse_quote_json(
        "v1/sho/list/exchange/stockexpire",
        {"select": "stockid,expiremonth"},
    )
    months: set[str] = set()
    for row in _sse_projection_rows(payload, "上交所510500ETF挂牌月份"):
        if not isinstance(row, list) or len(row) != 2:
            raise RuntimeError("上交所期权挂牌月份字段缺失或格式异常")
        if str(row[0]) != "510500":
            continue
        value = str(row[1]).strip()
        if not re.fullmatch(r"20[0-9]{4}", value) or not 1 <= int(value[4:]) <= 12:
            # A malformed requested month is unknown, not proven unlisted.
            # Dropping it could change the nearest-expiry target.
            raise RuntimeError("上交所510500ETF挂牌月份存在无效值，禁止按残缺月份选约")
        months.add(value)
    ordered_months = sorted(months)
    if not ordered_months:
        raise RuntimeError("上交所未返回510500ETF期权挂牌月份")
    _require_current_510500_expiry_months(ordered_months)
    return ordered_months


def fetch_sina_510500_expiries() -> list[str]:
    raw = _public_quote_bytes(
        "https://stock.finance.sina.com.cn/futures/api/openapi.php/StockOptionService.getStockName",
        "新浪510500挂牌月份", params={"exchange": "null", "cate": "500ETF"})
    try:
        result = json.loads(raw)["result"]
        status, data = result["status"], result["data"]
        if type(status["code"]) is not int or status["code"] != 0 or data["stockId"] != "510500":
            raise ValueError("wrong status/underlying")
        months = data["contractMonth"]
        if not isinstance(months, list) or any(
            not isinstance(value, str) or not re.fullmatch(r"20[0-9]{2}-[0-9]{2}", value)
            or not 1 <= int(value[-2:]) <= 12 for value in months):
            raise ValueError("invalid listed month")
        # The endpoint repeats its current-month selector before four actual
        # listed months. Other duplicates or partial responses are invalid.
        if len(months) == 5 and months[0] == months[1]:
            months = months[1:]
        if len(months) != 4 or len(set(months)) != 4 or months != sorted(months):
            raise ValueError("incomplete/duplicate listing")
        _require_current_510500_expiry_months([value.replace("-", "") for value in months])
    except (ValueError, KeyError, TypeError) as exc:
        raise RuntimeError("新浪510500挂牌月份结构、标的或完整性未经核验") from exc
    return [value.replace("-", "") for value in months]


def fetch_510500_expiries_with_failover() -> list[str]:
    errors, failures = [], []
    for source, fetcher in (("上交所挂牌", fetch_sse_510500_expiries),
                            ("新浪挂牌", fetch_sina_510500_expiries)):
        try:
            return fetcher()
        except Exception as exc:
            errors.append(exc)
            failures.append(f"{source}: {type(exc).__name__}: {exc}")
    raise _source_failure_error("510500挂牌月份所有来源均不可用；" + "；".join(failures), errors) from errors[-1]


def fetch_sse_510500_historical_quote(day: date) -> dict[str, Any]:
    payload = _request_json(
        "https://web.ifzq.gtimg.cn/appstock/app/kline/kline",
        {"param": "sh510500,day,,,260"},
    )
    rows = ((payload.get("data") or {}).get("sh510500") or {}).get("day") or []
    points = {
        date.fromisoformat(str(row[0])): float(row[2])
        for row in rows
        if len(row) >= 3
    }
    if day not in points:
        raise RuntimeError(f"腾讯510500ETF历史日线缺少 {day} 收盘")
    ordered = sorted(points)
    location = ordered.index(day)
    previous = points[ordered[location - 1]] if location else points[day]
    return {
        "date": day.isoformat(),
        "time": "150000",
        "last": float(points[day]),
        "prev_close": float(previous),
        "source": "腾讯510500ETF历史日线",
    }


def fetch_sse_510500_dated_master(day: date) -> dict[str, adjusted_put_migration.Terms]:
    """A requested historical date is not evidence of the returned master date."""
    reference = adjusted_put_migration.day(day)
    try:
        response = _evidence_http_get(
            "https://query.sse.com.cn/commonQuery.do",
            stream=True,
            params={"isPagination": "false", "sqlId": adjusted_put_migration.MASTER_SQL,
                    "securityId": "510500", "queryDate": reference.strftime("%Y%m%d"),
                    "pageHelp.pageSize": "1000", "pageHelp.pageNo": "1"},
            timeout=_bounded_timeout(8),
            headers={"User-Agent": "Mozilla/5.0 POE-IC-IM-Research/1.0",
                     "Referer": "https://www.sse.com.cn/assortment/options/disclo/info/",
                     "Cache-Control": "no-cache", "Pragma": "no-cache"},
        )
    except (requests.ConnectionError, requests.Timeout, requests.exceptions.ChunkedEncodingError) as exc:
        raise SignalTransportError("IC历史Put官方逐日身份来源不可用，禁止猜测历史条款") from exc
    except requests.RequestException as exc:
        raise RuntimeError("IC历史Put官方逐日身份来源不可用，禁止猜测历史条款") from exc
    try:
        response.raise_for_status()
        payload = json.loads(_bounded_response_bytes(response, "IC历史Put官方主表"))
    except (requests.ConnectionError, requests.Timeout, requests.exceptions.ChunkedEncodingError) as exc:
        raise SignalTransportError("IC历史Put官方逐日身份响应传输中断") from exc
    except (requests.RequestException, ValueError) as exc:
        raise RuntimeError("IC历史Put官方逐日身份响应无效") from exc
    finally:
        response.close()
    return adjusted_put_migration.master_terms(payload, as_of=reference)


def fetch_sse_existing_put_historical_quote(
    contract: str, security_id: str, day: date
) -> tuple[pd.DataFrame, dict[str, Any]]:
    # This is a new calculation, even for a pre-fix date. Reading an old ledger
    # remains compatible; constructing a new row from an unproved M alias does
    # not. Obtain independent dated terms BEFORE any ID-keyed historical price.
    if (not isinstance(security_id, str) or not re.fullmatch(r"[0-9]{8}", security_id)
            or not isinstance(contract, str)):
        raise RuntimeError("IC历史Put请求证券身份格式无效")
    if re.fullmatch(r"510500P[0-9]{4}A[0-9]{5}", contract):
        raise RuntimeError("IC adjusted historical Put requires full unit/cost engine migration")
    if not re.fullmatch(r"510500P[0-9]{4}M[0-9]{5}", contract):
        raise RuntimeError("IC历史Put请求合约身份格式无效")
    terms = fetch_sse_510500_dated_master(day).get(security_id)
    if (not isinstance(terms, adjusted_put_migration.Terms)
            or terms.security_id != security_id or terms.contract != contract or terms.unit != 10000):
        raise RuntimeError("IC历史Put独立主数据与请求证券身份不一致")
    terms.require_available(day)
    # Keep the master expiry and every downstream tenor calculation consistent.
    # Unknown calendar years cannot be certified through a weekday fallback.
    _require_official_exchange_calendar(terms.expiry, "IC历史Put到期核验")
    if terms.expiry != _fourth_wednesday(terms.expiry.year, terms.expiry.month):
        raise RuntimeError("IC历史Put主表到期日与官方交易日历不一致")
    closes = fetch_option_closes(security_id)
    stamp = pd.Timestamp(day)
    if stamp not in closes.index:
        raise RuntimeError(f"上交所期权 {contract} 历史日线缺少 {day} 收盘")
    value = closes.loc[stamp]
    try:
        if isinstance(value, (bool, np.bool_, pd.Series)):
            raise ValueError("ambiguous or boolean price")
        price = float(value)
        if not math.isfinite(price) or price < 0:
            raise ValueError("nonfinite or negative price")
    except (ValueError, TypeError, OverflowError) as exc:
        raise RuntimeError("IC历史Put价格无效或同日价格不唯一") from exc
    frame = pd.DataFrame(
        [
            {
                "contract": terms.contract,
                "security_id": terms.security_id,
                "contract_unit": terms.unit,
                "last": price,
                "strike": float(terms.strike),
            }
        ]
    )
    return frame, {
        "date": day.isoformat(),
        "time": "150000",
        "source": str(closes.attrs.get("source") or "unknown"),
        "source_failures": list(closes.attrs.get("source_failures") or []),
        "identity_date": day.isoformat(),
        "identity_source": "上交所逐日合约主表",
        "identity_payload_sha256": terms.source_hash,
    }


def _is_exchange_trading_day(day: date) -> bool:
    if day.weekday() >= 5:
        return False
    if day.year not in _OFFICIAL_EXCHANGE_CALENDAR_YEARS:
        return True
    return day not in _EXCHANGE_CLOSURES


class CalendarCoverageError(RuntimeError):
    """A scheduling or delivery date lacks official calendar evidence."""


_SIGNAL_CALENDAR_DIAGNOSTICS = contextvars.ContextVar("signal_calendar_diagnostics", default=None)


def _require_official_exchange_calendar(day: date, label: str) -> None:
    if day.year not in _OFFICIAL_EXCHANGE_CALENDAR_YEARS:
        context = _SIGNAL_CALENDAR_DIAGNOSTICS.get()
        if context is not None:
            item = {"date": day.isoformat(), "purpose": label,
                    "source": "missing_official_calendar", "officially_verified": False}
            if item not in context["failures"]:
                context["failures"].append(item)
        covered = "/".join(str(year) for year in sorted(_OFFICIAL_EXCHANGE_CALENDAR_YEARS))
        raise CalendarCoverageError(
            f"{label}需要{day.year}年官方交易日历，但脚本仅覆盖{covered}年；"
            "暂停实时新鲜度判定和新增信号"
        )


def _require_model_expiry_calendar(day: date, label: str) -> None:
    """Only an explicit signal-diagnostic context may estimate a model expiry.

    Recording an estimate never authorizes selection, sizing or scheduling as a
    formal target. The public builder must return a separate diagnostic payload.
    Direct selector callers retain their original strict behavior.
    """
    if day.year in _OFFICIAL_EXCHANGE_CALENDAR_YEARS:
        return
    context = _SIGNAL_CALENDAR_DIAGNOSTICS.get()
    if context is None:
        _require_official_exchange_calendar(day, label)
        return
    item = {"date": day.isoformat(), "purpose": label,
            "source": "weekday_rule_unverified", "officially_verified": False}
    if item not in context["expiries"]:
        context["expiries"].append(item)


def make_diagnostic_signal(
    product: str, clock: datetime, reason: str, *,
    source_signal: dict[str, Any] | None = None,
    status: str = "calendar_unverified",
) -> dict[str, Any]:
    """Return observations with no executable targets or pending-plan fields."""
    clock = _beijing_clock(clock)
    context = _SIGNAL_CALENDAR_DIAGNOSTICS.get()
    source = source_signal or (context.get("signal", {}) if context else {})
    anchor = context.get("anchor", LIVE_CONTINUATION_ANCHOR[product]) if context else LIVE_CONTINUATION_ANCHOR[product]
    calendar_rows = list(context["expiries"] + context["failures"]) if context else []
    future = dict(context.get("future", {})) if context else {}
    future.update(formal_target_available=False, scope="verified_quotes_or_last_verified_identity_only")
    future.setdefault("last_verified_contract", anchor.get("post_core_contract"))
    future.setdefault("last_verified_day", anchor.get("last_verified_day"))
    result = {
        "product": product, "mode": source.get("mode", "intraday"),
        "market_date": source.get("market_date", clock.date()),
        "market_phase": source.get("market_phase", _market_phase(clock)),
        "close_confirmed": source.get("close_confirmed", False),
        "state_anchor_day": source.get("state_anchor_day", anchor.get("last_verified_day")),
        "fetch_time": clock.strftime("%Y-%m-%d %H:%M:%S"),
        "diagnostic_only": True, "signal_complete": False,
        "persistence_eligible": False, "v14_action": "HOLD_FAIL_CLOSED",
        "diagnostic_status": status, "diagnostic_reason": str(reason),
        "calendar_provisional": bool(calendar_rows) or status == "calendar_unverified",
        "calendar_diagnostics": calendar_rows,
        "calendar_coverage_warning": (_calendar_coverage_warning(clock.date())
            or _calendar_coverage_note(date.fromisoformat(row["date"]) for row in calendar_rows)),
        "diagnostic_future": future,
        "diagnostic_model": {key: source[key] for key in (
            "index_price", "score", "momentum_120", "momentum_score",
            "put_sizing_iv", "put_sizing_option_abs_delta", "put_sizing_expiry",
        ) if key in source},
        "data_notes": list(source.get("data_notes", [])),
    }
    # These are model observations, not independent confirmed futures targets:
    # the fixed-core route and quarter schedule can still depend on a Put leg
    # or the missing calendar. Copy only already-computed scalar values.
    references = {}
    for source_key, reference_key in (
        ("momentum_next_weight", "momentum_weight_reference"),
        ("grid_target", "grid_units_reference"),
        ("core_action", "quarter_action_reference"),
        ("roll_execution_date", "quarter_execution_date_reference"),
        ("roll_preview", "quarter_preview_reference"),
        ("roll_confirmed", "quarter_model_roll_reference"),
    ):
        value = source.get(source_key)
        if value is None or not isinstance(value, (str, bool, int, float, np.generic, date)):
            continue
        if isinstance(value, (float, np.floating)) and not math.isfinite(float(value)):
            continue
        references[reference_key] = deepcopy(value)
    if references:
        result["diagnostic_model"]["unconfirmed_references"] = {
            "confirmed": False,
            "label": "参考计算值（未确认）",
            **references,
        }
    # Deliberately do not copy the source dict: even a failed policy path can
    # contain newly-created ordinary/short/profit pending plans and targets.
    return result


def _calendar_coverage_warning(day: date) -> str | None:
    year_end = date(day.year, 12, 31)
    if ((year_end - day).days <= 90
            and day.year + 1 not in _OFFICIAL_EXCHANGE_CALENDAR_YEARS):
        return (f"交易日历覆盖预警：距离{day.year}年末不足90天，"
                f"{day.year + 1}年官方交易日历尚未载入；跨年日期仅作标注诊断，执行与落账须核验。")
    return None


def _roll_backward_exchange_day(
    day: date,
    *,
    require_official: bool = False,
) -> date:
    candidate = day
    if require_official:
        _require_official_exchange_calendar(candidate, "previous exchange session")
    while not _is_exchange_trading_day(candidate):
        candidate -= timedelta(days=1)
        if require_official:
            _require_official_exchange_calendar(candidate, "最近已完成交易日判定")
    return candidate


def _latest_completed_exchange_day(clock: datetime) -> date:
    clock = _beijing_clock(clock)
    _require_official_exchange_calendar(clock.date(), "实时行情新鲜度校验")
    phase = _market_phase(clock)
    if _is_exchange_trading_day(clock.date()) and phase == "收盘后":
        return clock.date()
    prior_day = clock.date() - timedelta(days=1)
    _require_official_exchange_calendar(prior_day, "最近已完成交易日判定")
    return _roll_backward_exchange_day(prior_day, require_official=True)


def _roll_forward_exchange_day(day: date, *, require_official: bool = False) -> date:
    candidate = day
    if require_official:
        _require_official_exchange_calendar(candidate, "next exchange session")
    while not _is_exchange_trading_day(candidate):
        candidate += timedelta(days=1)
        if require_official:
            _require_official_exchange_calendar(candidate, "next exchange session")
    return candidate


def _option_maintenance_session(day: date) -> bool:
    _require_official_exchange_calendar(day, "月度Put提醒日历")
    return _is_exchange_trading_day(day)


def _third_friday(year: int, month: int) -> date:
    weeks = month_calendar.monthcalendar(year, month)
    fridays = [
        week[month_calendar.FRIDAY] for week in weeks if week[month_calendar.FRIDAY]
    ]
    return _roll_forward_exchange_day(date(year, month, fridays[2]))


def _fourth_wednesday(year: int, month: int) -> date:
    weeks = month_calendar.monthcalendar(year, month)
    days = [
        week[month_calendar.WEDNESDAY]
        for week in weeks
        if week[month_calendar.WEDNESDAY]
    ]
    return _roll_forward_exchange_day(date(year, month, days[3]))


def _contract_month(contract: str) -> tuple[int, int]:
    match = re.fullmatch(
        r"(?:(?:IC|IM)(\d{2})(\d{2})|MO(\d{2})(\d{2})-[CP]-\d+)",
        str(contract).upper(),
    )
    if not match:
        raise ValueError(f"无法识别合约月份: {contract}")
    year = match.group(1) or match.group(3)
    month = match.group(2) or match.group(4)
    return 2000 + int(year), int(month)


def select_active_future(product: str, quotes: pd.DataFrame, today: date, *, purpose: str = "selection") -> pd.Series:
    if purpose not in {"selection", "maintenance_reference"}:
        raise ValueError("unsupported future reference purpose")
    if "lastprice" not in quotes:
        raise RuntimeError(f"{product} 延时行情缺少 lastprice")
    candidates = quotes[quotes["instrument"].str.fullmatch(rf"{product}\d{{4}}")].copy()
    candidates = candidates[
        np.isfinite(candidates["lastprice"].to_numpy(dtype=float))
        & candidates["lastprice"].gt(0)
    ]
    if candidates.empty:
        raise RuntimeError(f"{product} 无可用期货合约")
    candidates["expiry"] = candidates["instrument"].map(
        lambda value: _third_friday(*_contract_month(value))
    )
    eligible = candidates[candidates["expiry"].ge(today)].sort_values("expiry")
    if eligible.empty:
        latest = candidates["expiry"].max()
        raise RuntimeError(
            f"{product} 行情中的期货合约均已到期（最晚规则到期日 {latest}）"
        )
    selected = eligible.iloc[0]
    if purpose != "maintenance_reference" or not _expiry_definitely_after_reference(selected["expiry"], today):
        _require_model_expiry_calendar(selected["expiry"], "selected future expiry")
    return selected


def _next_listed_future_contract(
    product: str,
    quotes: pd.DataFrame,
    active_expiry: date,
) -> str:
    listed = {
        str(contract)
        for contract in quotes.attrs.get(
            "listed_instruments", quotes["instrument"].tolist()
        )
        if re.fullmatch(rf"{product}\d{{4}}", str(contract))
    }
    later = sorted(
        (
            contract
            for contract in listed
            if _third_friday(*_contract_month(contract)) > active_expiry
        ),
        key=lambda contract: _third_friday(*_contract_month(contract)),
    )
    return later[0] if later else ""


def _require_listed_future_quote(
    product: str,
    quotes: pd.DataFrame,
    contract: str,
) -> pd.Series:
    rows = quotes[quotes["instrument"].eq(contract)]
    if rows.empty:
        raise RuntimeError(
            f"{product}规则下一挂牌合约 {contract} 缺少有限正价，禁止跳到更远月份"
        )
    return rows.iloc[0]


def _require_selected_510500_quote_time(
    row: pd.Series, clock: datetime, market_date: date | None, *, source: str | None = None
) -> None:
    if "source_stamp" not in row.index:
        if str(source or "").startswith("新浪"):
            raise RuntimeError("新浪510500期权合约缺少有效逐行时间戳")
        return
    if market_date is None:
        raise RuntimeError("新浪510500期权逐行报价缺少信号日，禁止校验自身日期")
    stamp = row["source_stamp"]
    if pd.isna(stamp) or not isinstance(stamp, (datetime, pd.Timestamp)) or stamp.tzinfo is None:
        raise RuntimeError("新浪510500期权合约缺少有效逐行时间戳")
    if stamp.date() != market_date:
        raise RuntimeError("新浪510500期权选中合约报价日期与信号日不一致")
    now = clock.astimezone(BEIJING) if clock.tzinfo else clock.replace(tzinfo=BEIJING)
    now = _iv_observation_clock(now)
    close_confirmed = stamp.date() < now.date() or _market_phase(now) == "收盘后"
    try:
        # Sina fallback has per-contract timestamps, so selected core/candidate
        # rows must pass the 20-minute gate. SSE's aggregate source cannot
        # supply equivalent row-level evidence; the stricter fallback is intentional.
        _validate_iv_monitor_times(stamp.date(), stamp, stamp, now, close_confirmed)
    except ValueError as exc:
        raise RuntimeError("新浪510500期权合约报价时间不满足20分钟新鲜度") from exc


def _quote_row(
    frame: pd.DataFrame, contract: str, market_date: date | None = None,
    *, quote_source: str | None = None,
) -> pd.Series | None:
    rows = (
        frame[frame["instrument"].eq(contract)]
        if "instrument" in frame
        else frame[frame["contract"].eq(contract)]
    )
    if not len(rows):
        return None
    row = rows.iloc[0]
    try:
        _require_selected_510500_quote_time(row, _now_beijing(), market_date, source=quote_source)
    except RuntimeError:
        # A stale held leg is missing market evidence, not a global lookup
        # failure.  A changing action must still fail in _require_existing_leg_quote.
        return None
    return row


def _normal_cdf(value: float) -> float:
    return 0.5 * (1.0 + math.erf(value / math.sqrt(2.0)))


def _bs_price_delta(
    option_type: str,
    spot: float,
    strike: float,
    rate: float,
    dividend: float,
    sigma: float,
    years: float,
) -> tuple[float, float]:
    if min(spot, strike, sigma, years) <= 0:
        raise ValueError("Black-Scholes 输入必须为正")
    root_t = math.sqrt(years)
    d1 = (math.log(spot / strike) + (rate - dividend + 0.5 * sigma * sigma) * years) / (
        sigma * root_t
    )
    d2 = d1 - sigma * root_t
    if option_type == "C":
        price = spot * math.exp(-dividend * years) * _normal_cdf(
            d1
        ) - strike * math.exp(-rate * years) * _normal_cdf(d2)
        delta = math.exp(-dividend * years) * _normal_cdf(d1)
    else:
        price = strike * math.exp(-rate * years) * _normal_cdf(-d2) - spot * math.exp(
            -dividend * years
        ) * _normal_cdf(-d1)
        delta = -math.exp(-dividend * years) * _normal_cdf(-d1)
    return price, delta


def _implied_volatility(
    option_type: str,
    market_price: float,
    spot: float,
    strike: float,
    rate: float,
    dividend: float,
    years: float,
) -> float | None:
    try:
        market_price, spot, strike, rate, dividend, years = (
            float(value) for value in (market_price, spot, strike, rate, dividend, years)
        )
    except (TypeError, ValueError, OverflowError):
        return None
    if not all(math.isfinite(value) for value in (market_price, spot, strike, rate, dividend, years)):
        return None
    if min(market_price, spot, strike, years) <= 0:
        return None
    low, high = 0.001, 5.0
    low_price = _bs_price_delta(option_type, spot, strike, rate, dividend, low, years)[
        0
    ]
    high_price = _bs_price_delta(
        option_type, spot, strike, rate, dividend, high, years
    )[0]
    if market_price < low_price - 1e-8 or market_price > high_price + 1e-8:
        return None
    for _ in range(80):
        middle = (low + high) / 2.0
        price = _bs_price_delta(
            option_type, spot, strike, rate, dividend, middle, years
        )[0]
        if price < market_price:
            low = middle
        else:
            high = middle
    return (low + high) / 2.0


def _format_market(contract: str, row: pd.Series | None) -> str:
    if row is None:
        return f"`{contract}`（当前行情缺失）"
    last = float(row.get("lastprice", row.get("last", np.nan)))
    bid = float(row.get("bprice", np.nan))
    ask = float(row.get("sprice", np.nan))
    text = f"`{contract}`，最新 {last:.4g}"
    if row.get("pricing_basis") == "official_settlement_estimate_zero_volume":
        text = f"`{contract}`，当日结算估计 {last:.4g}（零成交量；非成交价）"
    elif row.get("pricing_basis") == "live_bid_ask_mid_estimate_zero_volume":
        text = f"`{contract}`，双边中价估计 {last:.4g}（零成交量；非成交价）"
    if np.isfinite(bid) and bid >= 0 and np.isfinite(ask) and ask >= 0:
        text += f"，买/卖 {bid:.4g}/{ask:.4g}"
    return text


def _require_existing_leg_quote(
    leg: str,
    contract: str,
    row: pd.Series | None,
    action: str,
) -> None:
    state_change = action in {
        "ROLL",
        "RESIZE_OR_ROLL",
        "CLOSE_CALL",
        "RESCUE_NEXT_LISTED",
    }
    if not state_change:
        return
    if row is None:
        raise RuntimeError(f"{leg}旧腿 {contract} 缺少有效报价，禁止继续{action}")
    last = float(row.get("lastprice", row.get("last", np.nan)))
    if not np.isfinite(last) or last <= 0:
        raise RuntimeError(f"{leg}旧腿 {contract} 缺少有限正价，禁止继续{action}")
    if "position" in row.index:
        position = float(row.get("position", np.nan))
        im_put = bool(re.fullmatch(r"MO\d{4}-P-\d+", str(contract)))
        if not np.isfinite(position) or position < 0 or (position == 0 and not im_put):
            raise RuntimeError(f"{leg}旧腿 {contract} 缺少正持仓量，禁止继续{action}")
    if "bprice" in row.index and "sprice" in row.index:
        bid = float(row.get("bprice", np.nan))
        ask = float(row.get("sprice", np.nan))
        if not all(np.isfinite(value) and value > 0 for value in (bid, ask)) or bid > ask:
            raise RuntimeError(f"{leg}旧腿 {contract} 缺少双边有效报价，禁止继续{action}")


def _format_quote_number(value: Any, decimals: int = 2) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "缺失"
    if not np.isfinite(number) or number < 0:
        return "缺失"
    return f"{number:.{decimals}f}"


def _grid_target(product: str, live: dict[str, Any]) -> tuple[float, str]:
    current = float(live["grid_current_units"])
    target = float(live["grid_target_units"])
    if target > current:
        return target, "ADD_GRID"
    if target < current:
        return target, "EXIT_GRID"
    return current, "HOLD"


def _apportion_integer_quantity(
    total: int, raw_parts: dict[str, float]
) -> dict[str, int]:
    """Split an already-rounded total without creating phantom contracts."""
    if total < 0 or any(value < 0 for value in raw_parts.values()):
        raise ValueError("Put张数及分袖原始张数不得为负")
    result = {name: math.floor(value) for name, value in raw_parts.items()}
    remaining = total - sum(result.values())
    if remaining < 0:
        raise ValueError("Put整数总张数小于各分袖向下取整之和")
    ranked = sorted(
        raw_parts,
        key=lambda name: (-(raw_parts[name] - math.floor(raw_parts[name])), name),
    )
    positive = [name for name in ranked if raw_parts[name] > 0]
    if remaining and not positive:
        raise ValueError("Put总张数为正但所有分袖贡献均为零")
    for index in range(remaining):
        result[positive[index % len(positive)]] += 1
    return result


def _ic_put_quantity_breakdown(
    full_equivalent: int,
    absolute_delta: float,
    core_delta: float,
    momentum_delta: float,
    total_qty: int | None = None,
) -> dict[str, float | int]:
    if absolute_delta <= 1e-8:
        raise ValueError("IC Put绝对Delta必须大于0")
    raw_parts = {
        "core": full_equivalent * core_delta / absolute_delta,
        "momentum": full_equivalent * momentum_delta / absolute_delta,
    }
    combined_raw = sum(raw_parts.values())
    if total_qty is None:
        total_qty = max(1, round(combined_raw)) if combined_raw > 0 else 0
    split = _apportion_integer_quantity(total_qty, raw_parts)
    return {
        "total_raw": combined_raw,
        "total": total_qty,
        "core_raw": raw_parts["core"],
        "core": split["core"],
        "momentum_raw": raw_parts["momentum"],
        "momentum": split["momentum"],
        "grid": 0,
    }


def _gov10y_for_day(product: str, day: date) -> float:
    return _resolve_gov10y_evidence(day, _now_beijing(), float(FROZEN[product]["gov10y"]), DATA_CUTOFF)["yield_decimal"]


def _ic_current_quantity_breakdown(anchor: dict[str, Any] | None = None) -> dict[str, int]:
    """Read held contracts without repricing them using today's Delta."""
    anchor = LIVE_CONTINUATION_ANCHOR["IC"] if anchor is None else anchor
    def integer(value):
        number = float(value)
        if not math.isfinite(number) or number < 0 or not number.is_integer():
            raise RuntimeError("IC账本Put分袖数量必须为非负整数")
        return int(number)
    total = integer(anchor["post_put_qty"])
    keys = ("verified_core_put_qty", "verified_momentum_put_qty")
    if any(key in anchor for key in keys):
        if not all(key in anchor for key in keys):
            raise RuntimeError("IC账本Put分袖数量不完整")
        core, momentum = (integer(anchor[key]) for key in keys)
    elif total == 0:
        core = momentum = 0
    elif float(anchor["verified_momentum_put_delta"]) == 0 and float(anchor["verified_core_put_delta"]) > 0:
        core, momentum = total, 0
    elif float(anchor["verified_core_put_delta"]) == 0 and float(anchor["verified_momentum_put_delta"]) > 0:
        core, momentum = 0, total
    else:
        raise RuntimeError("IC双袖Put账本缺少已核验分袖数量，禁止按今日Delta猜算")
    if core + momentum != total:
        raise RuntimeError("IC账本Put分袖数量之和不等于总张数")
    return {"total": total, "core": core, "momentum": momentum, "grid": 0}


def _size_existing_ic_put(
    contract: str,
    quote: pd.Series,
    today: date,
    etf_price: float,
    future_price: float,
    current_total_qty: int,
    current_core_delta: float,
    current_momentum_delta: float,
    target_core_delta: float,
    target_momentum_delta: float,
) -> dict[str, Any]:
    """Resize an already-audited IC Put without silently reselecting its contract."""
    _require_held_ic_put_identity(contract, LIVE_CONTINUATION_ANCHOR["IC"].get("post_put_security_id"), quote, today)
    match = re.fullmatch(r"510500P([0-9]{2})([0-9]{2})M([0-9]{5})", contract)
    if not match:
        raise RuntimeError(f"无法解析IC Put月份或行权价: {contract}")
    expiry = _fourth_wednesday(2000 + int(match.group(1)), int(match.group(2)))
    _require_model_expiry_calendar(expiry, "held IC Put sizing expiry")
    strike = float(match.group(3)) / 1000.0
    market_price = float(quote.get("last", np.nan))
    years = max((expiry - today).days, 1) / 365.0
    iv = _implied_volatility(
        "P",
        market_price,
        etf_price,
        strike,
        _gov10y_for_day("IC", today),
        float(FROZEN["IC"]["dividend"]),
        years,
    )
    if iv is None:
        raise RuntimeError(f"IC既有Put {contract} 无法由有效价格反解IV，禁止自动改张")
    absolute_delta = abs(
        _bs_price_delta(
            "P",
            etf_price,
            strike,
            _gov10y_for_day("IC", today),
            float(FROZEN["IC"]["dividend"]),
            iv,
            years,
        )[1]
    )
    if absolute_delta <= 1e-8:
        raise RuntimeError(f"IC既有Put {contract} 的绝对Delta无效，禁止自动改张")
    full_equivalent = max(1, round(future_price * 200.0 / (etf_price * 10_000.0)))
    current_breakdown = _ic_current_quantity_breakdown()
    if current_breakdown["total"] != current_total_qty:
        raise RuntimeError("IC当前Put总张数与账本不一致")
    target_total_delta = target_core_delta + target_momentum_delta
    target_total_qty = (
        max(1, round(full_equivalent * target_total_delta / absolute_delta))
        if target_total_delta > 0
        else 0
    )
    target_breakdown = _ic_put_quantity_breakdown(
        full_equivalent,
        absolute_delta,
        target_core_delta,
        target_momentum_delta,
        target_total_qty,
    )
    return {
        "put_sizing_future_price": future_price,
        "put_sizing_future_multiplier": 200,
        "put_sizing_future_notional": future_price * 200.0,
        "put_sizing_etf_price": etf_price,
        "put_sizing_option_multiplier": 10_000,
        "put_sizing_etf_option_notional": etf_price * 10_000.0,
        "put_sizing_full_equivalent_contracts": full_equivalent,
        "put_sizing_target_delta": target_total_delta,
        "put_sizing_option_abs_delta": absolute_delta,
        "put_sizing_raw_qty": full_equivalent * target_total_delta / absolute_delta,
        "put_sizing_rounded_qty": target_total_qty,
        "put_current_total_qty": int(current_breakdown["total"]),
        "put_current_core_qty": int(current_breakdown["core"]),
        "put_current_momentum_qty": int(current_breakdown["momentum"]),
        "put_current_grid_qty": 0,
        "put_target_total_qty": int(target_breakdown["total"]),
        "put_target_core_qty": int(target_breakdown["core"]),
        "put_target_momentum_qty": int(target_breakdown["momentum"]),
        "put_target_grid_qty": 0,
        "put_sizing_iv": iv,
        "put_sizing_expiry": expiry,
        "put_sizing_strike": strike,
        "put_sizing_signal_date": today,
    }


def select_ic_put_for_reset(
    today: date,
    etf_price: float,
    future_price: float,
    target_delta: float,
) -> dict[str, Any]:
    if not 0.0 <= target_delta <= 1.0:
        raise ValueError(f"IC Put目标绝对Delta超出[0, 1]: {target_delta}")
    if math.isclose(target_delta, 0.0, rel_tol=0.0, abs_tol=1e-12):
        return {
            "contract": None,
            "quote": None,
            "expiry": None,
            "strike": None,
            "qty": 0,
            "iv": None,
            "absolute_delta": None,
            "stamp": None,
        }
    target_day = (pd.Timestamp(today) + pd.DateOffset(months=3)).date()
    months = fetch_510500_expiries_with_failover()
    candidates: list[tuple[str, date]] = []
    for value in months:
        expiry = _fourth_wednesday(int(value[:4]), int(value[4:]))
        if expiry > today:
            candidates.append((value, expiry))
    if not candidates:
        raise RuntimeError("没有未来510500ETF Put挂牌月份")
    month, expiry = min(
        candidates, key=lambda item: (abs((item[1] - target_day).days), item[1])
    )
    _require_model_expiry_calendar(expiry, "selected IC Put expiry")
    chain, stamp = _fetch_510500_chain_for_day(month[2:], today)
    puts = chain[
        chain["contract"].str.contains(rf"510500P{month[2:]}M", regex=True)
        & chain["last"].gt(0)
    ].copy()
    if puts.empty:
        raise RuntimeError(f"{month} 没有可用标准510500ETF Put")
    puts["strike_error"] = (puts["strike"] - 0.95 * etf_price).abs()
    selected = puts.sort_values(["strike_error", "contract"]).iloc[0]
    _require_selected_510500_quote_time(selected, _now_beijing(), today, source=stamp.get("source"))
    years = max((expiry - today).days, 1) / 365.0
    iv = _implied_volatility(
        "P",
        float(selected["last"]),
        etf_price,
        float(selected["strike"]),
        _gov10y_for_day("IC", today),
        float(FROZEN["IC"]["dividend"]),
        years,
    )
    absolute_delta = None
    qty = None
    if iv is not None:
        absolute_delta = abs(
            _bs_price_delta(
                "P",
                etf_price,
                float(selected["strike"]),
                _gov10y_for_day("IC", today),
                float(FROZEN["IC"]["dividend"]),
                iv,
                years,
            )[1]
        )
        full_qty = max(1, round(future_price * 200.0 / (etf_price * 10_000.0)))
        qty = (
            max(1, round(full_qty * target_delta / absolute_delta))
            if absolute_delta > 1e-8
            else None
        )
    return {
        "contract": str(selected["contract"]),
        "security_id": _ic_put_selected_security_id(selected),
        "quote": selected,
        "expiry": expiry,
        "strike": float(selected["strike"]),
        "qty": qty,
        "iv": iv,
        "absolute_delta": absolute_delta,
        "stamp": stamp,
    }


def _mo_enriched(quotes: pd.DataFrame, option_type: str, today: date) -> pd.DataFrame:
    pattern = rf"MO(\d{{2}})(\d{{2}})-{option_type}-(\d+)"
    rows = quotes[quotes["instrument"].str.fullmatch(pattern)].copy()
    parsed = rows["instrument"].str.extract(pattern)
    rows["expiry"] = [
        _third_friday(2000 + int(year), int(month))
        for year, month in zip(parsed[0], parsed[1], strict=True)
    ]
    rows["strike"] = pd.to_numeric(parsed[2], errors="coerce")
    return rows[rows["expiry"].gt(today)].copy()


def _listed_mo_enriched(
    quotes: pd.DataFrame,
    option_type: str,
    today: date,
) -> pd.DataFrame:
    """Parse the raw listed set without pretending no-trade rows are executable."""

    instruments = quotes.attrs.get("listed_instruments")
    if not instruments:
        instruments = quotes["instrument"].tolist()
    raw = pd.DataFrame({"instrument": sorted(set(map(str, instruments)))})
    pattern = rf"MO(\d{{2}})(\d{{2}})-{option_type}-(\d+)"
    raw = raw[raw["instrument"].str.fullmatch(pattern)].copy()
    if raw.empty:
        return raw.assign(expiry=pd.Series(dtype=object), strike=pd.Series(dtype=float))
    parsed = raw["instrument"].str.extract(pattern)
    raw["expiry"] = [
        _third_friday(2000 + int(year), int(month))
        for year, month in zip(parsed[0], parsed[1], strict=True)
    ]
    raw["strike"] = pd.to_numeric(parsed[2], errors="coerce")
    return raw[raw["expiry"].gt(today)].copy()


def select_im_put_for_reset(
    quotes: pd.DataFrame, today: date, spot: float
) -> pd.Series:
    listed_puts = _listed_mo_enriched(quotes, "P", today)
    target_day = (pd.Timestamp(today) + pd.DateOffset(months=3)).date()
    expiries = sorted(set(listed_puts["expiry"]))
    if not expiries:
        raise RuntimeError("没有未来MO Put挂牌月份")
    expiry = min(expiries, key=lambda value: (abs((value - target_day).days), -value.toordinal()))
    _require_model_expiry_calendar(expiry, "selected IM Put expiry")
    listed_month = listed_puts[listed_puts["expiry"].eq(expiry)].copy()
    listed_month["strike_error"] = (listed_month["strike"] - im_put_policy.moneyness(today) * spot).abs()
    selected_contract = str(
        listed_month.sort_values(["strike_error", "instrument"]).iloc[0]["instrument"]
    )
    puts = _mo_enriched(quotes, "P", today)
    eligible = puts[
        puts["instrument"].eq(selected_contract)
        & puts["lastprice"].gt(0)
        & (im_put_policy.active(today) | puts["volume"].gt(0))
        & (im_put_policy.active(today) | puts["position"].gt(0))
    ].copy()
    if eligible.empty:
        raise RuntimeError(
            f"MO规则目标Put {selected_contract} 已挂牌但缺少可执行报价，禁止跳月或跳行权价"
        )
    return eligible.iloc[0]


def _independent_im_put_target_expiry(
    quotes: pd.DataFrame, today: date
) -> date:
    """Match the independent replay's 3m listed-month choice, including ties."""

    listed_puts = _listed_mo_enriched(quotes, "P", today)
    target_day = (pd.Timestamp(today) + pd.DateOffset(months=3)).date()
    expiries = sorted(set(listed_puts["expiry"]))
    if not expiries:
        raise RuntimeError("没有未来MO Put挂牌月份")
    # Historical independent replay chooses the later actual expiry on a tie.
    expiry = min(expiries, key=lambda value: (abs((value - target_day).days), -value.toordinal()))
    _require_model_expiry_calendar(expiry, "independent IM Put expiry")
    return expiry


def select_independent_im_put_for_reset(
    quotes: pd.DataFrame, today: date, spot: float
) -> pd.Series:
    """Select a fresh independent-sleeve Put with replay-identical month semantics."""

    expiry = _independent_im_put_target_expiry(quotes, today)
    listed_puts = _listed_mo_enriched(quotes, "P", today)
    listed_month = listed_puts[listed_puts["expiry"].eq(expiry)].copy()
    listed_month["strike_error"] = (listed_month["strike"] - im_put_policy.moneyness(today) * spot).abs()
    selected_contract = str(
        listed_month.sort_values(["strike_error", "instrument"]).iloc[0]["instrument"]
    )
    puts = _mo_enriched(quotes, "P", today)
    eligible = puts[
        puts["instrument"].eq(selected_contract)
        & puts["lastprice"].gt(0)
        & (im_put_policy.active(today) | puts["volume"].gt(0))
        & (im_put_policy.active(today) | puts["position"].gt(0))
    ].copy()
    if eligible.empty:
        raise RuntimeError(
            f"MO动量Put规则目标 {selected_contract} 已挂牌但缺少可执行报价，禁止跳月或跳行权价"
        )
    return eligible.iloc[0]


def select_im_call_d10(
    quotes: pd.DataFrame, today: date, spot: float, anchor_expiry: date
) -> dict[str, Any] | None:
    listed_calls = _listed_mo_enriched(quotes, "C", today)
    listed_expiries = sorted(
        set(listed_calls.loc[listed_calls["expiry"].gt(anchor_expiry), "expiry"])
    )
    if not listed_expiries:
        return None
    expiry = listed_expiries[0]
    calls = _mo_enriched(quotes, "C", today)
    calls = calls[
        calls["expiry"].eq(expiry)
        & calls["strike"].gt(spot)
        & calls["lastprice"].gt(0)
        & ((today >= v14_policy.REPEAT_ROLL_EFFECTIVE_SIGNAL_DATE) | calls["volume"].gt(0))
        & ((today >= v14_policy.REPEAT_ROLL_EFFECTIVE_SIGNAL_DATE) | calls["position"].gt(0))
    ].copy()
    if calls.empty:
        return None
    selections: list[dict[str, Any]] = []
    for row in calls.itertuples(index=False):
        years = max((expiry - today).days, 1) / 365.0
        iv = _implied_volatility(
            "C",
            float(row.lastprice),
            spot,
            float(row.strike),
            _gov10y_for_day("IM", today),
            float(FROZEN["IM"]["dividend"]),
            years,
        )
        if iv is None:
            continue
        delta = _bs_price_delta(
            "C",
            spot,
            float(row.strike),
            _gov10y_for_day("IM", today),
            float(FROZEN["IM"]["dividend"]),
            iv,
            years,
        )[1]
        selections.append(
            {
                "row": pd.Series(row._asdict()),
                "iv": iv,
                "delta": delta,
                "expiry": expiry,
            }
        )
    if not selections:
        return None
    return min(
        selections,
        key=lambda item: (abs(item["delta"] - 0.10), -float(item["row"]["position"])),
    )


def select_im_call_rescue(
    quotes: pd.DataFrame,
    today: date,
    spot: float,
    old_expiry: date,
    old_strike: float,
) -> dict[str, Any] | None:
    listed_calls = _listed_mo_enriched(quotes, "C", today)
    listed_expiries = sorted(
        set(listed_calls.loc[listed_calls["expiry"].gt(old_expiry), "expiry"])
    )
    if not listed_expiries:
        return None
    expiry = listed_expiries[0]
    listed_expiry = listed_calls[
        listed_calls["expiry"].eq(expiry)
        & listed_calls["strike"].ge(old_strike * 1.05 - 1e-12)
    ].sort_values(["strike", "instrument"])
    if listed_expiry.empty:
        return None
    target_contract = str(listed_expiry.iloc[0]["instrument"])
    calls = _mo_enriched(quotes, "C", today)
    calls = calls[
        calls["instrument"].eq(target_contract)
        & calls["lastprice"].gt(0)
        & ((today >= v14_policy.REPEAT_ROLL_EFFECTIVE_SIGNAL_DATE) | calls["volume"].gt(0))
        & ((today >= v14_policy.REPEAT_ROLL_EFFECTIVE_SIGNAL_DATE) | calls["position"].gt(0))
    ].copy()
    if calls.empty:
        return None
    row = calls.iloc[0]
    years = max((expiry - today).days, 1) / 365.0
    iv = _implied_volatility(
        "C",
        float(row["lastprice"]),
        spot,
        float(row["strike"]),
        _gov10y_for_day("IM", today),
        float(FROZEN["IM"]["dividend"]),
        years,
    )
    if iv is None:
        return None
    delta = _bs_price_delta(
        "C",
        spot,
        float(row["strike"]),
        _gov10y_for_day("IM", today),
        float(FROZEN["IM"]["dividend"]),
        iv,
        years,
    )[1]
    return {"row": row, "iv": iv, "delta": delta, "expiry": expiry}


def _market_phase(clock: datetime) -> str:
    clock = _beijing_clock(clock)
    if not _is_exchange_trading_day(clock.date()):
        return "非交易日"
    current = clock.time()
    if time(9, 30) <= current < time(11, 30) or time(13, 0) <= current < time(15, 0):
        return "盘中"
    if time(9, 25) <= current < time(9, 30):
        return "集合竞价"
    if current >= time(15, 0):
        return "收盘后"
    if current < time(9, 25):
        return "开盘前"
    return "午间休市"


def _expiry_definitely_after_reference(expiry: date, reference: date) -> bool:
    """Prove a pure comparison from a nominal expiry's lower bound.

    The callers supply a rule-based expiry which exchange holidays can only
    postpone.  For an officially covered reference date in an earlier year,
    that unknown future year's expiry is therefore strictly later regardless
    of its final holiday adjustment.  This does not verify the expiry or
    authorize its use for ranking, sizing, scheduling or formal targets.
    """
    _require_official_exchange_calendar(reference, "expiry comparison reference")
    return (expiry.year not in _OFFICIAL_EXCHANGE_CALENDAR_YEARS
            and expiry.year > reference.year and expiry > reference)


def _is_pre_expiry_close(today: date, active_expiry: date, close_confirmed: bool) -> bool:
    _require_official_exchange_calendar(today, "option maintenance reference")
    next_trading_day = _roll_forward_exchange_day(today + timedelta(days=1), require_official=True)
    if _expiry_definitely_after_reference(active_expiry, next_trading_day):
        return False
    _require_model_expiry_calendar(active_expiry, "option maintenance expiry")
    return next_trading_day == active_expiry and close_confirmed is True


def _calendar_coverage_note(expiries: Iterable[date]) -> str | None:
    uncovered_years = sorted(
        {day.year for day in expiries if day.year not in _OFFICIAL_EXCHANGE_CALENDAR_YEARS}
    )
    if not uncovered_years:
        return None
    years = "/".join(str(year) for year in uncovered_years)
    return (
        f"挂牌合约包含{years}年到期日，但脚本尚未载入该年度官方休市表；"
        "这些到期日未核验，仅供诊断展示，不能作为新增目标、维护或提醒的日期依据；须补齐官方安排后验证"
    )


def require_signal_calendar(product: str, signal: dict[str, Any]) -> None:
    """Guard consumed signal dates without treating every listed row as a target."""
    def covered(value: Any, label: str) -> None:
        if value is not None:
            day = value if isinstance(value, date) else date.fromisoformat(str(value)[:10])
            _require_official_exchange_calendar(day, f"{product} {label}")

    def contract_covered(value: Any, label: str, execution_day: Any = None) -> None:
        if not value:
            return
        text = str(value)
        match = re.fullmatch(r"(?:IC|IM)([0-9]{2})([0-9]{2})", text)
        option = False
        if match is None:
            match = re.fullmatch(r"MO([0-9]{2})([0-9]{2})-[PC]-[0-9]+", text)
        if match is None:
            match = re.fullmatch(r"510500P([0-9]{2})([0-9]{2})[MA][0-9]{5}", text)
            option = True
        if match is None:
            raise RuntimeError(f"{product} {label}合约语法非法，不能核验交易日历: {text}")
        year, month = 2000 + int(match.group(1)), int(match.group(2))
        covered(date(year, month, 1), label)
        if execution_day is not None:
            expiry = _fourth_wednesday(year, month) if option else _third_friday(year, month)
            covered(expiry, label)
            execution = date.fromisoformat(str(execution_day)[:10])
            if expiry < execution:
                raise RuntimeError(f"{product} {label}目标合约已到期: {text} expiry={expiry} execution={execution}")

    def positive(value: Any) -> bool:
        try:
            return float(value) > 0
        except (ValueError, TypeError):
            # Numeric shape remains the responsibility of the existing validators.
            return False

    covered(signal.get("market_date"), "market date")
    covered(signal.get("next_trade_date"), "next session")
    # next_core and quote-frame expiries are diagnostics until actually adopted.
    contract_covered(signal.get("core_target"), "core target")
    target_day = (signal.get("market_date") if signal.get("option_monthly_reset_due")
                  else signal.get("next_trade_date", signal.get("market_date")))
    ic_shared_qty = (signal.get("put_target_momentum_qty")
                     if signal.get("v14_core_put_contract")
                     and signal.get("v14_core_put_contract") != signal.get("put_target_contract")
                     else signal.get("put_target_total_qty"))
    quantities = ({"put_target_contract": ic_shared_qty,
                   "v14_core_put_contract": signal.get("v14_core_put_qty")}
                  if product == "IC" else
                  {"put_target_contract": signal.get("core_put_target_qty_normalized"),
                   "core_put_target_contract": signal.get("core_put_target_qty_normalized"),
                   "momentum_put_target_contract": signal.get("momentum_put_target_qty_normalized")})
    for target in ("put_target_contract", "core_put_target_contract", "v14_core_put_contract",
                   "momentum_put_target_contract"):
        contract_covered(signal.get(target), target, target_day if positive(quantities.get(target)) else None)
    if (signal.get("v14_action") in {"ENTER_SHORT_PUT", "ROLL_SHORT_PUT"}
            or float(signal.get("v14_short_put_qty_normalized", 0) or 0) > 0):
        covered(signal.get("v14_short_put_expiry"), "new short Put expiry")
        opening_short = signal.get("v14_action") in {"ENTER_SHORT_PUT", "ROLL_SHORT_PUT"}
        contract_covered(signal.get("v14_short_put_contract"), "new short Put",
                         signal.get("next_trade_date") if opening_short else None)
    if signal.get("v14_profit_pending"):
        covered(signal.get("v14_profit_execution_day"), "profit reentry execution")
        contract_covered(signal.get("v14_profit_reentry_contract"), "profit reentry",
                         signal.get("v14_profit_execution_day"))
    for key in ("v14_ordinary_put_open_plan", "v14_ordinary_put_pending", "v14_short_put_open_pending"):
        plan = signal.get(key)
        if not isinstance(plan, dict):
            continue
        covered(plan.get("execution_day"), key)
        contract_covered(plan.get("new_contract"), key, plan.get("execution_day"))
        legs = plan.get("legs", {})
        for leg in (legs.values() if isinstance(legs, dict) else legs):
            if leg.get("changed") and float(leg.get("new_qty", 0) or 0) > 0:
                contract_covered(leg.get("new_contract"), key, plan.get("execution_day"))
    if signal.get("option_monthly_reset_due") or signal.get("option_monthly_reset_preview"):
        covered(signal.get("option_monthly_reset_execution_date"), "monthly maintenance")
    if signal.get("option_monthly_reset_due") or signal.get("put_monthly_reset_preview"):
        covered(signal.get("put_monthly_reset_execution_date"), "Put monthly maintenance")
    if signal.get("roll_confirmed") or signal.get("core_target") != signal.get("core_current"):
        covered(signal.get("roll_execution_date"), "future roll execution")


def _validate_market_stamp(label: str, value: str, clock: datetime) -> date:
    cleaned = str(value).strip()
    try:
        stamp_day = (
            datetime.strptime(cleaned, "%Y%m%d").date()
            if re.fullmatch(r"[0-9]{8}", cleaned)
            else date.fromisoformat(cleaned)
        )
    except ValueError as exc:
        raise RuntimeError(f"{label}缺少可验证的行情日期") from exc
    expected = _latest_completed_exchange_day(clock)
    if stamp_day > clock.date():
        raise RuntimeError(f"{label}行情日期 {stamp_day} 晚于北京时间 {clock.date()}")
    if stamp_day < expected:
        raise RuntimeError(
            f"{label}行情已过期：最新 {stamp_day}，至少应覆盖 {expected}；暂停生成信号"
        )
    return stamp_day


def _validate_chain_stamp_matches(
    label: str,
    stamp: dict[str, str],
    reference_day: date,
    clock: datetime,
) -> date:
    clock = _iv_observation_clock(clock)
    chain_day = _validate_market_stamp(label, stamp.get("date", ""), clock)
    if chain_day != reference_day:
        raise RuntimeError(
            f"{label}与参考行情日期不一致：{chain_day} != {reference_day}"
        )
    if reference_day >= sse_identity.EFFECTIVE_SIGNAL_DATE:
        raw_time = str(stamp.get("time", ""))
        if not re.fullmatch(r"[0-9]{6}", raw_time):
            raise RuntimeError(f"{label}行情时间格式无效")
        try:
            observed = _iv_monitor_stamp(reference_day, stamp.get("date"), raw_time, label)
        except ValueError as exc:
            raise RuntimeError(f"{label}行情时间无效") from exc
        if observed.time() < time(9, 15):
            raise RuntimeError(f"{label}行情时间早于09:15，不能作为有效盘中行情")
        now = clock.astimezone(BEIJING) if clock.tzinfo else clock.replace(tzinfo=BEIJING)
        if observed > now:
            raise RuntimeError(f"{label}行情时间晚于当前运行时间")
    return chain_day


def _require_intraday_bridge_source_day(
    label: str,
    source_day: Any,
    market_date: date,
    enabled: bool,
) -> None:
    if not enabled:
        return
    try:
        parsed = (
            source_day
            if isinstance(source_day, date) and not isinstance(source_day, datetime)
            else date.fromisoformat(str(source_day)[:10])
        )
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{label}缺少{market_date}当日可验证行情日期") from exc
    if parsed != market_date:
        raise RuntimeError(
            f"{label}桥接行情日期为 {parsed}，必须等于当日 {market_date}；暂停新增信号"
        )


def _next_unverified_session_bridge_allowed(
    product: str,
    market_date: date,
    clock: datetime,
    mode: str,
) -> bool:
    verified_day = LIVE_CONTINUATION_ANCHOR[product]["last_verified_day"]
    next_day = _roll_forward_exchange_day(verified_day + timedelta(days=1))
    phase = _market_phase(clock)
    if mode == "intraday":
        allowed_phases = {"集合竞价", "盘中", "午间休市", "收盘后"}
    else:
        allowed_phases = {"收盘后"}
    expected_completed_day = _latest_completed_exchange_day(clock)
    same_session = market_date == clock.date() and phase in allowed_phases
    completed_session_replay = (
        market_date < clock.date() and expected_completed_day == market_date
    )
    return (
        market_date == next_day
        and (same_session or completed_session_replay)
        and expected_completed_day in {verified_day, market_date}
    )


def _validate_signal_market_date(
    product: str,
    market_date: date,
    clock: datetime,
    mode: str = "close",
) -> bool:
    if market_date > clock.date():
        raise RuntimeError(
            f"{product} 行情日期 {market_date} 晚于北京时间 {clock.date()}"
        )
    expected = _latest_completed_exchange_day(clock)
    if market_date < expected:
        raise RuntimeError(
            f"{product} 行情已过期：最新 {market_date}，至少应覆盖最近已完成交易日 "
            f"{expected}；暂停新增信号"
        )
    verified_day = LIVE_CONTINUATION_ANCHOR[product]["last_verified_day"]
    if market_date > verified_day:
        if _next_unverified_session_bridge_allowed(
            product, market_date, clock, mode
        ):
            return True
        raise RuntimeError(
            f"{product} 审计账本仅逐腿核验至 {verified_day}，尚未可靠重放 "
            f"{market_date} 的期货、Put及Call状态；暂停新增信号"
        )
    return False


def _apply_next_unverified_session_anchor(
    product: str,
    live: dict[str, Any],
    *, next_session: bool = True,
) -> dict[str, Any]:
    anchor = LIVE_CONTINUATION_ANCHOR[product]
    result = dict(live)
    # Momentum and grid close signals execute at the next session open.  During
    # the first unverified session the current position is therefore the
    # audited close target, not the position that existed before that close.
    result["momentum_current_weight"] = float(
        anchor.get("verified_next_momentum_weight", anchor["verified_momentum_weight"])
        if next_session else anchor["verified_momentum_weight"]
    )
    result["momentum_current_source_date"] = anchor["last_verified_day"]
    result["grid_current_units"] = float(
        anchor.get("verified_next_grid_units", anchor["verified_grid_units"])
        if next_session else anchor["verified_grid_units"]
    )
    result["state_anchor_day"] = anchor["last_verified_day"]
    if product == "IC":
        result["v13_current_core_put_delta"] = float(
            anchor["verified_core_put_delta"]
        )
        result["v13_current_momentum_put_delta"] = float(
            anchor["verified_momentum_put_delta"]
        )
        result["v13_current_put_delta"] = float(
            anchor["verified_total_put_delta"]
        )
        result["current_core_put_driver"] = anchor["verified_core_put_driver"]
        result["current_momentum_put_driver"] = anchor[
            "verified_momentum_put_driver"
        ]
    else:
        result["v13_current_parent_puts"] = int(anchor["verified_parent_puts"])
        result["v13_current_put_qty_normalized"] = float(
            anchor["verified_core_put_qty_normalized"]
        )
        result["v13_current_core_put_qty_normalized"] = float(
            anchor["verified_core_put_qty_normalized"]
        )
        result["v13_current_momentum_put_qty_normalized"] = float(
            anchor["verified_momentum_put_qty_normalized"]
        )
        result["v13_current_total_put_qty_normalized"] = float(
            anchor["verified_total_put_qty_normalized"]
        )
    return result


def _validated_signal_state_anchor_day(
    product: str,
    live: dict[str, Any],
    bridge_from_anchor: bool,
) -> date | None:
    value = live.get("state_anchor_day")
    if isinstance(value, pd.Timestamp):
        value = value.date()
    elif value is not None and not isinstance(value, date):
        value = date.fromisoformat(str(value)[:10])
    if not bridge_from_anchor:
        return value
    expected = LIVE_CONTINUATION_ANCHOR[product]["last_verified_day"]
    if value != expected:
        raise RuntimeError(
            f"{product}账本桥接状态锚点不一致：期望 {expected}，实际 {value}"
        )
    return value


def _daily_grid_target(product: str, live: dict[str, Any]) -> float:
    state = float(live["grid_current_units"])
    signal_day = live.get("market_date", live.get("history_date", GRID_POLICY_EFFECTIVE_DATE))
    signal_day = pd.Timestamp(signal_day).date()
    rule = grid_rule(product, signal_day)
    if live["score"] <= rule["entry"]:
        return rule["units"]
    if live["score"] >= rule["exit"]:
        return 0.0
    return min(state, rule["units"])


IV_MONITOR_MAX_DELAY_SECONDS = 20 * 60


def _iv_monitor_stamp(day, source_day, source_time, label):
    """Parse timestamps emitted by the SSE/CFFEX adapters, without inventing one."""
    expected = pd.Timestamp(day).date()
    try:
        actual = pd.Timestamp(source_day).date() if source_day is not None else None
    except (TypeError, ValueError):
        actual = None
    if actual != expected or source_time is None:
        raise ValueError(f"{label}缺少与信号日一致的有效行情时间")
    raw = str(source_time).strip()
    stamp = None
    for fmt in ("%Y%m%d %H%M%S", "%Y-%m-%d %H%M%S", "%Y-%m-%d %H:%M:%S", "%H:%M:%S", "%H%M%S"):
        try:
            parsed = datetime.strptime(raw, fmt)
            if fmt in ("%H:%M:%S", "%H%M%S"):
                parsed = parsed.replace(year=expected.year, month=expected.month, day=expected.day)
            stamp = parsed.replace(tzinfo=BEIJING)
            break
        except ValueError:
            continue
    if stamp is None or stamp.date() != expected:
        raise ValueError(f"{label}行情时间格式或日期无效")
    return stamp


def _validate_iv_monitor_times(day, option_stamp, spot_stamp, clock, close_confirmed):
    """Monitoring-only freshness contract; exchange quotes may be delayed 20 min."""
    now = clock.replace(tzinfo=BEIJING) if clock.tzinfo is None else clock.astimezone(BEIJING)
    if not close_confirmed and (now.date() != pd.Timestamp(day).date() or now.hour >= 15):
        raise ValueError("采集校验时刻已越过信号盘中时段，IV监测需要重新取数")
    for label, stamp in (("期权", option_stamp), ("标的", spot_stamp)):
        if stamp > now:
            raise ValueError(f"{label}报价时间晚于当前运行时间")
    reference = now
    if close_confirmed:
        # Historical/end-of-day quotes are evaluated against that session close,
        # not against the evening report's wall clock. CFFEX archive stamps 15:15.
        end = datetime.combine(pd.Timestamp(day).date(), datetime.min.time()).replace(
            hour=15, minute=15, tzinfo=BEIJING
        )
        reference = min(now, end)
    def active_seconds(start, end):
        elapsed = (end - start).total_seconds()
        if not close_confirmed and start.date() == end.date():
            lunch_start = end.replace(hour=11, minute=30, second=0, microsecond=0)
            lunch_end = end.replace(hour=13, minute=0, second=0, microsecond=0)
            elapsed -= max(0.0, (min(end, lunch_end) - max(start, lunch_start)).total_seconds())
        return elapsed
    for label, stamp in (("期权", option_stamp), ("标的", spot_stamp)):
        delay = active_seconds(stamp, reference)
        if delay < 0 or delay > IV_MONITOR_MAX_DELAY_SECONDS:
            raise ValueError(f"{label}报价超出IV监测20分钟时间容忍范围")
    if active_seconds(min(option_stamp, spot_stamp), max(option_stamp, spot_stamp)) > IV_MONITOR_MAX_DELAY_SECONDS:
        raise ValueError("期权与标的报价相差超过IV监测20分钟容忍范围")


def build_iv_warning(product, signal, live, quotes, clock, *, collection_started=None):
    """Display-only IV monitor; keep the 95% reference used by the IM scans."""
    clock = _iv_observation_clock(clock, collection_started)
    day = signal["market_date"]
    if product == "IC":
        evidence = signal.get("iv_monitor_evidence")
        contract = (evidence.get("contract") if isinstance(evidence, dict)
                    else signal.get("put_current_contract")) or ""
        match = re.fullmatch(r"510500P([0-9]{2})([0-9]{2})M([0-9]{5})", contract)
        iv = None
        reason = ""
        source = evidence.get("source", "IC持仓Put证据不完整") if isinstance(evidence, dict) else "上交所510500当日持仓Put报价反解IV"
        quote_time = evidence.get("quote_time") if isinstance(evidence, dict) else signal.get("sse_time")
        strike, expiry = None, None
        try:
            if not match:
                raise ValueError("IC持仓Put合约格式无效")
            expiry = _fourth_wednesday(2000 + int(match.group(1)), int(match.group(2)))
            strike = float(match.group(3))/1000.
            if evidence is not None:
                if not isinstance(evidence, dict):
                    raise ValueError("IC监测证据格式无效")
                option_price = float(evidence["option_price"])
                if (not math.isclose(float(evidence["strike"]), strike, abs_tol=1e-9)
                        or put_execution.as_day(evidence["expiry"]) != expiry
                        or evidence["contract_unit"] != 10000
                        or not evidence["security_id"] or not isinstance(evidence["source"], str)
                        or not evidence["source"].strip()):
                    raise ValueError("IC监测价格与合约主数据未绑定")
                source_day = evidence["quote_date"]
            else:
                option_price = float(signal.get("iv_monitor_option_price"))
                source_day = day
            if not math.isfinite(option_price) or option_price <= 0:
                raise ValueError("IC持仓Put缺少有限正价，无法反解IV")
            option_stamp = _iv_monitor_stamp(day, source_day, quote_time, "IC期权")
            spot_stamp = _iv_monitor_stamp(day, signal.get("etf_quote_date"), signal.get("etf_quote_time"), "510500ETF")
            _validate_iv_monitor_times(day, option_stamp, spot_stamp, clock, signal.get("close_confirmed") is True)
            if expiry <= day:
                raise ValueError("IC监测Put已到期，不能反解正期限IV")
            iv = _implied_volatility("P", option_price, signal["etf_price"],
                                     strike, _gov10y_for_day("IC", day),
                                     float(FROZEN["IC"]["dividend"]), (expiry-day).days/365.)
        except (ValueError, RuntimeError, KeyError, TypeError, OverflowError) as exc:
            reason = str(exc)
        result = im_put_policy.iv_warning(
            iv, source=source,
            market_date=day, snapshot_time=quote_time, contract=contract, reason=reason,
        )
        result.update(validation_clock=clock.isoformat(), reference_strike=strike,
                      expiry=str(expiry) if expiry else None,
                      contract_unit=evidence.get("contract_unit") if isinstance(evidence, dict) else 10000)
        return result
    source = str(quotes.attrs.get("source", "未知"))
    contract = ""
    try:
        source_day = quotes.attrs.get("source_date")
        if str(source_day)[:10] != str(day)[:10]:
            raise ValueError("MO报价日期与信号日不一致")
        expiry = _independent_im_put_target_expiry(quotes, day)
        listed = _listed_mo_enriched(quotes, "P", day)
        month = listed[listed.expiry.eq(expiry)].copy()
        target = im_put_policy.IV_REFERENCE_MONEYNESS * float(signal["put_reference_price"])
        month["error"] = (month.strike - target).abs()
        chosen = month.sort_values(["error", "instrument"]).iloc[0]
        contract = str(chosen.instrument)
        row = _quote_row(quotes, contract)
        if row is None or not math.isfinite(float(row["lastprice"])) or float(row["lastprice"]) <= 0:
            raise ValueError("95%参考Put缺少当日有效价格；未跳选其他合约")
        option_stamp = _iv_monitor_stamp(day, source_day, row.get("source_time"), "MO期权")
        spot_stamp = _iv_monitor_stamp(day, live.get("live_price_source_date"), live.get("live_price_source_time"), "中证1000指数")
        _validate_iv_monitor_times(day, option_stamp, spot_stamp, clock, signal.get("close_confirmed") is True)
        iv = _implied_volatility("P", float(row["lastprice"]), float(live["price"]),
                                 float(chosen.strike), _gov10y_for_day("IM", day),
                                 float(FROZEN["IM"]["dividend"]), (expiry-day).days/365.0)
        pricing_basis = str(row.get("pricing_basis", "source_last_quote"))
        pricing_note = "；零成交量，当日结算价估算IV，非成交报价" if pricing_basis == "official_settlement_estimate_zero_volume" else ""
        if pricing_basis == "live_bid_ask_mid_estimate_zero_volume":
            pricing_note = "；零成交量，当日双边中价估算IV，非成交报价"
        result = im_put_policy.iv_warning(iv, source=source+"；约3个月95%固定参考Put反解（交易目标102%）"+pricing_note,
                                         market_date=day, snapshot_time=row.get("source_time"), contract=contract)
        result.update(reference_moneyness=0.95, reference_strike=float(chosen.strike),
                      option_price=float(row["lastprice"]), spot=float(live["price"]), expiry=str(expiry),
                      pricing_basis=pricing_basis, validation_clock=clock.isoformat())
        return result
    except (ValueError, RuntimeError, KeyError, IndexError, TypeError) as exc:
        result = im_put_policy.iv_warning(None, source=source, market_date=day,
                                         snapshot_time=None, contract=contract, reason=str(exc))
        result["validation_clock"] = clock.isoformat()
        return result


def _v14_target_month(execution_day: date, offset: int = 1) -> tuple[int, int]:
    return _month_after(execution_day.year, execution_day.month, offset)


def _v14_ic_short_put_candidate(
    signal: dict[str, Any], *, roll_from_expiry: date | None = None
) -> dict[str, Any]:
    if (_HISTORICAL_REPLAY_DAY.get() is not None
            and signal_evidence.current_reader.get() is None):
        return {"tradable": False, "reason": "historical_candidate_chain_unavailable"}
    execution_day = signal["next_trade_date"]
    if not isinstance(execution_day, date):
        execution_day = date.fromisoformat(str(execution_day)[:10])
    if roll_from_expiry is None:
        year, month = _v14_target_month(execution_day)
    else:
        year, month = _month_after(roll_from_expiry.year, roll_from_expiry.month)
    expiry_month = f"{year:04d}{month:02d}"
    expiry = _fourth_wednesday(year, month)
    _require_official_exchange_calendar(expiry, "new IC short Put expiry")
    try:
        chain, stamp = _fetch_510500_chain_for_day(expiry_month[2:], signal["market_date"])
    except RuntimeError as exc:
        if "证券代码列表" in str(exc) or "有效510500 Put月份" in str(exc):
            return {"tradable": False, "reason": "target_m1_not_listed", "month": expiry_month}
        raise
    _validate_chain_stamp_matches("v1.4 IC卖Put候选", stamp, signal["market_date"], _now_beijing())
    puts = chain[
        chain.contract.str.contains(rf"510500P{expiry_month[2:]}M", regex=True)
        & chain["last"].gt(0)
    ].copy()
    if puts.empty:
        return {"tradable": False, "reason": "target_m1_no_valid_quote", "month": expiry_month}
    etf = float(signal["etf_price"])
    puts["distance"] = (puts.strike - 0.95 * etf).abs()
    selected = puts.sort_values(["distance", "contract"]).iloc[0]
    _require_selected_510500_quote_time(
        selected, _now_beijing(), signal["market_date"], source=stamp.get("source")
    )
    years = max((expiry - signal["market_date"]).days, 1) / 365.0
    premium = float(selected["last"])
    iv = _implied_volatility(
        "P", premium, etf, float(selected.strike),
        _gov10y_for_day("IC", signal["market_date"]),
        float(FROZEN["IC"]["dividend"]), years,
    )
    if iv is None:
        return {"tradable": False, "reason": "iv_unavailable"}
    # IC fixed core is 0.5x.  The approved fix3 sizing scales that core
    # notional by decision-known option Delta so the initial total short-Put
    # Delta is 0.5 per 0.5x core sleeve (about 0.25 per 1x IC), rather
    # than retaining the old q1-notional size.
    abs_delta = abs(_bs_price_delta(
        "P", etf, float(selected.strike), _gov10y_for_day("IC", signal["market_date"]),
        float(FROZEN["IC"]["dividend"]), float(iv), years,
    )[1])
    if not math.isfinite(abs_delta) or abs_delta <= 0.0:
        return {"tradable": False, "reason": "candidate_delta_unavailable"}
    q1_notional = 0.5 * float(signal["future_last"]) * 200.0 / (etf * 10_000.0)
    qty = q1_notional * 0.50 / abs_delta
    return {
        "tradable": True,
        "reason": "ok",
        "contract": str(selected.contract),
        "security_id": _ic_put_selected_security_id(selected),
        "expiry": expiry,
        "strike": float(selected.strike),
        "premium": premium,
        "iv": iv,
        "qty_normalized": qty,
        "quantity_rule": "q_delta05_continuous_research",
        "decision_known_entry_abs_delta": abs_delta,
        "quote_date": stamp.get("date"),
        "quote_time": (pd.Timestamp(selected["source_stamp"]).strftime("%H%M%S")
                       if "source_stamp" in selected.index else stamp.get("time")),
        "quote_source": stamp.get("source"),
    }


def _v14_im_short_put_candidate(
    signal: dict[str, Any], quotes: pd.DataFrame, *, roll_from_expiry: date | None = None
) -> dict[str, Any]:
    execution_day = signal["next_trade_date"]
    if not isinstance(execution_day, date):
        execution_day = date.fromisoformat(str(execution_day)[:10])
    if roll_from_expiry is None:
        year, month = _v14_target_month(execution_day)
    else:
        year, month = _month_after(roll_from_expiry.year, roll_from_expiry.month)
    expiry = _third_friday(year, month)
    _require_official_exchange_calendar(expiry, "new IM short Put expiry")
    listed = _listed_mo_enriched(quotes, "P", signal["market_date"])
    month = listed[listed.expiry.eq(expiry)].copy()
    if month.empty:
        return {"tradable": False, "reason": "target_m1_not_listed", "expiry": expiry}
    spot = float(signal["index_price"])
    month["distance"] = (month.strike - 0.95 * spot).abs()
    contract = str(month.sort_values(["distance", "instrument"]).iloc[0].instrument)
    row = _quote_row(quotes, contract)
    if row is None:
        return {"tradable": False, "reason": "target_m1_no_quote", "contract": contract, "expiry": expiry}
    premium = float(row["lastprice"])
    # A dated positive quote is actionable under the user's market-maker
    # paper-fill assumption; recorded prints/OI are not admission gates.
    tradable = math.isfinite(premium) and premium > 0
    if signal["market_date"] < v14_policy.REPEAT_ROLL_EFFECTIVE_SIGNAL_DATE:
        # Reproducing a pre-fix5 signal must retain its original quote gate.
        tradable = tradable and float(row.get("volume", 0.0)) > 0 and float(row.get("position", 0.0)) > 0
    strike = float(month[month.instrument.eq(contract)].iloc[0].strike)
    years = max((expiry - signal["market_date"]).days, 1) / 365.0
    iv = _implied_volatility(
        "P", premium, spot, strike,
        _gov10y_for_day("IM", signal["market_date"]),
        float(FROZEN["IM"]["dividend"]), years,
    )
    return {
        "tradable": bool(tradable and iv is not None),
        "reason": "ok" if tradable and iv is not None else "untradable_or_iv_unavailable",
        "contract": contract,
        "expiry": expiry,
        "strike": strike,
        "premium": premium,
        "iv": iv,
        "qty_normalized": 1.5,
        "quantity_rule": "q3_delta05_continuous_research",
        "pricing_basis": str(row.get("pricing_basis", "source_last_quote")),
    }


def _v14_option_mark(product: str, signal: dict[str, Any], quotes: pd.DataFrame | None) -> tuple[float | None, float | None]:
    if product == "IC":
        mark = signal.get("iv_monitor_option_price")
        if signal.get("put_current_core_qty") is not None:
            if float(signal["put_current_core_qty"]) <= 0:
                mark = None
            else:
                core = signal.get("v14_core_put_current_contract") or signal.get("put_current_contract")
                evidence = signal.get("iv_monitor_evidence")
                if isinstance(evidence, dict):
                    mark = (evidence.get("option_price")
                            if evidence.get("sleeve") == "core" and evidence.get("contract") == core else None)
                elif signal.get("put_current_contract") != core:
                    mark = None
        target = (
            signal.get("v14_selected_core_entry_premium")
            if signal.get("option_monthly_reset_due")
            and signal.get("close_confirmed")
            and int(signal.get("put_target_core_qty", 0)) > 0
            else None
        )
        return mark, target
    current_contract = signal.get("core_put_current_contract")
    target_contract = signal.get("core_put_target_contract")
    current_row = _quote_row(quotes, current_contract) if quotes is not None and current_contract else None
    target_row = _quote_row(quotes, target_contract) if quotes is not None and target_contract else None
    mark = float(current_row["lastprice"]) if current_row is not None else None
    target = (
        float(target_row["lastprice"])
        if signal.get("option_monthly_reset_due") and signal.get("close_confirmed") and target_row is not None
        else None
    )
    return mark, target


def _v14_monthly_option_calendar(product: str, market_date: date,
                                 monthly_expiry: date, close_confirmed: bool) -> tuple[bool, bool]:
    preview = _is_pre_expiry_close(market_date, monthly_expiry, close_confirmed)
    due = monthly_expiry == market_date or (
        preview and (product != "IC" or market_date < v14_policy.ORDINARY_PUT_OPEN_EFFECTIVE_SIGNAL_DATE)
    )
    return due, preview and not due


def _v14_ic_core_overlay(signal: dict[str, Any], anchor: dict[str, Any]) -> None:
    """Price the dedicated core independently of the legacy/shared Put field.

    Before the identity migration, ``post_put_contract`` can be the single
    economic core leg; afterward it can hold the independent momentum leg.
    The ordinary-open planner requires explicit v1.4 core identity instead of
    treating that shared field as proof of a dedicated contract.
    """
    contract = anchor.get("v14_core_put_contract")
    if contract:
        if re.fullmatch(r"510500P[0-9]{4}A[0-9]{5}", str(contract)):
            raise RuntimeError("IC adjusted contract master and multiplier unavailable; preserve held A identity")
        day = signal["market_date"]
        replay = _HISTORICAL_REPLAY_DAY.get()
        if replay is not None:
            chain, stamp = fetch_sse_existing_put_historical_quote(str(contract), str(anchor["v14_core_put_security_id"]), replay)
        else:
            match = re.search(r"P(\d{4})", str(contract))
            if not match:
                raise RuntimeError("IC独立核心Put合约格式错误")
            chain, stamp = _fetch_510500_chain_for_day(match.group(1), day)
        _validate_chain_stamp_matches("IC独立核心Put", stamp, day, _now_beijing())
        row = _quote_row(chain, str(contract), day, quote_source=stamp.get("source"))
        if row is None or not math.isfinite(float(row["last"])) or float(row["last"]) <= 0:
            raise RuntimeError("IC独立核心Put缺少有效当日报价")
        _require_held_ic_put_identity(str(contract), anchor.get("v14_core_put_security_id"), row, day)
        signal["iv_monitor_option_price"] = float(row["last"])
        signal["v14_core_put_current_contract"] = str(contract)
        match = re.fullmatch(r"510500P([0-9]{2})([0-9]{2})M([0-9]{5})", str(contract))
        if not match:
            raise RuntimeError("IC核心Put监测缺少标准合约主数据")
        observed = row.get("source_stamp")
        signal["iv_monitor_evidence"] = dict(
            contract=str(contract), security_id=anchor.get("v14_core_put_security_id"),
            option_price=float(row["last"]), strike=float(row.get("strike", int(match.group(3))/1000.)),
            expiry=_fourth_wednesday(2000+int(match.group(1)), int(match.group(2))),
            contract_unit=10000, source=stamp.get("source"), sleeve="core",
            quote_date=observed.date() if isinstance(observed, datetime) else stamp.get("date"),
            quote_time=observed.strftime("%H%M%S") if isinstance(observed, datetime) else stamp.get("time"))
        signal["put_current_core_qty"] = int(anchor.get("v14_core_put_qty", 0))
        if not signal.get("option_monthly_reset_due"):
            target_delta = float(signal["core_put_target_delta"])
            held_delta = float(anchor.get("verified_core_put_delta", target_delta))
            qty = int(anchor.get("v14_core_put_qty", 0))
            if target_delta == 0.0:
                qty = 0
            elif not math.isclose(target_delta, held_delta, abs_tol=1e-12):
                expiry_match = re.fullmatch(r"510500P([0-9]{2})([0-9]{2})M([0-9]{5})",str(contract))
                if not expiry_match:
                    raise RuntimeError("IC独立核心Put格式无效")
                expiry = _fourth_wednesday(2000+int(expiry_match.group(1)),int(expiry_match.group(2)))
                _require_model_expiry_calendar(expiry, "dedicated IC core Put sizing expiry")
                years = (expiry-day).days/365.0
                spot = float(signal["etf_price"])
                strike = int(expiry_match.group(3))/1000.0
                rate = _gov10y_for_day("IC",day)
                iv = _implied_volatility("P",float(row["last"]),spot,strike,rate,float(FROZEN["IC"]["dividend"]),years)
                if iv is None or years <= 0:
                    raise RuntimeError("IC独立核心Put无法计算有效Delta")
                delta = abs(_bs_price_delta("P",spot,strike,rate,float(FROZEN["IC"]["dividend"]),iv,years)[1])
                if delta <= 1e-8:
                    raise RuntimeError("IC独立核心Put绝对Delta无效")
                equivalent = max(1,round(float(signal["future_last"])*200/(spot*10000)))
                qty = max(1,round(equivalent*target_delta/delta)) if target_delta > 0 else 0
            # The held leg still supplies today's mark, but a zero T+1 core
            # target must not carry its contract identity into the new ledger.
            signal.update(v14_core_put_contract=contract if qty > 0 else None,
                          v14_core_put_security_id=anchor.get("v14_core_put_security_id") if qty > 0 else None,
                          v14_core_put_qty=qty, put_target_core_qty=qty,
                          put_target_total_qty=qty+int(signal.get("put_target_momentum_qty",0)))
    if signal.get("option_monthly_reset_due") and signal.get("close_confirmed"):
        core_qty = int(signal.get("put_target_core_qty", 0))
        signal.update(
            v14_core_put_contract=signal.get("put_target_contract") if core_qty > 0 else None,
            v14_core_put_security_id=signal.get("put_target_security_id") if core_qty > 0 else None,
            v14_core_put_qty=core_qty,
        )


def _v14_prepare_lifecycle_evidence(product: str, signal: dict[str, Any], anchor: dict[str, Any], quotes: pd.DataFrame | None) -> None:
    """Describe model-signal scope without treating broker activity as an input."""
    route = anchor.get("v14_route_state", "future")
    signal["v14_signal_scope"] = "research_model_signal_only"
    signal["v14_account_execution_status"] = "not_observed_out_of_scope"
    if route == "short_put":
        expiry = anchor.get("v14_short_put_expiry")
        expiry_day = date.fromisoformat(str(expiry)[:10]) if expiry else None
        day = signal.get("market_date")
        day = day if isinstance(day, date) else date.fromisoformat(str(day)[:10])
        if expiry_day is not None and day >= expiry_day:
            signal["v14_lifecycle_evidence_status"] = "waiting_model_settlement_reference"
            signal["v14_lifecycle_evidence_note"] = (
                "发布到期条件分支；研究账本只等待模型结算依据，不等待账户成交、行权或交割回执。"
            )
        else:
            signal["v14_lifecycle_evidence_status"] = "model_short_put_active"
            signal["v14_lifecycle_evidence_note"] = "策略参考持仓；实际交易和账户状态不在信号系统范围内。"
    elif route in {"assigned_etf", "cash_wait", "recovery_future"}:
        signal["v14_lifecycle_evidence_status"] = "model_recovery_route_active"
        signal["v14_lifecycle_evidence_note"] = "模型恢复路径；不表示账户已成交、交割或持有对应仓位。"
    else:
        signal["v14_lifecycle_evidence_status"] = "model_future_route_active"
        signal["v14_lifecycle_evidence_note"] = "策略参考路径；实际执行由用户自行完成。"
    execution_day = anchor.get("v14_profit_execution_day")
    if not anchor.get("v14_profit_pending") or not execution_day or not signal.get("close_confirmed"):
        return
    if str(execution_day)[:10] != str(signal["market_date"])[:10] or signal.get("option_monthly_reset_due"):
        return
    if route != "future":
        return
    day = signal["market_date"]
    trigger_value = anchor.get("v14_profit_trigger_day")
    trigger_day = date.fromisoformat(str(trigger_value)[:10]) if trigger_value else None
    if trigger_day is not None and trigger_day >= v14_policy.PROFIT_OPEN_EFFECTIVE_SIGNAL_DATE:
        if (product == "IC" and int(signal.get("put_target_core_qty", 0)) <= 0) or (
                product == "IM" and float(signal.get("core_put_target_qty_normalized", 0.0)) <= 0):
            return
        old_contract = str(anchor.get("v14_profit_old_contract") or "")
        new_contract = str(anchor.get("v14_profit_reentry_contract") or "")
        planned_qty = float(anchor.get("v14_profit_reentry_qty") or 0.0)
        if not old_contract or not new_contract or planned_qty <= 0:
            raise RuntimeError("3倍兑现T收盘预选计划不完整，禁止冒充次日开盘执行")
        if product == "IC":
            old_open, old_source = fetch_option_dated_open(str(anchor.get("v14_profit_old_security_id") or ""), day)
            new_open, new_source = fetch_option_dated_open(str(anchor.get("v14_profit_reentry_security_id") or ""), day)
            if not all(math.isfinite(value) and value > 0 for value in (old_open, new_open)):
                raise RuntimeError("三倍兑现任一腿缺少执行日正开盘价，禁止回填收盘或昨收")
            signal.update(v14_core_put_contract=new_contract,
                          v14_core_put_security_id=anchor["v14_profit_reentry_security_id"],
                          v14_core_put_qty=int(planned_qty), put_target_core_qty=int(planned_qty),
                          put_target_total_qty=int(planned_qty)+int(signal.get("put_target_momentum_qty", 0)),
                          core_put_action="RESIZE_OR_ROLL", put_action="RESIZE_OR_ROLL")
        else:
            if quotes is None:
                raise RuntimeError("IM 次日开盘兑现缺少 MO 期权链")
            old_row = _quote_row(quotes, old_contract)
            new_row = _quote_row(quotes, new_contract)
            if old_row is None or new_row is None:
                raise RuntimeError("IM 三倍兑现旧/新合约未在执行日挂牌链中同时找到")
            if "openprice" not in old_row or "openprice" not in new_row:
                raise RuntimeError("IM 三倍兑现旧/新合约缺少指定日开盘价，禁止使用收盘价代替")
            try:
                old_open, new_open = float(old_row["openprice"]), float(new_row["openprice"])
            except (TypeError, ValueError) as exc:
                raise RuntimeError("IM 三倍兑现旧/新合约指定日开盘价无效") from exc
            if not all(math.isfinite(value) and value > 0 for value in (old_open, new_open)):
                raise RuntimeError("三倍兑现任一腿缺少执行日正开盘价，禁止回填收盘或昨收")
            old_source = new_source = str(quotes.attrs.get("source", "MO_dated_open"))
            if old_source == "东方财富":
                observed_clock = _now_beijing()
                verify_sina_option_open(old_contract, day, old_open, observed_clock)
                verify_sina_option_open(new_contract, day, new_open, observed_clock)
                old_source = new_source = "东方财富（新浪逐合约开盘价复核）"
            if not math.isclose(float(signal.get("core_put_target_qty_normalized", 0.0)), planned_qty, abs_tol=1e-12):
                raise RuntimeError("IM 次日风险目标量与T收盘预选量不同，禁止伪称同一开盘成交")
            signal.update(core_put_target_contract=new_contract, put_target_contract=new_contract,
                          core_put_action="RESIZE_OR_ROLL", put_action="RESIZE_OR_ROLL")
        signal.update(v14_profit_reentry_entry_premium=new_open,
                      v14_profit_reentry_contract=new_contract,
                      v14_profit_open_executed_contract=new_contract,
                      v14_profit_open_old_contract=old_contract,
                      v14_profit_open_old_qty=float(anchor.get("v14_profit_old_qty") or 0.0),
                      v14_profit_exit_open_price=old_open,
                      v14_profit_open_old_source=old_source,
                      v14_profit_open_new_source=new_source,
                      v14_profit_open_executed_qty=planned_qty,
                      v14_profit_open_price_day=day,
                      v14_profit_reentry_status="confirmed_open_research_price")
        return
    if product == "IC":
        if _HISTORICAL_REPLAY_DAY.get() is not None and not _original_evidence_replay():
            signal["v14_profit_reentry_status"] = "blocked_historical_new_contract_chain_unavailable"
            return
        selected = select_ic_put_for_reset(day, float(signal["etf_price"]),
                                          float(signal["future_last"]), float(signal["core_put_target_delta"]))
        if selected.get("quote") is None:
            signal["v14_profit_reentry_status"] = "blocked_no_core_protection_target"
            return
        _validate_chain_stamp_matches("IC核心3x重建", selected["stamp"], day, _now_beijing())
        premium = float(selected["quote"]["last"])
        if not math.isfinite(premium) or premium <= 0 or selected.get("qty") is None:
            raise RuntimeError("IC核心3x重建缺少有效报价或数量")
        signal.update(v14_profit_reentry_entry_premium=premium,
                      v14_profit_reentry_contract=selected["contract"],
                      v14_core_put_contract=selected["contract"],
                      v14_core_put_security_id=selected["security_id"],
                      v14_core_put_qty=int(selected["qty"]),
                      put_target_core_qty=int(selected["qty"]),
                      put_target_total_qty=int(selected["qty"])+int(signal.get("put_target_momentum_qty",0)),
                      core_put_action="RESIZE_OR_ROLL", put_action="RESIZE_OR_ROLL",
                      v14_profit_reentry_status="confirmed_close_research_price")
        return
    if quotes is None:
        return
    selected = select_im_put_for_reset(quotes, day, float(signal["put_reference_price"]))
    premium = float(selected["lastprice"])
    if not math.isfinite(premium) or premium <= 0 or float(selected.get("volume", 0)) <= 0:
        raise RuntimeError("v1.4核心Put重建缺少有效当日成交价格")
    contract = str(selected["instrument"])
    signal.update(v14_profit_reentry_entry_premium=premium,
                  v14_profit_reentry_contract=contract,
                  core_put_target_contract=contract,
                  put_target_contract=contract,
                  core_put_action="RESIZE_OR_ROLL", put_action="RESIZE_OR_ROLL",
                  v14_profit_reentry_status="confirmed_close_research_price")


def _v14_prepare_profit_open_plan(product: str, signal: dict[str, Any], anchor: dict[str, Any], quotes: pd.DataFrame | None) -> None:
    """Select a new 3x core Put from signal-day closes, never tomorrow's chain."""
    day = signal["market_date"]
    if (day < v14_policy.PROFIT_OPEN_EFFECTIVE_SIGNAL_DATE or not signal.get("close_confirmed")
            or signal.get("option_monthly_reset_due") or anchor.get("v14_route_state") != "future"
            or anchor.get("v14_profit_pending") or not anchor.get("v14_core_put_profit3x_eligible")):
        return
    entry, mark = anchor.get("v14_core_put_entry_premium"), signal.get("v14_core_put_mark")
    if (entry is None or mark is None or not math.isfinite(float(mark))
            or float(mark) < v14_policy.PROFIT_MULTIPLE * float(entry)):
        return
    try:
        if product == "IC":
            if int(signal.get("put_target_core_qty", 0)) <= 0:
                return
            selected = select_ic_put_for_reset(day, float(signal["etf_price"]),
                                               float(signal["future_last"]), float(signal["core_put_target_delta"]))
            if selected.get("quote") is None or selected.get("qty") is None:
                raise RuntimeError("IC T收盘无可用核心Put预选合约或数量")
            _validate_chain_stamp_matches("IC核心3x次日开盘预选", selected["stamp"], day, _now_beijing())
            contract, qty, security_id = selected["contract"], int(selected["qty"]), selected["security_id"]
        else:
            if quotes is None or float(signal.get("core_put_target_qty_normalized", 0.0)) <= 0:
                return
            selected = select_im_put_for_reset(quotes, day, float(signal["put_reference_price"]))
            contract, qty, security_id = str(selected["instrument"]), float(signal["core_put_target_qty_normalized"]), None
        if not contract or qty <= 0 or (product == "IC" and not security_id):
            raise RuntimeError("T收盘预选核心Put身份不完整")
        signal.update(v14_profit_plan_contract=contract, v14_profit_plan_qty=qty,
                      v14_profit_plan_security_id=security_id,
                      v14_profit_reentry_status="t_close_preselected_for_next_open")
    except (SignalTransportError, requests.ConnectionError, requests.Timeout):
        raise
    except Exception as exc:
        signal["v14_profit_reentry_status"] = f"t_close_preselection_unavailable:{type(exc).__name__}:{exc}"


def _v14_ordinary_open_evidence(
    product: str, market_date: date, clock: datetime,
    quote_cache: dict[str, pd.DataFrame] | None = None,
) -> dict[str, Any] | None:
    """Verify yesterday's exact contracts at today's open before projecting holdings."""
    anchor = LIVE_CONTINUATION_ANCHOR[product]
    plan = anchor.get("v14_ordinary_put_pending")
    if not plan:
        return None
    v14_policy.validate_extension(product, anchor)
    execution_day = date.fromisoformat(str(plan["execution_day"])[:10])
    if market_date < execution_day:
        return {"status": "awaiting_execution_day", "plan": plan}
    if market_date > execution_day:
        return {"status": put_execution.RETRY_OPEN_STATUS if market_date >= put_execution.OPEN_EVIDENCE_EFFECTIVE_DATE
                else "closed_missed_execution_day", "plan": plan,
                "reason": f"需对 {execution_day} 执行 historical_replay，保留原计划和原执行日"}
    # A monthly reset is a same-day close event and has priority over a
    # preselected ordinary opening change on that date.
    if market_date == _third_friday(market_date.year, market_date.month):
        return {"status": "closed_monthly_priority", "plan": plan}
    prices: list[dict[str, Any]] = []
    try:
        chain = fetch_cffex_quotes("MO", clock) if product == "IM" else None
        if chain is not None and quote_cache is not None:
            quote_cache["MO"] = chain
        if chain is not None and chain.attrs.get("source_date") != market_date:
            raise RuntimeError("MO开盘报价日期与执行日不一致")
        seen: set[tuple[str, str | None]] = set()
        for leg in plan["legs"].values():
            if not leg.get("changed"):
                continue
            for side in ("old", "new"):
                qty = float(leg[f"{side}_qty"])
                if qty <= 0:
                    continue
                contract = str(leg[f"{side}_contract"])
                security_id = leg.get(f"{side}_security_id")
                key = (contract, security_id)
                if key in seen:
                    continue
                seen.add(key)
                if product == "IC":
                    price, source = fetch_option_dated_open(str(security_id), market_date)
                else:
                    row = _quote_row(chain, contract)
                    if row is None or "openprice" not in row:
                        raise RuntimeError(f"{contract} 缺少指定日 MO openprice 开盘价")
                    price, source = float(row["openprice"]), str(chain.attrs.get("source", "MO"))
                if not math.isfinite(float(price)) or float(price) <= 0:
                    raise RuntimeError(f"{contract} 指定日开盘价非正或无效")
                if product == "IM" and source == "东方财富":
                    verify_sina_option_open(contract, market_date, price, clock)
                    source = "东方财富（新浪逐合约开盘价复核）"
                prices.append({"contract": contract, "security_id": security_id,
                               "openprice": float(price), "source": source,
                               "price_day": market_date})
    except (RuntimeError, ValueError, KeyError, TypeError, requests.RequestException) as exc:
        status = (put_execution.RETRY_OPEN_STATUS if market_date >= put_execution.OPEN_EVIDENCE_EFFECTIVE_DATE
                  else "closed_missing_open_price")
        return {"status": status, "plan": plan,
                "reason": f"{type(exc).__name__}: {exc}"}
    return {"status": "confirmed_open_research_price", "plan": plan, "prices": prices}


def _opening_retry_diagnostic(
    product: str, clock: datetime, market_date: date, live: dict[str, Any],
    events: list[dict[str, Any]], *, original_anchor: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Expose missing original-day evidence without creating replacement plans."""
    pending = [event for event in events if event.get("status") == put_execution.RETRY_OPEN_STATUS]
    anchor = original_anchor if original_anchor is not None else LIVE_CONTINUATION_ANCHOR[product]
    retained = [("ordinary", anchor.get("v14_ordinary_put_pending")),
                ("short_put", anchor.get("v14_short_put_open_pending"))]
    if anchor.get("v14_profit_pending") and anchor.get("v14_profit_execution_day"):
        execution = put_execution.as_day(anchor["v14_profit_execution_day"])
        if execution <= market_date and (execution < market_date or market_date != _third_friday(market_date.year, market_date.month)):
            retained.append(("profit3x", put_execution.profit_plan(product, anchor, execution)))
    def fingerprint(plan: dict[str, Any]) -> str:
        return json.dumps(plan, sort_keys=True, default=str)
    seen = {fingerprint(event["plan"]) for event in pending}
    for kind, plan in retained:
        if (isinstance(plan, dict) and put_execution.as_day(plan["execution_day"]) <= market_date
                and fingerprint(plan) not in seen):
            pending.append(dict(kind=kind, plan=plan, status=put_execution.RETRY_OPEN_STATUS,
                                reason="原计划保留；完整组合开盘证据尚未全部确认"))
            seen.add(fingerprint(plan))
    plans = [json.loads(json.dumps(event["plan"], default=str)) for event in pending]
    days = sorted({str(plan["execution_day"])[:10] for plan in plans})
    reason = "原执行日开盘证据尚未确认，Put腿待确认；保留原计划。"
    if days:
        reason += "执行日：" + "、".join(days) + "。"
        missed = [day for day in days if date.fromisoformat(day) < market_date]
        reason += ("需对 " + "、".join(missed) + " 执行 historical_replay。" if missed
                   else "请等待原执行日开盘数据后重试；若已跨日，须对原执行日执行 historical_replay。")
    source = {**live, "market_date": market_date}
    diagnostic = make_diagnostic_signal(product, clock, reason, source_signal=source,
                                        status="awaiting_opening_evidence")
    diagnostic.update(retry_original_plans=plans, retry_execution_days=days,
                      retry_evidence_failures=[str(event.get("reason", "")) for event in pending])
    return diagnostic


def _v14_ic_ordinary_core_target(signal: dict[str, Any]) -> tuple[str | None, str | None, float]:
    """Resolve the independent IC core identity, including its first opening."""
    qty = float(signal.get("put_target_core_qty", 0))
    if qty <= 0:
        return None, None, qty
    contract = signal.get("v14_core_put_contract") or signal.get("put_target_contract")
    security_id = signal.get("v14_core_put_security_id") or signal.get("put_target_security_id")
    return contract, security_id, qty


def _v14_schedule_ordinary_put(product: str, signal: dict[str, Any], anchor: dict[str, Any],
                               opening: dict[str, Any] | None) -> None:
    """Persist an exact T-close plan; it is not a paper execution yet."""
    prior = anchor.get("v14_ordinary_put_pending")
    if opening is not None:
        signal["v14_ordinary_put_open_status"] = opening["status"]
        signal["v14_ordinary_put_open_plan"] = opening["plan"]
        if opening.get("prices") is not None:
            signal["v14_ordinary_put_open_prices"] = opening["prices"]
        if opening.get("reason"):
            signal["v14_ordinary_put_open_reason"] = opening["reason"]
    signal["v14_ordinary_put_pending"] = None
    # The public builder returns an opening diagnostic before this point.
    # Retain this guard for direct helper callers; it cannot confirm an open
    # or create a replacement plan when the original evidence is unresolved.
    if prior and opening and opening["status"] == put_execution.RETRY_OPEN_STATUS:
        signal.update(v14_ordinary_put_pending=prior, v14_action="HOLD_FAIL_CLOSED",
                      v14_action_reason="unresolved opening evidence; retry original execution day")
        return
    day = signal["market_date"]
    if (day < v14_policy.ORDINARY_PUT_OPEN_EFFECTIVE_SIGNAL_DATE or not signal.get("close_confirmed")
            or signal.get("option_monthly_reset_due")
            or (signal.get("v14_action") == "HOLD_FAIL_CLOSED" and not signal.get("v14_profit_pending"))):
        return
    if prior and opening and opening["status"] == "awaiting_execution_day":
        signal["v14_ordinary_put_pending"] = prior
        return
    if product == "IC":
        held = _ic_current_quantity_breakdown(anchor)
        if int(anchor.get("v14_core_put_qty", 0)) != held["core"]:
            raise RuntimeError("IC账本核心Put数量与独立持仓明细不一致，禁止生成开盘换仓计划")
        if held["core"] > 0 and (not anchor.get("v14_core_put_contract")
                                  or not anchor.get("v14_core_put_security_id")):
            raise RuntimeError("IC账本核心Put有持仓但缺少独立合约身份，禁止生成开盘换仓计划")
        if held["momentum"] > 0 and (not anchor.get("post_put_contract")
                                      or not anchor.get("post_put_security_id")):
            raise RuntimeError("IC账本动量Put有持仓但缺少合约身份，禁止生成开盘换仓计划")
        new_core_contract, new_core_security_id, new_core_qty = _v14_ic_ordinary_core_target(signal)
        core = dict(old_contract=anchor.get("v14_core_put_contract"),
                    old_security_id=anchor.get("v14_core_put_security_id"),
                    old_qty=float(held["core"]),
                    new_contract=new_core_contract,
                    new_security_id=new_core_security_id,
                    new_qty=new_core_qty)
        momentum = dict(old_contract=anchor.get("post_put_contract") if held["momentum"] > 0 else None,
                        old_security_id=anchor.get("post_put_security_id") if held["momentum"] > 0 else None,
                        old_qty=float(held["momentum"]),
                        new_contract=signal.get("put_target_contract") if float(signal.get("put_target_momentum_qty", 0)) > 0 else None,
                        new_security_id=signal.get("put_target_security_id") if float(signal.get("put_target_momentum_qty", 0)) > 0 else None,
                        new_qty=float(signal.get("put_target_momentum_qty", 0)))
    else:
        core = dict(old_contract=anchor.get("post_core_put_contract") if float(anchor.get("verified_core_put_qty_normalized", 0)) > 0 else None,
                    old_security_id=None, old_qty=float(anchor.get("verified_core_put_qty_normalized", 0)),
                    new_contract=signal.get("core_put_target_contract"), new_security_id=None,
                    new_qty=float(signal.get("core_put_target_qty_normalized", 0)))
        momentum = dict(old_contract=anchor.get("post_momentum_put_contract") if float(anchor.get("verified_momentum_put_qty_normalized", 0)) > 0 else None,
                        old_security_id=None, old_qty=float(anchor.get("verified_momentum_put_qty_normalized", 0)),
                        new_contract=signal.get("momentum_put_target_contract"), new_security_id=None,
                        new_qty=float(signal.get("momentum_put_target_qty_normalized", 0)))
    legs = {"core": core, "momentum": momentum}
    profit_core = v14_policy.profit_core_reference(product, anchor, signal)
    if signal.get("v14_route_state") != "future":
        # The route owns the fixed-core switch. Only the independent momentum
        # Put uses an ordinary opening plan while that route is active.
        legs["core"] = dict(old_contract=None, old_security_id=None, old_qty=0.0,
                            new_contract=None, new_security_id=None, new_qty=0.0)
    elif profit_core is not None:
        contract, security_id, qty = profit_core
        legs["core"] = dict(old_contract=contract, old_security_id=security_id, old_qty=qty,
                            new_contract=contract, new_security_id=security_id, new_qty=qty)
    for leg in legs.values():
        leg["changed"] = leg["old_contract"] != leg["new_contract"] or not math.isclose(
            leg["old_qty"], leg["new_qty"], abs_tol=1e-12
        )
    if not any(leg["changed"] for leg in legs.values()):
        return
    plan = {"product": product, "signal_day": day, "execution_day": signal["next_trade_date"], "legs": legs}
    if day >= fear_grid.CLOSE_FALLBACK_EFFECTIVE_DATE and (
        signal.get("signal_generation_timing") == "retrospective_replay" or datetime.now(BEIJING).date() > day
    ):
        plan.update(created_at=datetime.now(BEIJING).isoformat(timespec="seconds"),
                    creation_timing="retrospective_replay",
                    research_scope="retrospective_model_plan")
    if product == "IC":
        core_delta = (anchor["verified_core_put_delta"] if profit_core is not None
                      and signal.get("v14_action") != "EXECUTE_CORE_PUT_PROFIT3X_REENTER"
                      else signal["core_put_target_delta"])
        plan.update(core_delta=float(core_delta),
                    momentum_delta=float(signal["momentum_put_target_delta"]),
                    core_driver=str(signal["core_put_driver"]),
                    momentum_driver=str(signal["momentum_put_driver"]))
    else:
        plan["parent_puts"] = (int(2 * profit_core[2]) if profit_core is not None
                               else int(signal["v13_parent_puts_per_full_core"]))
    signal["v14_ordinary_put_pending"] = plan
    signal["v14_ordinary_put_plan_status"] = "scheduled_t_plus_1_open"


def _refresh_ic_put_text(signal: dict[str, Any], anchor: dict[str, Any] | None = None) -> None:
    """Render final quantities after overlays, routes and opening projections."""
    current_core = signal.get("v14_core_put_current_contract")
    if not current_core and anchor is not None:
        current_core = anchor.get("v14_core_put_contract")
        if (not current_core and put_execution.as_day(anchor["last_verified_day"]) < v14_policy.EFFECTIVE_SIGNAL_DATE):
            current_core = anchor.get("post_put_contract")
    if not current_core and float(signal.get("put_current_momentum_qty") or 0) == 0:
        current_core = signal.get("put_current_contract")
    target_core = signal.get("v14_core_put_contract") or signal.get("put_target_contract")
    def quantity(qty):
        if qty is None:
            return "张数待核验"
        number = float(qty)
        if not math.isfinite(number) or number < 0:
            return "张数待核验"
        return f"{number:g}张"
    def leg(qty, contract):
        text = quantity(qty)
        return text if text in {"0张", "张数待核验"} else f"{text} `{contract or '身份待核验'}`"
    signal["put_current"] = (
        f"核心 {leg(signal.get('put_current_core_qty'), current_core)}；"
        f"动量 {leg(signal.get('put_current_momentum_qty'), signal.get('put_current_contract'))}")
    signal["put_target"] = (
        f"核心 {leg(signal.get('put_target_core_qty'), target_core)}；"
        f"动量 {leg(signal.get('put_target_momentum_qty'), signal.get('put_target_contract'))}；"
        f"合计 {quantity(signal.get('put_target_total_qty'))}")


def _v14_require_held_ic_short_identity(signal: dict[str, Any], anchor: dict[str, Any]) -> None:
    contract = str(anchor["v14_short_put_contract"])
    security_id = anchor.get("v14_short_put_security_id")
    match = re.fullmatch(r"510500P([0-9]{4})M[0-9]{5}", contract)
    if not match:
        raise RuntimeError("IC adjusted contract master and multiplier unavailable; preserve held short identity")
    replay = _HISTORICAL_REPLAY_DAY.get()
    if replay is not None:
        chain, stamp = fetch_sse_existing_put_historical_quote(contract, str(security_id or ""), replay)
    else:
        chain, stamp = _fetch_510500_chain_for_day(match.group(1), signal["market_date"])
    _validate_chain_stamp_matches("IC既有卖Put", stamp, signal["market_date"], _now_beijing())
    row = _quote_row(chain, contract, signal["market_date"], quote_source=stamp.get("source"))
    if row is None:
        raise RuntimeError("IC既有卖Put缺少可验证证券身份的行情")
    _require_held_ic_put_identity(contract, security_id, row, signal["market_date"])


def _apply_v14_live_policy(
    product: str,
    signal: dict[str, Any],
    *,
    mo_quotes: pd.DataFrame | None = None,
) -> dict[str, Any]:
    anchor = LIVE_CONTINUATION_ANCHOR[product]
    put_execution.require_supported_ic_contracts(product, anchor)
    short_identity_required = (product == "IC" and bool(anchor.get("v14_short_put_contract"))
                               and signal["market_date"] >= sse_identity.EFFECTIVE_SIGNAL_DATE)
    short_identity_verified = not short_identity_required
    short_mark_required = v14_policy.short_put_mark_required(product, signal, anchor)
    short_mark_verified = not short_mark_required
    if product == "IC" and float(anchor.get("v14_core_put_qty", 0)) > 0:
        # Bind the requested monitor before quote collection: a failed core
        # overlay cannot silently become the independent momentum Put's IV.
        signal["v14_core_put_current_contract"] = anchor.get("v14_core_put_contract")
        signal["iv_monitor_evidence"] = dict(
            contract=anchor.get("v14_core_put_contract"),
            security_id=anchor.get("v14_core_put_security_id"), sleeve="core")
    try:
        if short_identity_required:
            _v14_require_held_ic_short_identity(signal, anchor)
            short_identity_verified = True
        if product == "IC":
            _v14_ic_core_overlay(signal, anchor)
        _v14_prepare_lifecycle_evidence(product, signal, anchor, mo_quotes)
        mark, target_entry = _v14_option_mark(product, signal, mo_quotes)
        signal["v14_core_put_mark"] = mark
        signal["v14_core_put_target_entry_premium"] = target_entry
        current_short = anchor.get("v14_short_put_contract")
        if current_short:
            # Prepared or reused signal fields are not evidence for this leg.
            for field in ("v14_short_put_mark", "v14_short_put_mark_day", "v14_short_put_mark_contract"):
                signal.pop(field, None)
            if product == "IC":
                security_id = anchor.get("v14_short_put_security_id")
                if security_id:
                    closes = (fetch_option_closes(str(security_id), signal["market_date"])
                              if short_mark_required else fetch_option_closes(str(security_id)))
                    stamp = pd.Timestamp(signal["market_date"])
                    signal["v14_short_put_mark"] = float(closes.loc[stamp]) if stamp in closes.index else None
            else:
                if mo_quotes is None:
                    raise RuntimeError("IM held short Put quote chain unavailable")
                row = _quote_row(mo_quotes, str(current_short), signal["market_date"])
                signal["v14_short_put_mark"] = float(row["lastprice"]) if row is not None else None
            if signal.get("v14_short_put_mark") is not None:
                signal["v14_short_put_mark_day"] = signal["market_date"]
                signal["v14_short_put_mark_contract"] = current_short
            v14_policy.require_short_put_mark(product, signal, anchor, require_binding=True)
            short_mark_verified = True
        # Admission dates and chains are only consumed when the pure policy
        # can enter or roll. Required held/core marks above keep their own
        # failure boundary; an unused M+1 chain cannot disable other sleeves.
        required = v14_policy.short_put_candidate_requirements(product, signal, anchor)
        candidate = {"tradable": False, "reason": required["reason"]}
        roll_candidate = None
        if required["entry"] or required["roll"]:
            if product == "IM" and mo_quotes is None:
                raise RuntimeError("IM v1.4 requires a validated MO chain")
            if required["entry"]:
                candidate = (_v14_ic_short_put_candidate(signal) if product == "IC"
                             else _v14_im_short_put_candidate(signal, mo_quotes))
            if required["roll"]:
                current_expiry = anchor.get("v14_short_put_expiry")
                if current_expiry is None:
                    raise RuntimeError("Held short Put lacks its expiry for replacement selection")
                current_expiry = date.fromisoformat(str(current_expiry)[:10])
                roll_candidate = (
                    _v14_ic_short_put_candidate(signal, roll_from_expiry=current_expiry)
                    if product == "IC" else
                    _v14_im_short_put_candidate(signal, mo_quotes, roll_from_expiry=current_expiry)
                )
        else:
            signal["v14_candidate_data_status"] = "not_required: " + required["reason"]
        projected = v14_policy.apply_policy(
            product, signal, anchor, candidate=candidate, roll_candidate=roll_candidate
        )
        # A new seller route has priority over a new 3x trigger. Only resolve
        # a 3x candidate when the pure policy actually waits for that input;
        # completed or committed lifecycle actions never repeat preselection.
        if (projected.get("v14_action") == "HOLD"
                and projected.get("v14_action_reason") == "profit3x_t_close_preselection_unavailable"):
            _v14_prepare_profit_open_plan(product, signal, anchor, mo_quotes)
            return v14_policy.apply_policy(
                product, signal, anchor, candidate=candidate, roll_candidate=roll_candidate
            )
        return projected
    except (SignalTransportError, requests.ConnectionError, requests.Timeout):
        # Let the existing bounded transport retry repeat required evidence.
        # A failed source must not become a policy decision or a new state.
        raise
    except Exception as exc:
        if not short_identity_verified or not short_mark_verified:
            # No policy projection, even for expiry, may consume an unproved
            # held identity or a mark left in a prepared signal.
            fallback = {k: v for k, v in signal.items() if not k.startswith("v14_")}
            fallback.update(v14_policy.default_extension(product))
            fallback.update({k: v for k, v in anchor.items() if k.startswith("v14_")})
            fallback.update(v14_action="HOLD_FAIL_CLOSED", v14_action_reason=str(exc),
                            v14_candidate_data_status=f"unavailable: {type(exc).__name__}: {exc}")
            if not short_identity_verified:
                fallback["v14_held_put_identity_status"] = "unverified"
            if not short_mark_verified:
                fallback["v14_short_put_mark_status"] = "unverified"
            return fallback
        # Candidate admission is fail-closed; independent lifecycle events
        # keep the action that produced their state/event-id transition.
        fallback = v14_policy.apply_policy(
            product, signal, anchor,
            candidate={"tradable": False}, roll_candidate={"tradable": False},
        )
        fallback["v14_candidate_data_status"] = f"unavailable: {type(exc).__name__}: {exc}"
        completed_lifecycle_actions = {
            "PUBLISH_SHORT_PUT_EXPIRY_BRANCHES", "EXECUTE_CORE_PUT_PROFIT3X_REENTER",
            "SHORT_PUT_EXPIRE_WORTHLESS", "SHORT_PUT_ASSIGNED",
            "ENTER_RECOVERY_FUTURE", "EXIT_RECOVERY_AT_BREAKEVEN",
        }
        if fallback.get("v14_action") not in completed_lifecycle_actions:
            fallback["v14_action"] = "HOLD_FAIL_CLOSED"
            fallback["v14_action_reason"] = f"{type(exc).__name__}: {exc}"
        return fallback


def _v14_committed_open_prices(product: str, plan: dict[str, Any], day: date,
                               clock: datetime, quote_cache: dict[str, pd.DataFrame]) -> list[dict[str, Any]]:
    """Fetch exact dated opening legs, never today's close or a substitute leg."""
    prices = []
    for required in plan["required_quotes"]:
        contract, kind = required["contract"], required.get("kind", "option")
        security = required.get("security_id")
        if kind == "option" and product == "IC":
            price, source = fetch_option_dated_open(str(security), day)
        else:
            key = product if kind == "future" else "MO"
            if key not in quote_cache:
                quote_cache[key] = fetch_cffex_quotes(key, clock)
            chain = quote_cache[key]
            if put_execution.as_day(chain.attrs.get("source_date")) != day:
                raise RuntimeError(f"{contract} opening chain is not dated {day}")
            row = _quote_row(chain, contract)
            if row is None or "openprice" not in row:
                raise RuntimeError(f"{contract} lacks its specified-day openprice")
            price, source = float(row["openprice"]), str(chain.attrs.get("source", ""))
            if key == "MO" and source == "东方财富":
                verify_sina_option_open(contract, day, price, clock)
                source = "东方财富（新浪逐合约开盘价复核）"
        prices.append(dict(contract=contract, security_id=security, kind=kind,
                           price_day=day, openprice=float(price), source=source))
    put_execution.checked_prices(plan, prices, day)
    return prices


def _v14_project_committed_opens(product: str, day: date, clock: datetime,
                                 quote_cache: dict[str, pd.DataFrame]) -> list[dict[str, Any]]:
    with STRATEGY_QUERY_LOCK:
        return _v14_project_committed_opens_locked(product, day, clock, quote_cache)


def _v14_project_committed_opens_locked(product: str, day: date, clock: datetime,
                                        quote_cache: dict[str, pd.DataFrame]) -> list[dict[str, Any]]:
    if not put_execution.active(day):
        return []
    events = []
    anchor = LIVE_CONTINUATION_ANCHOR[product]
    short = anchor.get("v14_short_put_open_pending")
    if short:
        execution = put_execution.as_day(short["execution_day"])
        event = dict(kind="short_put", plan=short, status="awaiting_execution_day")
        if day > execution:
            event["status"] = (put_execution.RETRY_OPEN_STATUS if day >= put_execution.OPEN_EVIDENCE_EFFECTIVE_DATE
                               else "closed_missed_execution_day")
            event["reason"] = (
                f"需对 {execution.isoformat()} 执行 historical_replay；"
                "保留原执行日和计划，不在后续日期补做成交"
            )
        elif day == execution:
            try:
                event.update(status="confirmed_open_research_price",
                             prices=_v14_committed_open_prices(product, short, day, clock, quote_cache))
            except (RuntimeError, ValueError, KeyError, TypeError, requests.RequestException) as exc:
                status = (put_execution.RETRY_OPEN_STATUS if day >= put_execution.OPEN_EVIDENCE_EFFECTIVE_DATE
                          else "closed_missing_open_price")
                event.update(status=status, reason=f"{type(exc).__name__}: {exc}")
        anchor = put_execution.project_short_open(product, anchor, event, day)
        events.append(event)
    if (day >= put_execution.OPEN_EVIDENCE_EFFECTIVE_DATE and anchor.get("v14_profit_pending")
            and anchor.get("v14_profit_execution_day")
            and put_execution.as_day(anchor["v14_profit_execution_day"]) < day):
        execution = put_execution.as_day(anchor["v14_profit_execution_day"])
        original_plan = put_execution.profit_plan(product, anchor, execution)
        if original_plan is not None:
            events.append(dict(kind="profit3x", plan=original_plan, status=put_execution.RETRY_OPEN_STATUS,
                               reason=f"需对 {execution} 执行 historical_replay；保留原计划和原执行日"))
    plan = put_execution.profit_plan(product, anchor, day)
    # Monthly priority is calendar-known, unchanged by this repair.
    if plan and day != _third_friday(day.year, day.month):
        event = dict(kind="profit3x", plan=plan)
        try:
            event.update(status="confirmed_open_research_price",
                         prices=_v14_committed_open_prices(product, plan, day, clock, quote_cache))
            anchor = put_execution.project_profit_open(product, anchor, event, day)
        except (RuntimeError, ValueError, KeyError, TypeError, requests.RequestException) as exc:
            status = (put_execution.RETRY_OPEN_STATUS if day >= put_execution.OPEN_EVIDENCE_EFFECTIVE_DATE
                      else "closed_missing_open_price")
            execution = put_execution.as_day(plan["execution_day"])
            replay = (f"需对 {execution.isoformat()} 执行 historical_replay；"
                      if day > execution else "")
            event.update(status=status, reason=f"{replay}{type(exc).__name__}: {exc}")
        events.append(event)
    LIVE_CONTINUATION_ANCHOR[product] = anchor
    return events


def _original_evidence_replay() -> bool:
    return signal_evidence.current_reader.get() is not None


def build_live_trade_signal(
    product: str, now: datetime | None = None, mode: str = "intraday",
) -> dict[str, Any]:
    clock = _beijing_clock(now or _now_beijing())
    # Select an original-session bundle before calculation. Recursion enters
    # once with the verified reader and its real close acquisition clock.
    # Missing old bundles keep the existing dated historical providers; an
    # existing but incomplete/corrupt bundle never falls back to current data.
    replay_day = _HISTORICAL_REPLAY_DAY.get()
    evidence_root = evidence_adapter.configured_root()
    original_present = False
    if replay_day is not None and evidence_root is not None and not _original_evidence_replay():
        try:
            original_present = evidence_adapter.has_original(evidence_root, product, replay_day)
        except signal_evidence.EvidenceUnavailable as exc:
            result = make_diagnostic_signal(product, clock, str(exc), status="original_evidence_unavailable")
            result["mode"] = mode
            return result
    if original_present:
        with STRATEGY_QUERY_LOCK:
            try:
                reader, replay_clock = evidence_adapter.load_original(
                    _evidence_strategy, evidence_root, product, replay_day)
                with signal_evidence.replay_session(reader):
                    result = build_live_trade_signal(product, replay_clock, mode)
                result["original_evidence"] = {
                    "manifest_sha256": reader.manifest_sha256,
                    "decision_at": reader.decision_at.isoformat(),
                    "acquired_until": reader.closed_at.isoformat(),
                    "replay_runtime": replay_clock.isoformat(),
                    "input_revision": evidence_adapter.INPUT_REVISION,
                    "unrecorded_inputs": deepcopy(reader.missing_inputs),
                    "replay_completeness": signal_evidence.decode(
                        reader.context.get("annotations", {}).get("replay_completeness")),
                }
                integrity = signal_evidence.decode(reader.context.get("annotations", {}).get("signal_capture_integrity"))
                if isinstance(integrity, dict):
                    result["input_evidence_status"] = integrity["status"]
                result["historical_evidence_supplements"] = deepcopy(
                    getattr(reader, "supplemental_evidence", []))
                return result
            except signal_evidence.EvidenceUnavailable as exc:
                result = make_diagnostic_signal(product, clock, str(exc),
                                                status="original_evidence_unavailable")
                result["mode"] = mode
                return result
    with STRATEGY_QUERY_LOCK, runtime_clock(clock), collection_clock(clock):
        # The exchange session ends at 15:00.  The generic snapshot route is
        # deliberately more conservative until 15:30; these are not one gate.
        if mode == "close" and _is_exchange_trading_day(clock.date()) and _market_phase(clock) != "收盘后":
            raise RuntimeError("今日尚未收盘，收盘确认信号尚不可用；盘中研究请查询实时信号")
        original_anchor = LIVE_CONTINUATION_ANCHOR[product]
        context = {"expiries": [], "failures": [], "signal": {}, "future": {}, "anchor": original_anchor}
        token = _SIGNAL_CALENDAR_DIAGNOSTICS.set(context)
        cache_token = _IC_QUOTE_QUERY_CACHE.set({})
        try:
            try:
                result = _build_live_trade_signal(product, clock, mode)
            except CalendarCoverageError as exc:
                result = make_diagnostic_signal(product, clock, str(exc))
            if not result.get("diagnostic_only") and (
                context["expiries"] or context["failures"]
                or result.get("v14_action") == "HOLD_FAIL_CLOSED"
            ):
                result = make_diagnostic_signal(
                    product, clock,
                    ("到期日或执行日尚未经官方日历核验；估值仅作诊断，组合目标未确认。"
                     if context["expiries"] or context["failures"] else
                      str(result.get("v14_action_reason") or result.get("v14_reason")
                          or "Put腿未能完成核验，组合目标未确认。")),
                    source_signal=result,
                    status="calendar_unverified" if context["expiries"] or context["failures"] else "put_fail_closed",
                )
            result["mode"] = mode
            session = signal_evidence.current_session.get()
            if session is not None:
                session.bind_signal(result)
            return result
        finally:
            # Opening confirmation is an in-memory projection for this query.
            # Only the state store may persist a fully validated close signal.
            LIVE_CONTINUATION_ANCHOR[product] = original_anchor
            _IC_QUOTE_QUERY_CACHE.reset(cache_token)
            _SIGNAL_CALENDAR_DIAGNOSTICS.reset(token)


def _build_live_trade_signal(
    product: str,
    now: datetime | None = None,
    mode: str = "intraday",
) -> dict[str, Any]:
    collection_started = time_module.monotonic()
    if mode not in {"intraday", "close"}:
        raise ValueError(f"非法信号模式: {mode}")
    clock = _beijing_clock(now or _now_beijing())
    _require_official_exchange_calendar(clock.date(), f"{product}信号")
    today = clock.date()
    live = live_proxy(product, clock)
    market_date = live.get("history_date", today)
    if isinstance(market_date, pd.Timestamp):
        market_date = market_date.date()
    if not isinstance(market_date, date):
        market_date = date.fromisoformat(str(market_date))
    partial_context = _SIGNAL_CALENDAR_DIAGNOSTICS.get()
    if partial_context is not None:
        # Retain already-computed observations even if a later calendar or
        # futures schedule fails before the full signal dictionary exists.
        partial_context["signal"].update({"market_date": market_date,
            "index_price": live.get("price"), **{key: live[key] for key in
            ("score", "momentum_120", "momentum_score", "momentum_next_weight") if key in live}})
    bridge_from_anchor = _validate_signal_market_date(
        product, market_date, clock, mode
    )
    quote_cache: dict[str, pd.DataFrame] = {}
    opening_anchor = LIVE_CONTINUATION_ANCHOR[product]
    put_execution.require_supported_ic_contracts(product, opening_anchor)
    opening = _v14_ordinary_open_evidence(product, market_date, clock, quote_cache)
    if opening is not None and opening.get("status") == put_execution.RETRY_OPEN_STATUS:
        return _opening_retry_diagnostic(product, clock, market_date, live, [opening], original_anchor=opening_anchor)
    put_execution.require_resolved_opening_evidence(
        {"v14_ordinary_put_open_status": opening["status"] if opening else None}
    )
    if opening is not None and opening["status"] == "confirmed_open_research_price":
        LIVE_CONTINUATION_ANCHOR[product] = v14_policy.project_ordinary_open(
            product, LIVE_CONTINUATION_ANCHOR[product], opening["plan"], opening["prices"]
        )
    opening_events = _v14_project_committed_opens(product, market_date, clock, quote_cache)
    if any(event.get("status") == put_execution.RETRY_OPEN_STATUS for event in opening_events):
        return _opening_retry_diagnostic(product, clock, market_date, live, opening_events, original_anchor=opening_anchor)
    put_execution.require_resolved_opening_evidence({"v14_opening_events": opening_events})
    put_execution.require_due_openings(product, opening_anchor,
        {"v14_ordinary_put_open_status": opening["status"] if opening else None,
         "v14_ordinary_put_open_plan": opening["plan"] if opening else None,
         "v14_opening_events": opening_events}, market_date,
        market_date == _third_friday(market_date.year, market_date.month))
    if bridge_from_anchor:
        live = _apply_next_unverified_session_anchor(product, live)
    elif market_date == LIVE_CONTINUATION_ANCHOR[product]["last_verified_day"]:
        live = _apply_next_unverified_session_anchor(product, live, next_session=False)
    fear_evidence: dict[str, Any] | None = None
    if market_date >= fear_grid.EFFECTIVE_SIGNAL_DATE:
        if not live.get("valuation_provenance"):
            raise RuntimeError(f"{product} 新网格信号缺少已核验估值来源")
        anchor = LIVE_CONTINUATION_ANCHOR[product]
        source_key = ("verified_next_grid_entry_source" if bridge_from_anchor
                      else "verified_grid_entry_source")
        current_source = anchor.get(source_key)
        if current_source is None:
            # The last pre-fix10 grid could only have entered by valuation.
            current_source = fear_grid.source_for_legacy_units(
                float(live["grid_current_units"])
            )
        # A post-close "实时信号" query must meet the same Fear confirmation
        # gate as the close route before it can describe a confirmed target.
        fear_mode = (
            "close" if market_date < today or
            (market_date == today and _market_phase(clock) == "收盘后") else mode
        )
        fear_evidence = _fear_score_evidence(market_date, fear_mode)
        if fear_grid.flexible_source(fear_evidence) and fear_evidence["fear_greed_index"] is None:
            next_units, next_source, grid_reason = float(live["grid_current_units"]), current_source, "fear_unavailable"
        else:
            next_units, next_source, grid_reason = fear_grid.transition(
                product, float(live["grid_current_units"]), current_source,
                float(live["score"]), fear_evidence["fear_greed_index"],
            )
        if _now_beijing().date() >= fear_grid.SOURCE_POLICY_DATE:
            fear_evidence.update(_fear_reference_evidence(market_date))
        live["grid_target_units"] = next_units
        live["grid_entry_source_current"] = current_source
        live["grid_entry_source_target"] = next_source
        live["grid_transition_reason"] = grid_reason
    elif live.get("valuation_provenance"):
        # Continue the persisted valuation grid state without replaying older
        # proxy scores. Historical signals keep their original field contract.
        live["grid_target_units"] = _daily_grid_target(product, live)
    if partial_context is not None and "grid_target_units" in live:
        partial_context["signal"]["grid_target"] = live["grid_target_units"]
    state_anchor_day = _validated_signal_state_anchor_day(
        product, live, bridge_from_anchor
    )
    future_quotes = fetch_cffex_quotes(product, clock)
    future_quote_source = str(future_quotes.attrs.get("source", "未知"))
    future_quote_date = future_quotes.attrs.get("source_date")
    _require_intraday_bridge_source_day(
        f"{product}期货", future_quote_date, market_date, bridge_from_anchor
    )
    calendar_context = _SIGNAL_CALENDAR_DIAGNOSTICS.get()
    if calendar_context is not None:
        try:
            observed_day = pd.Timestamp(future_quote_date).date() if future_quote_date is not None else None
        except (ValueError, TypeError):
            observed_day = None
        quote_rows = []
        if observed_day == market_date:
            for _, row in future_quotes.iterrows():
                contract = str(row.get("instrument", ""))
                price = row.get("lastprice")
                if (re.fullmatch(rf"{product}[0-9]{{4}}", contract)
                        and not isinstance(price, (bool, np.bool_))
                        and price is not None and math.isfinite(float(price)) and float(price) > 0):
                    quote_rows.append({"contract": contract, "lastprice": float(price)})
        calendar_context["future"] = {
            "quote_source": future_quote_source,
            "quote_date": str(future_quote_date) if future_quote_date is not None else None,
            "quote_status": "signal_date_matched" if observed_day == market_date else "unverified_date",
            "quotes": quote_rows,
        }
    # Option maintenance keeps the original monthly reference, independent of futures.
    monthly_future = select_active_future(product, future_quotes, market_date, purpose="maintenance_reference")
    monthly_expiry = _third_friday(*_contract_month(str(monthly_future["instrument"])))
    phase = _market_phase(clock)
    close_confirmed = market_date < today or (
        market_date == today and phase in {"收盘后", "非交易日"}
    )
    option_roll_due, monthly_preview_only = _v14_monthly_option_calendar(
        product, market_date, monthly_expiry, close_confirmed
    )
    option_core_action = "ROLL" if option_roll_due else "HOLD"
    option_reference_contract = str(monthly_future["instrument"])
    if option_roll_due:
        option_reference_contract = _next_listed_future_contract(
            product, future_quotes, monthly_expiry
        )
    option_reference_future = _require_listed_future_quote(
        product, future_quotes, option_reference_contract
    )
    option_reference_expiry = _third_friday(*_contract_month(option_reference_contract))
    ledger_core = str(LIVE_CONTINUATION_ANCHOR[product]["post_core_contract"])
    ledger_core_expiry = _third_friday(*_contract_month(ledger_core))
    calendar_note = _calendar_coverage_note([
        _third_friday(*_contract_month(str(c))) for c in future_quotes.instrument
    ])
    if market_date >= quarter_roll.EFFECTIVE_DATE:
        def covered_session(day):
            _require_official_exchange_calendar(day, "季度换仓日历")
            return _is_exchange_trading_day(day)
        future_plan = quarter_roll.roll_state(
            product, ledger_core,
            future_quotes.attrs.get("listed_instruments", future_quotes.instrument.tolist()),
            market_date, close_confirmed,
            lambda c: _third_friday(*_contract_month(c)), covered_session,
        )
        current_core = future_plan["core_current"]
        target_core = future_plan["core_target"]
        core_action = future_plan["core_action"]
        next_core = future_plan["next_core"]
        active_expiry = ledger_core_expiry
        roll_execution_date = future_plan["roll_execution_date"]
        scheduled_roll_completed = future_plan["roll_confirmed"]
    else:
        # Pre-effective catch-up retains r6 monthly semantics.
        active_expiry = monthly_expiry
        next_core = _next_listed_future_contract(product, future_quotes, monthly_expiry)
        current_core = ledger_core
        target_core = option_reference_contract
        core_action = option_core_action
        roll_execution_date = monthly_expiry if option_roll_due else None
        scheduled_roll_completed = market_date >= ledger_core_expiry
        if core_action == "HOLD" and target_core != current_core:
            raise RuntimeError(f"{product} monthly reference does not match audited ledger")
        future_plan = dict(core_eod_contract=target_core, roll_confirmed=option_roll_due,
                           roll_policy={"tenor": "legacy_monthly_pre_effective"})
    active_future = _require_listed_future_quote(product, future_quotes, target_core)
    spread = quarter_roll.quarter_spread(
        product, future_quotes, market_date, lambda c: _third_friday(*_contract_month(c))
    )
    grid_units, grid_action = _grid_target(product, live)
    close_confirmed = market_date < today or (
        market_date == today and phase in {"收盘后", "非交易日"}
    )
    if mode == "intraday":
        stage = (
            "盘中实时监测，须待T收盘确认"
            if phase == "盘中"
            else f"{phase}，返回最新可得行情"
        )
    elif close_confirmed:
        stage = f"最近已完成交易日 {market_date} 的收盘信号"
    else:
        stage = f"{market_date} 尚未收盘，收盘信号未形成"
    reader = signal_evidence.current_reader.get()
    legacy_replay = reader is not None and not any(
        entry.get("role") == "iv.monitor" for entry in reader.manifest["entries"].values())
    data_notes = [
        (f"原日存证重放：{market_date}；原日实际采集完成 {reader.closed_at.isoformat()}；"
         f"manifest SHA-256 {reader.manifest_sha256}。" if legacy_replay else
         "市场输入来源、日期及回退情况见以下审计记录"),
        daily_valuation.disclosure(live.get("valuation_provenance")),
        "MOM120沿用价格指数动量口径",
        f"{product}期货源：{future_quote_source}，as-of {future_quote_date}",
    ]
    if product == "IM":
        data_notes.append(
            f"中证1000 OHLCV源：{live.get('momentum_ohlcv_source', '未知')}；"
            + (
                "盘中成交量使用已确认状态占位，不把不可验证累计量写入信号"
                if live.get("momentum_volume_placeholder")
                else "成交量已通过日期、OHLC关系、正值与数量级校验"
            )
        )
    if live.get("momentum_ohlcv_source_failures"):
        data_notes.append(
            "指数OHLCV前序来源失败："
            + "；".join(live["momentum_ohlcv_source_failures"])
        )
    if live.get("momentum_ohlcv_source_audit"):
        page_summary = [
            f"{page['page']}:{page['first_response_date']}..{page['last_response_date']}"
            f" sha256={page['response_sha256']}"
            f" bytes={page['response_bytes']}"
            f" {page['started_at']}..{page['ended_at']}"
            for page in live["momentum_ohlcv_source_audit"]
        ]
        data_notes.append(
            "Tencent OHLCV分页来源审计：" + "；".join(page_summary)
        )
    if bridge_from_anchor:
        data_notes.append(
            f"账本下一交易日桥接：当前腿固定取"
            f"{LIVE_CONTINUATION_ANCHOR[product]['last_verified_day']}已核验收盘锚点；"
            f"{market_date}行情只形成下一交易日目标"
        )
    if fear_evidence is not None:
        data_notes.extend([fear_grid.source_disclosure(fear_evidence), fear_grid.reference_disclosure(fear_evidence)])
        data_notes.append(
            f"恐贪来源：{fear_evidence['fear_data_status']}，"
            f"数据日 {fear_evidence['fear_data_date'] or '缺失'}，"
            f"分数 {fear_evidence['fear_greed_index'] if fear_evidence['fear_greed_index'] is not None else '缺失'}；"
            f"网页更新 {fear_evidence['fear_page_updated_at']}；"
            f"CSV SHA-256 {fear_evidence['fear_csv_sha256']}"
        )
    data_notes.extend(future_quotes.attrs.get("source_audit", []))
    if future_quotes.attrs.get("source_failures"):
        data_notes.append(
            "行情源回退/不可用汇总："
            + "；".join(future_quotes.attrs["source_failures"])
        )
    if calendar_note:
        data_notes.append(calendar_note)
    signal: dict[str, Any] = {
        "product": product,
        "mode": mode,
        "market_phase": phase,
        "market_date": market_date,
        "close_confirmed": close_confirmed,
        "state_anchor_day": state_anchor_day,
        "stage": stage,
        "fetch_time": clock.strftime("%Y-%m-%d %H:%M:%S"),
        "index_price": live["price"],
        "score": live["score"],
        "valuation_provenance": live.get("valuation_provenance", {}),
        "momentum_120": live["momentum_120"],
        "momentum_score": live["momentum_score"],
        "momentum_abs20": live["momentum_abs20"],
        "momentum_abs": live.get("momentum_abs", live["momentum_abs20"]),
        "momentum_abs_days": live.get("momentum_abs_days", 20),
        "momentum_abs_on": live.get("momentum_abs_on", live["momentum_abs20"] > 0),
        "momentum_abs_debounce_active": live.get("momentum_abs_debounce_active", True),
        "momentum_volume_ratio": live["momentum_volume_ratio"],
        "momentum_volume_pass": live["momentum_volume_pass"],
        "momentum_volume_placeholder": live["momentum_volume_placeholder"],
        "momentum_score_hot": live["momentum_score_hot"],
        "momentum_base_nav": live["momentum_base_nav"],
        "momentum_base_dd": live["momentum_base_dd"],
        "momentum_nav_defense": live["momentum_nav_defense"],
        "momentum_ohlcv_source": live["momentum_ohlcv_source"],
        "momentum_ohlcv_source_audit": live.get("momentum_ohlcv_source_audit", []),
        "momentum_ohlcv_source_failures": live.get("momentum_ohlcv_source_failures", []),
        "momentum_ohlcv_source_volume_scale": live.get(
            "momentum_ohlcv_source_volume_scale"
        ),
        "momentum_current_weight": live["momentum_current_weight"],
        "momentum_next_weight": live["momentum_next_weight"],
        "momentum_signal_date": live["momentum_signal_date"],
        "momentum_current_source_date": live["momentum_current_source_date"],
        "next_trade_date": _roll_forward_exchange_day(
            market_date + timedelta(days=1), require_official=True
        ),
        "core_current": current_core,
        "core_target": target_core,
        "core_action": core_action,
        "future_last": float(active_future["lastprice"]),
        "future_bid": float(active_future.get("bprice", np.nan)),
        "future_ask": float(active_future.get("sprice", np.nan)),
        "future_quote_source": future_quote_source,
        "future_quote_date": future_quote_date,
        "future_expiry": _third_friday(*_contract_month(target_core)),
        "next_core": next_core,
        "roll_date": active_expiry,
        "roll_execution_date": roll_execution_date,
        "scheduled_roll_completed": scheduled_roll_completed,
        "core_eod_contract": future_plan["core_eod_contract"],
        "roll_confirmed": future_plan["roll_confirmed"],
        "roll_policy": future_plan["roll_policy"],
        "quarter_spread": spread,
        **quarter_roll.monthly_spreads(
            product, future_quotes, market_date, lambda c: _third_friday(*_contract_month(c))
        ),
        "option_monthly_reset_due": option_roll_due,
        "option_monthly_reset_preview": product == "IC" and monthly_preview_only,
        "option_monthly_reset_execution_date": monthly_expiry,
        "option_reference_contract": option_reference_contract,
        "grid_current": float(live["grid_current_units"]),
        "grid_target": grid_units,
        "grid_action": grid_action,
        "grid_policy_revision": grid_policy_revision(market_date),
        "grid_policy": grid_rule(product, market_date),
        "data_notes": data_notes,
    }
    if calendar_context is not None:
        calendar_context["signal"] = signal
    if fear_evidence is not None:
        signal.update(fear_evidence)
        if market_date >= fear_grid.CLOSE_FALLBACK_EFFECTIVE_DATE:
            actual_generated = datetime.now(BEIJING)
            signal.update(
                signal_calculation_started_at=actual_generated.isoformat(timespec="seconds"),
                signal_generation_timing="retrospective_replay" if
                _HISTORICAL_REPLAY_DAY.get() is not None or actual_generated.date() > market_date
                else "intraday_hypothetical_if_now_close" if not close_confirmed else "close_confirmed",
            )
        signal.update({
            "grid_entry_source_current": live["grid_entry_source_current"],
            "grid_entry_source_target": live["grid_entry_source_target"],
            "grid_transition_reason": live["grid_transition_reason"],
        })

    if product == "IC":
        put_contract = str(LIVE_CONTINUATION_ANCHOR["IC"]["post_put_contract"])
        match = re.search(r"P(\d{4})", put_contract)
        if not match:
            raise RuntimeError(f"无法解析IC Put合约: {put_contract}")
        replay_day = _HISTORICAL_REPLAY_DAY.get()
        if replay_day is not None:
            security_id = LIVE_CONTINUATION_ANCHOR["IC"].get(
                "post_put_security_id"
            )
            if not security_id:
                raise RuntimeError(
                    f"IC历史补账缺少既有Put {put_contract} 的证券代码映射"
                )
            chain, sse_stamp = fetch_sse_existing_put_historical_quote(
                put_contract, str(security_id), replay_day
            )
            etf = (fetch_510500_quote_with_failover(market_date) if signal_evidence.current_reader.get() is not None
                   else fetch_sse_510500_historical_quote(replay_day))
        else:
            chain, sse_stamp = _fetch_510500_chain_for_day(match.group(1), market_date)
            etf = fetch_510500_quote_with_failover(market_date)
        chain_label = f"{sse_stamp.get('source', '上交所')}510500期权链"
        etf_label = str(etf.get("source", "上交所510500ETF"))
        data_notes.append(f"期权链实际来源：{sse_stamp.get('source', '上交所')}；ETF现价实际来源：{etf_label}")
        chain_day = _validate_market_stamp(chain_label, sse_stamp["date"], clock)
        etf_day = _validate_market_stamp(etf_label, etf["date"], clock)
        _require_intraday_bridge_source_day(
            chain_label, chain_day, market_date, bridge_from_anchor
        )
        _require_intraday_bridge_source_day(
            etf_label, etf_day, market_date, bridge_from_anchor
        )
        if chain_day != etf_day:
            raise RuntimeError(
                f"上交所ETF与期权链日期不一致：{etf_day} != {chain_day}"
            )
        put_quote = _quote_row(chain, put_contract, market_date, quote_source=sse_stamp.get("source"))
        if put_quote is not None and float(LIVE_CONTINUATION_ANCHOR["IC"].get("post_put_qty", 0)) > 0:
            _require_held_ic_put_identity(
                put_contract, LIVE_CONTINUATION_ANCHOR["IC"].get("post_put_security_id"), put_quote, market_date
            )
        target_delta = float(live["v13_put_target_delta"])
        prior_delta = float(live["v13_current_put_delta"])
        current_core_delta = float(live["v13_current_core_put_delta"])
        current_momentum_delta = float(live["v13_current_momentum_put_delta"])
        target_core_delta = float(live["v13_core_put_delta"])
        target_momentum_delta = float(live["v13_momentum_put_delta"])
        put_current = (
            f"组合目标绝对Delta {prior_delta:.1%}，账本合约 {put_contract}"
        )
        put_target = (
            "无需Put，绝对Delta 0%"
            if math.isclose(target_delta, 0.0, rel_tol=0.0, abs_tol=1e-12)
            else f"绝对Delta {target_delta:.0%}，沿用 {put_contract}"
        )
        put_action = (
            "HOLD"
            if math.isclose(target_delta, prior_delta) and option_core_action == "HOLD"
            else "RESIZE_OR_ROLL"
        )
        _require_existing_leg_quote("IC Put", put_contract, put_quote, put_action)
        put_market = _format_market(put_contract, put_quote)
        put_target_contract_value: str | None = put_contract
        put_target_security_id_value: str | None = str(
            LIVE_CONTINUATION_ANCHOR["IC"].get("post_put_security_id") or ""
        ) or None
        ic_sizing: dict[str, Any] = {}
        if (replay_day is not None and option_core_action == "ROLL"
                and signal_evidence.current_reader.get() is None):
            raise RuntimeError(
                f"IC历史补账遇到月换日 {replay_day}，缺少该日完整510500期权链/挂牌月份/ETF等原始证据；"
                "补齐原日可信存档后执行historical_replay，禁止用当前链替代"
            )
        if option_core_action == "HOLD":
            anchored_total = int(LIVE_CONTINUATION_ANCHOR["IC"]["post_put_qty"])
            protection_changed = not (
                math.isclose(target_delta, prior_delta, abs_tol=1e-12)
                and math.isclose(target_core_delta, current_core_delta, abs_tol=1e-12)
                and math.isclose(
                    target_momentum_delta, current_momentum_delta, abs_tol=1e-12
                )
            )
            if protection_changed:
                if put_quote is None:
                    raise RuntimeError(
                        f"IC既有Put {put_contract} 无有效行情，禁止账本续接"
                    )
                ic_sizing = _size_existing_ic_put(
                    put_contract,
                    put_quote,
                    market_date,
                    float(etf["last"]),
                    float(option_reference_future["lastprice"]),
                    anchored_total,
                    current_core_delta,
                    current_momentum_delta,
                    0.0 if LIVE_CONTINUATION_ANCHOR["IC"].get("v14_core_put_contract") else target_core_delta,
                    target_momentum_delta,
                )
                ic_sizing["put_selection_note"] = (
                    f"{LIVE_CONTINUATION_ANCHOR['IC']['last_verified_day']}已核验账本续接；"
                    "保护档变化，沿用既有合约并按当日有效价格重算IV/Delta后调整张数"
                )
            else:
                held = _ic_current_quantity_breakdown()
                anchored_core = held["core"]
                anchored_momentum = held["momentum"]
                ic_sizing = {
                    "put_current_total_qty": anchored_total,
                    "put_current_core_qty": anchored_core,
                    "put_current_momentum_qty": anchored_momentum,
                    "put_current_grid_qty": 0,
                    "put_target_total_qty": anchored_total,
                    "put_target_core_qty": anchored_core,
                    "put_target_momentum_qty": anchored_momentum,
                    "put_target_grid_qty": 0,
                    "put_selection_note": (
                        f"{LIVE_CONTINUATION_ANCHOR['IC']['last_verified_day']}已核验账本续接；"
                        "保护档未变，沿用既有合约与张数"
                    ),
                }
            anchored_core = int(ic_sizing["put_current_core_qty"])
            anchored_momentum = int(ic_sizing["put_current_momentum_qty"])
            target_total = int(ic_sizing["put_target_total_qty"])
            target_core_qty = int(ic_sizing["put_target_core_qty"])
            target_momentum = int(ic_sizing["put_target_momentum_qty"])
            put_current = (
                f"共{anchored_total}张（裸滚核心袖{anchored_core}张 + "
                f"动量指引袖{anchored_momentum}张 + 网格0张） {put_contract}"
            )
            put_target = (
                "无需Put，绝对Delta 0%"
                if target_total == 0
                else (
                    f"共{target_total}张（裸滚核心袖{target_core_qty}张 + "
                    f"动量指引袖{target_momentum}张 + 网格0张） {put_contract}"
                )
            )
        elif option_core_action == "ROLL" or option_roll_due:
            reset_day = monthly_expiry
            reset = select_ic_put_for_reset(
                reset_day,
                float(etf["last"]),
                float(option_reference_future["lastprice"]),
                target_delta,
            )
            signal["v14_selected_core_entry_premium"] = (
                float(reset["quote"]["last"]) if reset.get("quote") is not None else None
            )
            put_target_contract_value = (
                str(reset["contract"]) if reset["contract"] else None
            )
            put_target_security_id_value = (
                str(reset.get("security_id")) if reset.get("security_id") else None
            )
            if reset["stamp"] is not None:
                _validate_chain_stamp_matches(
                    "上交所510500新月份期权链",
                    reset["stamp"],
                    etf_day,
                    clock,
                )
            if reset["qty"] is None:
                return make_diagnostic_signal(
                    product, clock, "IC维护候选合约已选，但IV或Delta不足以确认张数，Put腿待核验。",
                    source_signal=signal, status="put_quantity_unresolved",
                )
            if reset["qty"] == 0:
                put_target = "无需Put，绝对Delta 0%"
                put_market = "无（目标Delta为0%）"
                held = _ic_current_quantity_breakdown()
                ic_sizing = {
                    **{f"put_current_{part}_qty": value for part, value in held.items()},
                    **{f"put_target_{part}_qty": 0 for part in held},
                }
            else:
                qty_text = (
                    f"多 {reset['qty']}张"
                    if reset["qty"] is not None
                    else "数量待有效IV"
                )
                put_target = (
                    f"每1倍组合规模规范化{qty_text} {reset['contract']}，"
                    f"绝对Delta {target_delta:.1%}"
                )
                put_market = _format_market(str(reset["contract"]), reset["quote"])
                if reset["absolute_delta"] is not None:
                    future_notional = float(option_reference_future["lastprice"]) * 200.0
                    etf_option_notional = float(etf["last"]) * 10_000.0
                    full_equivalent = max(
                        1, round(future_notional / etf_option_notional)
                    )
                    raw_qty = (
                        full_equivalent
                        * target_delta
                        / float(reset["absolute_delta"])
                    )
                    current_breakdown = _ic_current_quantity_breakdown()
                    target_breakdown = _ic_put_quantity_breakdown(
                        full_equivalent,
                        float(reset["absolute_delta"]),
                        target_core_delta,
                        target_momentum_delta,
                        int(reset["qty"]),
                    )
                    ic_sizing = {
                        "put_sizing_future_price": float(option_reference_future["lastprice"]),
                        "put_sizing_future_multiplier": 200,
                        "put_sizing_future_notional": future_notional,
                        "put_sizing_etf_price": float(etf["last"]),
                        "put_sizing_option_multiplier": 10_000,
                        "put_sizing_etf_option_notional": etf_option_notional,
                        "put_sizing_full_equivalent_contracts": full_equivalent,
                        "put_sizing_target_delta": target_delta,
                        "put_sizing_option_abs_delta": float(reset["absolute_delta"]),
                        "put_sizing_raw_qty": raw_qty,
                        "put_sizing_rounded_qty": int(reset["qty"]),
                        "put_current_total_qty": int(current_breakdown["total"]),
                        "put_current_core_qty": int(current_breakdown["core"]),
                        "put_current_momentum_qty": int(
                            current_breakdown["momentum"]
                        ),
                        "put_current_grid_qty": 0,
                        "put_target_total_qty": int(target_breakdown["total"]),
                        "put_target_core_qty": int(target_breakdown["core"]),
                        "put_target_momentum_qty": int(
                            target_breakdown["momentum"]
                        ),
                        "put_target_grid_qty": 0,
                        "put_sizing_iv": reset["iv"],
                        "put_sizing_expiry": reset["expiry"],
                        "put_sizing_strike": reset["strike"],
                        "put_sizing_signal_date": reset_day,
                        "put_sizing_target_expiry_date": (
                            pd.Timestamp(reset_day) + pd.DateOffset(months=3)
                        ).date(),
                    }
                    put_current = (
                        f"共{current_breakdown['total']}张（裸滚核心袖"
                        f"{current_breakdown['core']}张 + 动量指引袖"
                        f"{current_breakdown['momentum']}张 + 网格0张） "
                        f"{put_contract}"
                    )
                    put_target = (
                        f"共{target_breakdown['total']}张（裸滚核心袖"
                        f"{target_breakdown['core']}张 + 动量指引袖"
                        f"{target_breakdown['momentum']}张 + 网格0张） "
                        f"{reset['contract']}"
                    )
                # A missing IV may leave the target quantity unresolved, but
                # the held contract identity must never become the new target.
        put_action = (
            "HOLD"
            if math.isclose(target_delta, prior_delta, abs_tol=1e-12)
            and option_core_action == "HOLD"
            else "RESIZE_OR_ROLL"
        )
        signal.update(
            {
                "etf_price": etf["last"],
                "etf_quote_date": etf["date"],
                "etf_quote_time": etf["time"],
                "iv_monitor_option_price": float(put_quote["last"]) if put_quote is not None else None,
                "sse_time": (pd.Timestamp(put_quote["source_stamp"]).strftime("%Y%m%d %H%M%S")
                             if put_quote is not None and "source_stamp" in put_quote.index
                             else f"{sse_stamp['date']} {sse_stamp['time']}"),
                "put_current": put_current,
                "put_target": put_target,
                "put_action": put_action,
                "put_market": put_market,
                "call_current": "无",
                "call_target": "无（IC 1.3明确禁止Call）",
                "call_action": "HOLD",
                "put_current_contract": put_contract,
                "put_target_contract": put_target_contract_value,
                "put_target_security_id": put_target_security_id_value,
                "call_current_contract": None,
                "call_target_contract": None,
                "call_target_qty_normalized": 0.0,
                "core_put_target_delta": live["v13_core_put_delta"],
                "momentum_put_target_delta": live["v13_momentum_put_delta"],
                "total_put_target_delta": live["v13_put_target_delta"],
                "core_put_current_delta": live["v13_current_core_put_delta"],
                "momentum_put_current_delta": live[
                    "v13_current_momentum_put_delta"
                ],
                "total_put_current_delta": live["v13_current_put_delta"],
                "valuation_tier": live["valuation_tier"],
                "valuation_tier_label": live["valuation_tier_label"],
                "valuation_put_delta": live["valuation_put_delta"],
                "mom120_floor_delta": live["mom120_floor_delta"],
                "current_core_put_driver": live["current_core_put_driver"],
                "current_momentum_put_driver": live[
                    "current_momentum_put_driver"
                ],
                "core_put_driver": live["core_put_driver"],
                "momentum_put_driver": live["momentum_put_driver"],
                **ic_sizing,
            }
        )
    else:
        mo_quotes = quote_cache.get("MO")
        if mo_quotes is None:
            mo_quotes = fetch_cffex_quotes("MO", clock)
        mo_quote_source = str(mo_quotes.attrs.get("source", "未知"))
        mo_quote_date = mo_quotes.attrs.get("source_date")
        _require_intraday_bridge_source_day(
            "MO期权链", mo_quote_date, market_date, bridge_from_anchor
        )
        data_notes.append(f"MO期权链源：{mo_quote_source}，as-of {mo_quote_date}")
        data_notes.extend(mo_quotes.attrs.get("source_audit", []))
        if mo_quotes.attrs.get("source_failures"):
            data_notes.append(
                "MO行情源回退/不可用汇总："
                + "；".join(mo_quotes.attrs["source_failures"])
            )
        option_rows_to_verify: dict[str, float] = {}
        im_anchor = LIVE_CONTINUATION_ANCHOR["IM"]
        previous_reset_value = im_anchor.get("verified_put_monthly_reset_date")
        previous_put_reset = (
            date.fromisoformat(str(previous_reset_value)[:10])
            if previous_reset_value is not None else None
        )
        # Monthly selection uses execution-day quotes, as in the research replay.
        # The preceding close is only a calendar preview, never a completed reset.
        im_put_reset_due = market_date == monthly_expiry and previous_put_reset != monthly_expiry
        if previous_put_reset is not None and previous_put_reset > monthly_expiry:
            raise RuntimeError("IM Put月度维护标记晚于当前月度事件，拒绝续接")
        core_put_contract_value = im_anchor.get("post_core_put_contract") or im_anchor.get("post_put_contract")
        core_put_contract = str(core_put_contract_value) if core_put_contract_value else None
        core_put_quote = _quote_row(mo_quotes, core_put_contract) if core_put_contract else None
        momentum_put_contract_value = im_anchor.get("post_momentum_put_contract")
        momentum_put_contract = (
            str(momentum_put_contract_value)
            if momentum_put_contract_value not in (None, "")
            else None
        )
        momentum_put_quote = (
            _quote_row(mo_quotes, momentum_put_contract)
            if momentum_put_contract
            else None
        )
        put_target = int(live["v13_parent_puts_per_full_core"])
        prior_put = int(live["v13_current_parent_puts"])
        core_put_target_normalized = float(live["v13_put_target_qty_normalized"])
        core_put_current_normalized = float(
            im_anchor["verified_core_put_qty_normalized"]
        )
        momentum_put_current_normalized = float(
            im_anchor["verified_momentum_put_qty_normalized"]
        )
        momentum_put_target_normalized = (
            im_put_policy.momentum_quantity(market_date, live["momentum_120"], live["momentum_next_weight"], core_put_target_normalized)
        )
        total_put_current_normalized = (
            core_put_current_normalized + momentum_put_current_normalized
        )
        total_put_target_normalized = (
            core_put_target_normalized + momentum_put_target_normalized
        )
        core_put_target_contract = core_put_contract
        core_put_target_text = (
            "无需Put（目标0张）"
            if put_target == 0
            else (
                f"0.5倍核心袖规范化多 {core_put_target_normalized:g}张 "
                f"{core_put_target_contract}（父规则每1倍 {put_target}张）"
            )
        )
        core_put_market = _format_market(core_put_contract, core_put_quote)
        im_contract_selection: dict[str, Any] = {}
        # A confirmed close roll changes the held chain before the next-session Put plan.
        # An unconfirmed intraday roll or an earlier preview must not change it.
        put_reference_contract = (
            future_plan["core_eod_contract"] if scheduled_roll_completed else current_core
        )
        put_reference_future = _require_listed_future_quote(
            "IM", future_quotes, put_reference_contract
        )
        put_reference_price = float(put_reference_future["lastprice"])
        put_reset_day = monthly_expiry if im_put_reset_due else market_date
        core_put_expiry = None
        if core_put_contract is not None and core_put_current_normalized > 0.0:
            core_put_expiry = _third_friday(*_contract_month(core_put_contract))
            if not _expiry_definitely_after_reference(core_put_expiry, market_date):
                _require_model_expiry_calendar(core_put_expiry, "held IM core Put maintenance")
        core_put_reselect = put_target > 0 and (
            im_put_reset_due or core_put_current_normalized == 0.0
            or (core_put_expiry is not None and core_put_expiry <= market_date)
        )
        if core_put_current_normalized > 0.0 and core_put_contract is None:
            raise RuntimeError("IM核心Put账本数量非零但合约为空，拒绝继续")
        if not core_put_reselect:
            im_contract_selection["put_selection_note"] = (
                f"{LIVE_CONTINUATION_ANCHOR['IM']['last_verified_day']}已核验账本续接；"
                "非月换日沿用既有合约，只按保护档调整张数"
            )
        else:
            reset_day = put_reset_day
            selected_put = select_im_put_for_reset(
                mo_quotes, reset_day, put_reference_price
            )
            core_put_target_contract = str(selected_put["instrument"])
            core_put_target_text = (
                f"0.5倍核心袖规范化多 {core_put_target_normalized:g}张 "
                f"{core_put_target_contract}（父规则每1倍 {put_target}张）"
            )
            core_put_market = _format_market(core_put_target_contract, selected_put)
            option_rows_to_verify[core_put_target_contract] = float(
                selected_put["lastprice"]
            )
            im_contract_selection = {
                "put_sizing_expiry": selected_put["expiry"],
                "put_sizing_strike": float(selected_put["strike"]),
                "put_sizing_signal_date": reset_day,
                "put_sizing_target_expiry_date": (
                    pd.Timestamp(reset_day) + pd.DateOffset(months=3)
                ).date(),
                "put_sizing_target_strike": im_put_policy.moneyness(market_date) * put_reference_price,
            }

        momentum_put_target_contract: str | None = None
        momentum_put_target_quote: pd.Series | None = None
        momentum_put_selection_note = "MOM120非负或动量执行权重为0，目标空仓" if im_put_policy.active(market_date) else "动量执行权重为0，目标空仓"
        if momentum_put_target_normalized > 0.0:
            current_expiry = (
                _third_friday(*_contract_month(momentum_put_contract))
                if momentum_put_contract
                else None
            )
            if current_expiry is not None:
                if not _expiry_definitely_after_reference(current_expiry, market_date):
                    _require_model_expiry_calendar(current_expiry, "held IM momentum Put maintenance")
            if (
                momentum_put_contract and momentum_put_current_normalized > 0.0
                and not im_put_reset_due and current_expiry > market_date
            ):
                momentum_put_target_contract = momentum_put_contract
                momentum_put_target_quote = momentum_put_quote
                momentum_put_selection_note = (
                    "非月度重置日，沿用既有独立动量Put，只按目标调整数量"
                )
            else:
                selected_momentum_put = select_independent_im_put_for_reset(
                    mo_quotes, put_reset_day, put_reference_price
                )
                desired_expiry = _independent_im_put_target_expiry(mo_quotes, put_reset_day)
                if selected_momentum_put["expiry"] != desired_expiry:
                    raise RuntimeError("IM动量Put独立期限选择与真实重放规则不一致")
                momentum_put_target_contract = str(
                    selected_momentum_put["instrument"]
                )
                momentum_put_target_quote = selected_momentum_put
                option_rows_to_verify[momentum_put_target_contract] = float(
                    selected_momentum_put["lastprice"]
                )
                momentum_put_selection_note = (
                    "独立月度重置（同到期月也重选行权价）或从零进入，"
                    f"按策略IM期货报价选择约3个月、{im_put_policy.moneyness(market_date):.0%}行权价"
                )
        momentum_put_current_text = (
            "独立动量Put 0张"
            if momentum_put_current_normalized == 0.0
            else f"独立动量Put {momentum_put_current_normalized:g}张 {momentum_put_contract}"
        )
        momentum_put_target_text = (
            "独立动量Put 0张"
            if momentum_put_target_normalized == 0.0
            else f"独立动量Put {momentum_put_target_normalized:g}张 {momentum_put_target_contract}"
        )
        call_contract_value = LIVE_CONTINUATION_ANCHOR["IM"].get(
            "verified_call_contract"
        )
        call_expiry_value = LIVE_CONTINUATION_ANCHOR["IM"].get(
            "verified_call_expiry"
        )
        call_strike_value = LIVE_CONTINUATION_ANCHOR["IM"].get(
            "verified_call_strike"
        )
        call_contract = (
            str(call_contract_value) if call_contract_value not in (None, "") else None
        )
        call_quote = _quote_row(mo_quotes, call_contract) if call_contract else None
        call_expiry = (
            date.fromisoformat(str(call_expiry_value)) if call_expiry_value else None
        )
        call_otm = (
            float(call_strike_value) / float(live["price"]) - 1.0
            if call_strike_value is not None
            else np.nan
        )
        call_market = (
            _format_market(call_contract, call_quote)
            if call_contract
            else "无（已核验Call仓位为0）"
        )
        call_finished = _im_call_finished(call_contract, call_expiry, market_date, close_confirmed)
        threat_roll_count = int(
            LIVE_CONTINUATION_ANCHOR["IM"].get("verified_threat_roll_count", 0)

        )
        call_target_contract: str | None = None
        call_target_expiry: date | None = None
        call_target_strike: float | None = None
        call_target_qty_normalized = 0.0
        call_target_threat_roll_count = threat_roll_count
        no_call_signal = market_date >= v14_policy.NO_CALL_EFFECTIVE_SIGNAL_DATE
        if no_call_signal:
            call_action = "CLOSE_CALL" if not call_finished else "HOLD"
            call_target = "买回旧Call，此后不再卖Call" if not call_finished else "目标空仓（fix6停止卖Call）"
        elif not call_finished:
            if call_otm <= 0.05 + 1e-12:
                if threat_roll_count >= 5:
                    call_action = "CLOSE_CALL"
                    call_target = "买回旧Call并暂停；已达到连续5次救援上限"
                else:
                    rescue = select_im_call_rescue(
                        mo_quotes,
                        market_date,
                        float(live["price"]),
                        call_expiry,
                        float(call_strike_value),
                    )
                    if rescue is None:
                        call_action = "CLOSE_CALL"
                        call_target = (
                            "买回旧Call；没有符合rescue_next_listed与行权价上移5%的合约"
                        )
                    else:
                        call_action = "RESCUE_NEXT_LISTED"
                        rescue_row = rescue["row"]
                        call_target_contract = str(rescue_row["instrument"])
                        call_target_expiry = rescue["expiry"]
                        call_target_strike = float(rescue_row["strike"])
                        call_target_qty_normalized = -1.0
                        call_target_threat_roll_count = threat_roll_count + 1
                        call_target = (
                            f"买回旧Call并空2张 {rescue_row['instrument']}（rescue_next_listed，"
                            f"Delta {rescue['delta']:.3f}，IV {rescue['iv']:.2%}，救援豁免IV26%）"
                        )
                        call_market = _format_market(
                            str(rescue_row["instrument"]), rescue_row
                        )
                        option_rows_to_verify[str(rescue_row["instrument"])] = float(
                            rescue_row["lastprice"]
                        )
            else:
                call_action = "HOLD"
                call_target_contract = call_contract
                call_target_expiry = call_expiry
                call_target_strike = (
                    float(call_strike_value) if call_strike_value is not None else None
                )
                call_target_qty_normalized = -1.0
                call_target = f"空2张 {call_contract}"
        else:
            selected_call = select_im_call_d10(
                mo_quotes,
                market_date,
                float(live["price"]),
                option_reference_expiry,
            )
            if selected_call is None:
                call_action = "WAIT_IV_OR_CHAIN"
                call_target = "旧Call已到期；未找到有效D10候选，保持空仓"
            elif float(selected_call["iv"]) >= 0.26:
                call_action = "OPEN_CALL"
                selected_row = selected_call["row"]
                call_target_contract = str(selected_row["instrument"])
                call_target_expiry = selected_call["expiry"]
                call_target_strike = float(selected_row["strike"])
                call_target_qty_normalized = -1.0
                call_target_threat_roll_count = 0
                call_target = (
                    f"空2张 {selected_row['instrument']}（Delta {selected_call['delta']:.3f}，"
                    f"IV {selected_call['iv']:.2%}）"
                )
                call_market = _format_market(
                    str(selected_row["instrument"]), selected_row
                )
                option_rows_to_verify[str(selected_row["instrument"])] = float(
                    selected_row["lastprice"]
                )
            else:
                call_action = "WAIT_IV"
                selected_row = selected_call["row"]
                call_target = f"D10候选 {selected_row['instrument']} 的IV {selected_call['iv']:.2%}<26%，保持空仓"
                call_market = _format_market(
                    str(selected_row["instrument"]), selected_row
                )
                option_rows_to_verify[str(selected_row["instrument"])] = float(
                    selected_row["lastprice"]
                )
        if call_contract and (not no_call_signal or not call_finished):
            _require_existing_leg_quote("IM Call", call_contract, call_quote, call_action)
        core_put_action = (
            "HOLD"
            if math.isclose(
                core_put_target_normalized,
                core_put_current_normalized,
                abs_tol=1e-12,
            )
            and core_put_target_contract == core_put_contract
            and not (im_put_reset_due and core_put_target_normalized > 0.0)
            else "RESIZE_OR_ROLL"
        )
        momentum_put_action = (
            "HOLD"
            if math.isclose(
                momentum_put_target_normalized,
                momentum_put_current_normalized,
                abs_tol=1e-12,
            )
            and momentum_put_target_contract == momentum_put_contract
            and not (im_put_reset_due and momentum_put_target_normalized > 0.0)
            else "RESIZE_OR_ROLL"
        )
        im_put_action = (
            "HOLD"
            if core_put_action == "HOLD" and momentum_put_action == "HOLD"
            else "RESIZE_OR_ROLL"
        )
        if core_put_current_normalized > 0.0:
            _require_existing_leg_quote(
                "IM核心Put", core_put_contract, core_put_quote, core_put_action
            )
        if momentum_put_current_normalized > 0.0:
            if momentum_put_contract is None:
                raise RuntimeError("IM动量Put账本数量非零但合约为空，拒绝继续")
            _require_existing_leg_quote(
                "IM动量Put",
                momentum_put_contract,
                momentum_put_quote,
                momentum_put_action,
            )
        if mo_quote_source == "东方财富":
            for contract, price in option_rows_to_verify.items():
                verify_row = _quote_row(mo_quotes, contract)
                verify_basis = str(verify_row.get("pricing_basis", "source_last_quote")) if verify_row is not None else "source_last_quote"
                verification = verify_sina_option_quote(
                    contract,
                    mo_quote_date,
                    price,
                    clock,
                    **({"pricing_basis": verify_basis} if verify_basis == "live_bid_ask_mid_estimate_zero_volume" else {}),
                )
                data_notes.append(
                    f"{contract}经{verification['source']}复核，as-of "
                    f"{verification['source_date']}，{'双边中价估计（非成交价）' if verify_basis == 'live_bid_ask_mid_estimate_zero_volume' else '最新'}{verification['lastprice']:g}"
                )
        call_current_text = _im_call_current_text(call_contract, no_call_signal, call_finished)
        call_target = call_target.replace("空2张", "规范化空1张")
        put_current_text = (
            f"核心Put {core_put_current_normalized:g}张 {core_put_contract}；"
            f"{momentum_put_current_text}；合计 {total_put_current_normalized:g}张"
        )
        put_target_text = (
            f"{core_put_target_text}；{momentum_put_target_text}；"
            f"合计 {total_put_target_normalized:g}张"
        )
        momentum_put_market = (
            "无（目标与当前均为空仓）"
            if momentum_put_contract is None
            and momentum_put_target_contract is None
            else _format_market(
                momentum_put_target_contract or momentum_put_contract,
                (
                    momentum_put_target_quote
                    if momentum_put_target_quote is not None
                    else momentum_put_quote
                ),
            )
        )
        put_market = f"核心：{core_put_market}；动量：{momentum_put_market}"
        signal.update(
            {
                "put_current": put_current_text,
                "put_target": put_target_text,
                "put_action": im_put_action,
                "put_market": put_market,
                "put_current_contract": core_put_contract,
                "put_target_contract": (
                    core_put_target_contract if put_target > 0 else None
                ),
                "core_put_current_contract": core_put_contract,
                "core_put_target_contract": (
                    core_put_target_contract if put_target > 0 else None
                ),
                "momentum_put_current_contract": momentum_put_contract,
                "momentum_put_target_contract": momentum_put_target_contract,
                "call_current": call_current_text,
                "call_target": call_target,
                "call_action": call_action,
                "call_market": call_market,
                "call_current_contract": call_contract,
                "call_target_contract": call_target_contract,
                "call_target_expiry": call_target_expiry,
                "call_target_strike": call_target_strike,
                "call_target_qty_normalized": call_target_qty_normalized,
                "call_target_threat_roll_count": call_target_threat_roll_count,
                "call_otm": call_otm,
                "call_expiry": call_expiry,
                "call_has_position": call_contract is not None and not call_finished,
                "threat_roll_count": threat_roll_count,
                "core_put_target_qty_normalized": core_put_target_normalized,
                "core_put_current_qty_normalized": core_put_current_normalized,
                "v13_parent_puts_per_full_core": put_target,
                "v13_current_parent_puts_per_full_core": prior_put,
                "momentum_put_target_qty_normalized": momentum_put_target_normalized,
                "momentum_put_current_qty_normalized": momentum_put_current_normalized,
                "total_put_target_qty_normalized": total_put_target_normalized,
                "total_put_current_qty_normalized": total_put_current_normalized,
                "core_put_action": core_put_action,
                "momentum_put_action": momentum_put_action,
                "momentum_put_selection_note": momentum_put_selection_note,
                "im_put_execution_revision": IM_PUT_EXECUTION_REVISION,
                "im_execution_fix_revision": IM_EXECUTION_FIX_REVISION,
                "im_put_policy_revision": im_put_policy.REVISION if im_put_policy.active(market_date) else "legacy_dual95",
                "im_put_policy_description": im_put_policy.description(market_date),
                "im_put_target_moneyness": im_put_policy.moneyness(market_date),
                "momentum_put_parent_qty": im_put_policy.momentum_parent(live["momentum_120"]) if im_put_policy.active(market_date) else put_target,
                "im_put_calendar_revision": "execution_day_20260911_v1",
                "put_monthly_reset_preview": option_roll_due and market_date < monthly_expiry,
                "put_reference_price_date": market_date,
                "option_calendar_reset_due": option_roll_due,
                "option_monthly_reset_due": im_put_reset_due,
                "put_monthly_reset_already_recorded": option_roll_due and previous_put_reset == monthly_expiry,
                "put_monthly_reset_execution_date": monthly_expiry if option_roll_due else None,
                "put_reference_future": str(put_reference_future["instrument"]),
                "put_reference_price": put_reference_price,
                "absolute_valuation_tier": live["absolute_valuation_tier"],
                "absolute_valuation_tier_label": live[
                    "absolute_valuation_tier_label"
                ],
                "relative_valuation_tier": live["relative_valuation_tier"],
                "relative_valuation_tier_label": live[
                    "relative_valuation_tier_label"
                ],
                "valuation_puts_per_full_core": live[
                    "valuation_puts_per_full_core"
                ],
                "mom120_floor_puts_per_full_core": live[
                    "mom120_floor_puts_per_full_core"
                ],
                "core_put_driver": live["core_put_driver"],
                **im_contract_selection,
            }
        )
    if product == "IM":
        signal["put_pricing_evidence"] = {}
        for field in ("put_current_contract", "core_put_target_contract", "momentum_put_current_contract", "momentum_put_target_contract"):
            contract = signal.get(field)
            row = _quote_row(mo_quotes, contract) if contract else None
            if row is not None:
                signal["put_pricing_evidence"][field] = {
                    "contract": str(contract), "pricing_basis": str(row.get("pricing_basis", "source_last_quote")),
                    "market_text": _format_market(str(contract), row),
                }
    current_momentum_units = 0.5 * float(signal["momentum_current_weight"])
    target_momentum_units = 0.5 * float(signal["momentum_next_weight"])
    current_total_units = 0.5 + current_momentum_units + float(signal["grid_current"])
    target_total_units = 0.5 + target_momentum_units + float(signal["grid_target"])
    momentum_change = target_momentum_units - current_momentum_units
    signal.update(
        {
            "core_units_current": 0.5,
            "core_units_target": 0.5,
            "momentum_units_current": current_momentum_units,
            "momentum_units_target": target_momentum_units,
            "momentum_units_change": momentum_change,
            "momentum_action": (
                "HOLD"
                if math.isclose(momentum_change, 0.0, abs_tol=1e-12)
                else ("INCREASE" if momentum_change > 0 else "DECREASE")
            ),
            "total_units_current": current_total_units,
            "total_units_target": target_total_units,
            "total_units_change": target_total_units - current_total_units,
        }
    )
    if calendar_context is not None and calendar_context["expiries"]:
        return make_diagnostic_signal(
            product, clock, "Put或期货到期日未经官方日历核验；模型估值仅作诊断，正式目标未确认。",
            source_signal=signal,
        )
    # Validate adopted contracts before policy/scheduler code can create any
    # new pending plan. Unconsumed listed months remain warning-only inputs.
    require_signal_calendar(product, signal)
    signal = _apply_v14_live_policy(
        product,
        signal,
        mo_quotes=mo_quotes if product == "IM" else None,
    )
    put_execution.require_resolved_held_identity(product, signal)
    if signal.get("v14_action") == "HOLD_FAIL_CLOSED" or (
        calendar_context is not None and (calendar_context["expiries"] or calendar_context["failures"])
    ):
        calendar_failure = bool(calendar_context and (calendar_context["expiries"] or calendar_context["failures"]))
        return make_diagnostic_signal(
            product, clock,
            str(signal.get("v14_action_reason") or signal.get("v14_reason")
                or "Put腿未完成核验，保留独立行情观察；组合目标未确认。"),
            source_signal=signal,
            status="calendar_unverified" if calendar_failure else "put_fail_closed",
        )
    if put_execution.active(market_date):
        signal["v14_execution_revision"] = put_execution.REVISION
        signal["v14_opening_events"] = opening_events
    _v14_schedule_ordinary_put(product, signal, LIVE_CONTINUATION_ANCHOR[product], opening)
    if product == "IC":
        _refresh_ic_put_text(signal, LIVE_CONTINUATION_ANCHOR[product])
    # A monitor-only candidate must not contaminate an otherwise verified
    # delivery with a provisional expiry. Its existing N/A fallback is strict.
    monitor_token = _SIGNAL_CALENDAR_DIAGNOSTICS.set(None)
    try:
        signal["iv_warning"] = (
            {"status": "unavailable", "text": "IV预警：N/A（原日未归档独立监测结果；回放不重新联网）"}
            if (_original_evidence_replay() and not any(
                entry.get("role") == "iv.monitor"
                for entry in signal_evidence.current_reader.get().manifest["entries"].values())) else
            build_iv_warning(product, signal, live, mo_quotes if product == "IM" else None, clock,
                             collection_started=collection_started))
    finally:
        _SIGNAL_CALENDAR_DIAGNOSTICS.reset(monitor_token)
    if market_date >= fear_grid.CLOSE_FALLBACK_EFFECTIVE_DATE:
        finished = datetime.now(BEIJING)
        signal.update(signal_generated_at=finished.isoformat(timespec="seconds"),
                      signal_generation_timing="retrospective_replay" if
                      _HISTORICAL_REPLAY_DAY.get() is not None or finished.date() > market_date else
                      "intraday_hypothetical_if_now_close" if not close_confirmed else "close_confirmed")
    require_signal_calendar(product, signal)
    signal["calendar_provisional"] = False
    grid_ok = fear_grid.publication_view(signal).get("grid_target_confirmed", True) is True
    signal["signal_complete"] = grid_ok
    signal["persistence_eligible"] = bool(signal.get("close_confirmed")) and grid_ok
    signal["calendar_coverage_warning"] = "；".join(
        note for note in (_calendar_coverage_warning(market_date), calendar_note) if note
    ) or None
    return signal


def _sm() -> Any:
    return poe.start_message()


def _write_diagnostic_signal(msg: Any, product: str, signal: dict[str, Any]) -> None:
    """Keep incomplete observations visible without using the normal target table."""
    msg.write(f"### {PRODUCT_NAMES[product]}\n\n")
    msg.write("**部分数据可用；Put及完整组合目标尚未确认。**\n\n")
    msg.write(f"{signal.get('diagnostic_reason', '数据待核验')}\n\n")
    msg.write(f"信号日：`{signal.get('market_date')}`；状态：`{signal.get('diagnostic_status')}`。\n\n")
    warning = signal.get("calendar_coverage_warning")
    if warning:
        msg.write(f"**{warning}**\n\n")
    for row in signal.get("calendar_diagnostics", []):
        msg.write(f"- 到期或执行日期 `{row.get('date')}` 未经官方日历核验（{row.get('purpose')}）。\n")
    if signal.get("calendar_diagnostics"):
        msg.write("\n")
    future = signal.get("diagnostic_future", {})
    if future.get("last_verified_contract"):
        msg.write(f"最后已核验期货合约：`{future['last_verified_contract']}`；账本日：`{future.get('last_verified_day')}`。\n\n")
    if future.get("quotes"):
        msg.write("已核验期货报价（仅行情观察）：\n\n")
        for row in future["quotes"]:
            msg.write(f"- `{row.get('contract', row.get('instrument'))}`：{row.get('lastprice', row.get('price'))}。\n")
        msg.write("\n")
    references = signal.get("diagnostic_model", {}).get("unconfirmed_references", {})
    if references:
        msg.write("参考计算值（未确认；不作为正式目标或执行安排）：\n\n")
        for key, label in (
            ("momentum_weight_reference", "动量袖权重参考"),
            ("grid_units_reference", "网格倍数参考"),
            ("quarter_action_reference", "季度换仓动作参考"),
            ("quarter_execution_date_reference", "季度执行日期参考（仍需日历核验）"),
            ("quarter_preview_reference", "季度预告状态参考"),
            ("quarter_model_roll_reference", "季度模型换仓状态参考"),
        ):
            if key in references:
                msg.write(f"- {label}：{references[key]}。\n")
        msg.write("\n")
    msg.write("完整目标：N/A；本次结果仅供研究诊断，不生成新执行计划，不写入正式账本。\n\n")
    def safe(value: Any) -> Any:
        if isinstance(value, dict):
            return {str(key): safe(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [safe(item) for item in value]
        if isinstance(value, (np.bool_, bool)):
            return bool(value)
        if isinstance(value, (np.integer, int)):
            return int(value)
        if isinstance(value, (float, np.floating)):
            return float(value) if math.isfinite(float(value)) else None
        if isinstance(value, (date, datetime, pd.Timestamp)):
            return value.isoformat()
        if value is None or isinstance(value, (str, int, bool)):
            return value
        return str(value)
    msg.attach_file(name=f"{product.lower()}_diagnostic_{signal.get('market_date')}.json",
                    contents=json.dumps(safe(signal), ensure_ascii=False, allow_nan=False, indent=2).encode("utf-8"),
                    content_type="application/json", is_inline=False)


def _write_last_verified_snapshot(msg: Any, product: str) -> None:
    # The builder may temporarily install an opening projection while holding
    # this same lock. Copy under the lock; rendering must use that stable copy.
    with STRATEGY_QUERY_LOCK:
        display = _VERIFIED_DISPLAY_ANCHORS.get()
        anchor = deepcopy((display if display is not None else LIVE_CONTINUATION_ANCHOR)[product])
    momentum_weight = float(anchor["verified_momentum_weight"])
    grid_units = float(anchor["verified_grid_units"])
    route = anchor.get("v14_route_state", "future")
    core_units = 0.5 if route in {"future", "recovery_future"} else 0.0
    total_units = core_units + 0.5 * momentum_weight + grid_units
    core_text = (
        f"{core_units:g}倍核心期货：`{anchor['post_core_contract']}`（路线 `{route}`）"
        if core_units > 0 else f"核心路线：`{route}`；核心期货0倍"
    )
    put_qty = float(anchor["verified_put_qty_normalized"])
    put_contract = str(anchor["post_put_contract"])
    call_qty = float(anchor["verified_call_contracts_normalized"])
    call_text = "无（IC禁止Call）" if product == "IC" else f"规范化 {call_qty:g}张"
    if product == "IM":
        core_put_qty = float(anchor["verified_core_put_qty_normalized"])
        momentum_put_qty = float(anchor["verified_momentum_put_qty_normalized"])
        core_put_contract = str(anchor["post_core_put_contract"])
        momentum_contract = anchor.get("post_momentum_put_contract")
        momentum_text = (
            "0张"
            if momentum_put_qty == 0.0
            else f"{momentum_put_qty:g}张 `{momentum_contract}`"
        )
        core_put_text = f"{core_put_qty:g}张 `{core_put_contract}`" if core_put_qty > 0 else "0张"
        put_snapshot = (
            f"核心 {core_put_text}；"
            f"动量 {momentum_text}；合计 {put_qty:g}张"
        )
    else:
        breakdown = _ic_current_quantity_breakdown(anchor)
        core_contract = anchor.get("v14_core_put_contract")
        if not core_contract and put_execution.as_day(anchor["last_verified_day"]) < v14_policy.EFFECTIVE_SIGNAL_DATE:
            core_contract = anchor.get("post_put_contract")
        core_put_text = (f"{breakdown['core']:g}张 `{core_contract or '身份待核验'}`"
                         if breakdown["core"] > 0 else "0张")
        momentum_text = (f"{breakdown['momentum']:g}张 `{put_contract}`"
                         if breakdown["momentum"] > 0 else "0张")
        put_snapshot = f"核心 {core_put_text}；动量 {momentum_text}；合计 {put_qty:g}张"
    msg.write(
        f"**最后逐腿核验快照（{anchor['last_verified_day']}，仅研究审计）**\n\n"
        f"- {core_text}\n"
        f"- 动量袖：权重 {momentum_weight:g}，期货名义 {0.5 * momentum_weight:g}倍\n"
        f"- 独立网格：{grid_units:g}倍；期货合计：{total_units:g}倍\n"
        f"- Put：{put_snapshot}；Call：{call_text}\n"
        "- 这只是最后已核验状态，不是当前账户持仓；联网或账本续接恢复前，"
        "不生成下一交易日目标。\n\n"
    )


_BOT_SETTINGS = SettingsResponse(
    allow_attachments=False,
    introduction_message=(
        "📊 **IC / IM 正式研究信号 1.4**\n\n"
        "支持：`实时信号`（盘中）、`信号`（收盘后）、`查询 IC 参数`、`查询 IM 参数`、"
        "`最近一年表现`、`查询`。每次信号均逐腿列明当前仓位、下一交易日目标与变化；"
        "SC 会按 IC 处理。"
    ),
)
poe.update_settings(_BOT_SETTINGS)


def build_live_signal_with_transport_retry(product: str, mode: str, budget: float) -> dict[str, Any]:
    """Retry one transient transport failure for this product only."""
    with _network_budget(budget):
        for attempt in range(2):
            try:
                signal = build_live_trade_signal(product, mode=mode)
                if attempt:
                    signal.setdefault("data_notes", []).append(
                        "本品种首次连接中断/超时后在剩余预算内重试一次成功；未重复其他品种"
                    )
                return signal
            except (requests.ConnectionError, requests.Timeout):
                if attempt:
                    raise
                _bounded_timeout(1.0)
    raise AssertionError("unreachable")


class ICIMMainlinesBot:
    def run(self) -> None:
        try:
            self._run_impl()
        except Exception as exc:  # noqa: BLE001 - keep the Poe entrypoint responsive.
            with _sm() as msg:
                msg.write("## ⚠️ 查询失败\n\n")
                msg.write(f"{type(exc).__name__}: {exc}")

    def _run_impl(self) -> None:
        query = getattr(poe.query, "text", "").strip()
        intent = classify_query(query)
        if intent.route == "performance":
            self._handle_performance(intent)
        elif intent.route == "intraday_signal":
            self._handle_signal(intent.products, mode="intraday")
        elif intent.route == "close_signal":
            self._handle_signal(intent.products, mode="close")
        elif intent.route == "params":
            self._handle_params(intent.products)
        else:
            self._handle_snapshot(intent.products)

    def _handle_snapshot(self, products: tuple[str, ...]) -> None:
        clock = _now_beijing()
        if (_is_exchange_trading_day(clock.date())
                and (_market_phase(clock) != "收盘后" or clock.time() < SETTLEMENT_SNAPSHOT_CUTOFF)):
            with _sm() as msg:
                msg.write("## 最近已核验研究账本快照\n\n今日完整收盘数据尚未核验。\n\n")
                for product in products:
                    try:
                        _write_last_verified_snapshot(msg, product)
                    except Exception as exc:  # noqa: BLE001 - keep the other product's report.
                        msg.write(f"### {PRODUCT_NAMES[product]}\n\n⚠️ 账本快照无法安全渲染：{exc}\n\n")
            return
        self._handle_signal(products, mode="close")

    def _handle_signal(self, products: tuple[str, ...], mode: str) -> None:
        with fear_grid.observation_batch(), _sm() as msg:
            title = "实时信号（联网刷新）" if mode == "intraday" else "信号（收盘确认）"
            report_build_id = _report_build_id(mode)
            msg.write(
                f"## IC / IM 1.4 {title}｜构建 {report_build_id}"
                f"（{_now_beijing():%Y-%m-%d %H:%M:%S} 北京时间）\n\n"
            )
            msg.write("版本口径：部署服务名V1-2；本页信号规则v1.4；绩效页为另行标注的v1.3/r6冻结历史。\n\n")
            header_maintenance = False
            if mode == "intraday":
                try:
                    header_maintenance = bool(option_maintenance_notice._valid_maintenance_day(
                        _now_beijing().date(), _option_maintenance_session))
                except Exception as notice_exc:
                    msg.write(f"⚠️ 月度维护日无法核验：{type(notice_exc).__name__}: {notice_exc}；维护提醒已降级。\n\n")
            msg.write(
                ("本次按指定历史交易日重新核验数据。" if _HISTORICAL_REPLAY_DAY.get() is not None else "本次重新联网取数。")
                + "**当前仓位**是研究规则从已审计账本续接出的策略仓位，"
                + ("不是你的账户持仓；期货目标对应下一交易日，月度Put维护按今日收盘候选单列；各腿目标不会自动下单。\n\n"
                   if header_maintenance
                   else "不是你的账户持仓；**下一交易日目标**不会自动下单。\n\n")
            )
            msg.write("网格规则：2026-10-08信号日起，估值或恐慌≤25入单个0.5倍网格；按入场来源分别在估值退出线或恐慌≥50退出。此前信号保留当日规则。\n\n")
            msg.write("恐慌口径：盘中及收盘均优先合格当日值；当日未发布时，只沿用正式上一交易日合格值，保留真实数据日。历史补录单列实际生成时间与回放标记。\n\n")
            per_product_budget = _signal_product_network_budget(len(products))
            for product in products:
                try:
                    live = build_live_signal_with_transport_retry(product, mode, per_product_budget)
                except Exception as exc:  # noqa: BLE001 - isolate each live product.
                    fear_line = ""
                    if _now_beijing().date() >= fear_grid.EFFECTIVE_SIGNAL_DATE:
                        try:
                            observed_fear = fear_grid.observed_in_batch("baifenwei",
                                _now_beijing().date(),
                                "intraday" if mode == "intraday" else "close",
                            )
                            if observed_fear is None:
                                raise RuntimeError("本轮尚无已采集恐慌证据；失败兜底不另行联网")
                            fear_line = (
                                f"当日恐慌指数：{observed_fear['fear_greed_index'] if observed_fear['fear_greed_index'] is not None else '未发布'}"
                                f"；数据日 {observed_fear['fear_data_date'] or '未发布'}；"
                                f"状态 `{observed_fear['fear_data_status']}`（仅独立观察）。\n\n"
                            )
                            fear_line += "百分位取数提示：" + fear_grid.source_disclosure(observed_fear) + "\n\n"
                        except Exception as fear_exc:  # noqa: BLE001 - warning must still render.
                            fear_line = f"当日恐慌指数：未核验（{fear_exc}）。\n\n"
                        if _now_beijing().date() >= fear_grid.SOURCE_POLICY_DATE:
                            reference = fear_grid.observed_in_batch("jiu", _now_beijing().date()) or {}
                            fear_line += fear_grid.reference_disclosure(reference) + "\n\n"
                    wait_hint = (f"指数日线尚未更新，请稍后重试（状态：{exc.status}）。"
                                 if getattr(exc, "status", None) == DailyOHLCVNotReady.status else "")
                    if not wait_hint and getattr(exc, "waiting_sources", []):
                        wait_hint = ("部分来源日线尚未更新，其他来源也未通过校验，请稍后重试"
                                     f"（状态：{getattr(exc, 'status', 'sources_unavailable')}）。")
                    msg.write(
                        f"### {PRODUCT_NAMES[product]}\n\n⚠️ 当日信号警告：{wait_hint}{exc}\n\n"
                        + fear_line
                        + "该品种的新目标尚未确认；不会用NaN、陈旧行情或未重放账本"
                        "推导替代目标。\n\n"
                    )
                    try:
                        _write_last_verified_snapshot(msg, product)
                    except Exception as snapshot_exc:  # noqa: BLE001 - reporting fallback only.
                        msg.write(
                            "⚠️ 最后已核验快照也无法安全渲染："
                            f"{type(snapshot_exc).__name__}: {snapshot_exc}。"
                            "请核对持久账本；本品种不提供当前仓位或目标。\n\n"
                        )
                    continue
                if _SIGNAL_OBSERVER is not None:
                    try:
                        _SIGNAL_OBSERVER(product, deepcopy(live))
                    except Exception as observer_exc:  # noqa: BLE001 - computed result remains available.
                        msg.write(f"⚠️ {PRODUCT_NAMES[product]}信号已生成，但结构化结果采集失败；"
                                  f"持久化状态未确认：{type(observer_exc).__name__}: {observer_exc}。\n\n")
                if live.get("diagnostic_only"):
                    _write_diagnostic_signal(msg, product, live)
                    try:
                        _write_last_verified_snapshot(msg, product)
                    except Exception as snapshot_exc:  # Keep the other product visible.
                        msg.write("最后已核验快照无法安全渲染："
                                  f"{type(snapshot_exc).__name__}: {snapshot_exc}。\n\n")
                    continue
                msg.write(f"### {PRODUCT_NAMES[product]}\n\n")
                if live.get("calendar_coverage_warning"):
                    msg.write(f"**{live['calendar_coverage_warning']}**\n\n")
                try:
                    monthly_notice = option_maintenance_notice.reminder(
                        product, live, is_session=_option_maintenance_session)
                except Exception as notice_exc:
                    monthly_notice = None
                    msg.write(f"⚠️ 月度Put维护提醒无法核验，已跳过：{type(notice_exc).__name__}: {notice_exc}。\n\n")
                if monthly_notice:
                    msg.write(monthly_notice + "\n\n")
                published = fear_grid.publication_view(live)
                grid_confirmed = published.get("grid_target_confirmed", True)
                msg.write(f"**{live.get('iv_warning', {}).get('text', 'IV预警：N/A（旧记录未包含监测值）')}**\n\n")
                provisional = not live["close_confirmed"]
                monthly_put_today = bool(
                    provisional and monthly_notice
                    and live.get("signal_generation_timing") != "retrospective_replay"
                    and str(live.get("put_monthly_reset_execution_date") if product == "IM" else
                            live.get("option_monthly_reset_execution_date"))[:10] == str(live["market_date"])[:10]
                )
                put_target_day = f"今日（{live['market_date']}）收盘候选" if monthly_put_today else "下一交易日"
                target_label = "下一交易日预估目标" if provisional else "下一交易日确认目标"
                confirm_text = (
                    "盘中值，必须等待本交易日收盘确认"
                    if provisional
                    else f"{live['market_date']} 收盘已确认"
                )
                if grid_confirmed:
                    msg.write(
                        f"**当前总期货：{live['total_units_current']:g}倍；"
                        f"{target_label}：{live['total_units_target']:g}倍；"
                        f"净变化：{live['total_units_change']:+g}倍。**\n\n"
                    )
                else:
                    msg.write(
                        "**部分有效：核心、动量和Put按下表单列；"
                        "恐慌当日值及上一交易日沿用值未核验，网格及完整总期货目标N/A。**\n\n"
                        f"当前总期货：{live['total_units_current']:g}倍；"
                        f"{target_label}：N/A；净变化：N/A。\n\n"
                    )
                msg.write(
                    f"信号日：**{live['market_date']}**；{'期货下一交易日' if monthly_put_today else '下一交易日'}：**{live['next_trade_date']}**；"
                    f"状态：**{confirm_text}**。\n\n"
                )
                if monthly_put_today:
                    msg.write(f"**月度Put：{put_target_day}，合约与数量均须盘尾自行复核，并在当天收盘完成换仓。**\n\n")
                if live.get("signal_generation_timing") == "retrospective_replay":
                    msg.write(
                        f"**历史模型补录 retrospective_replay：实际生成 {live.get('signal_generated_at')}；"
                        "不是原信号日已发布的前瞻目标，亦非账户成交。**\n\n"
                    )
                msg.write(
                    f"v1.4固定核心路由：**{live.get('v14_route_state', 'future')}**；"
                    f"动作：**{live.get('v14_action', 'HOLD')}**；"
                    f"原因：`{live.get('v14_action_reason', 'N/A')}`。\n\n"
                )
                expiry_branches = live.get("v14_expiry_conditional_signal")
                if isinstance(expiry_branches, dict):
                    msg.write(
                        "**卖Put到期条件信号**：模型结算依据尚待核验；"
                        "若价外失效，则结束卖Put周期并返回普通期货路线；"
                        "若价内行权/现金结算，则进入模型承接与恢复路线。"
                        "这是策略条件分支，实际账户成交、行权和交割由用户自行处理。\n\n"
                    )
                if product == "IM" and live.get("put_monthly_reset_preview"):
                    msg.write(f"月度Put维护预告：{live['put_monthly_reset_execution_date']}执行；当天按已持有IM价格重选，当前不锁定新合约。\n\n")
                if product == "IC" and live.get("option_monthly_reset_preview"):
                    msg.write(f"月度Put维护预告：{live['option_monthly_reset_execution_date']}收盘执行；今日仅预告，不重复重选或记为已维护。\n\n")
                if product == "IM" and live.get("option_monthly_reset_due"):
                    msg.write(f"月度Put执行日：{live['put_monthly_reset_execution_date']}；参考{live['put_reference_future']}，取价日{live.get('put_reference_price_date', live['market_date'])}。盘中为待收盘确认的候选，收盘结果是当日研究执行记录，不是下一日重新选约指令。\n\n")
                profit_status = live.get("v14_profit_reentry_status")
                ordinary_status = live.get("v14_ordinary_put_open_status")
                if (profit_status in {"scheduled_t_plus_1_open", "confirmed_open_research_price"}
                        or ordinary_status == "confirmed_open_research_price"
                        or live.get("v14_ordinary_put_plan_status") == "scheduled_t_plus_1_open"):
                    msg.write("期权“开盘价”按供应商当日开盘字段作纸面研究价：集合竞价无成交时，可能取其后首笔成交，低流动性合约甚至可能晚于上午；不保证是09:30价格或账户可成交价。\n\n")
                if profit_status == "scheduled_t_plus_1_open":
                    msg.write(f"核心买Put三倍兑现开盘计划：{live['market_date']}收盘确认；{live['v14_profit_execution_day']}开盘卖旧合约{live['v14_profit_old_contract']}、买入预选合约{live['v14_profit_reentry_contract']}，规范化目标量{live['v14_profit_reentry_qty']:g}。此为模型计划，尚非成交。\n\n")
                elif profit_status == "confirmed_open_research_price":
                    msg.write(f"核心买Put三倍兑现纸面执行：{live['v14_profit_open_price_day']}开盘卖旧合约{live['v14_profit_open_old_contract']}，模型价{live['v14_profit_exit_open_price']}；买入{live['v14_profit_open_executed_contract']}，模型价{live['v14_profit_reentry_entry_premium']}，数量{live['v14_profit_open_executed_qty']:g}。不是账户成交回执。\n\n")
                if ordinary_status == "confirmed_open_research_price":
                    msg.write(f"普通核心/动量买Put：{live['market_date']}按前一收盘预选身份及当日开盘价完成纸面确认；逐腿开盘价见信号证据。不是账户成交回执。\n\n")
                elif ordinary_status and ordinary_status.startswith("closed_"):
                    msg.write(f"普通核心/动量买Put前次开盘计划已关闭：`{ordinary_status}`；{live.get('v14_ordinary_put_open_reason', '未形成可核验开盘执行')}。未记纸面成交。\n\n")
                if live.get("v14_ordinary_put_plan_status") == "scheduled_t_plus_1_open":
                    plan = live["v14_ordinary_put_pending"]
                    msg.write(f"普通核心/动量买Put开盘计划：{plan['signal_day']}收盘定目标及合约，{plan['execution_day']}开盘待按预选身份与开盘价确认；尚非纸面或账户成交。\n\n")
                for event in live.get("v14_opening_events", []):
                    title = "三倍兑现" if event["kind"] == "profit3x" else "卖Put成本"
                    msg.write(f"{title}独立开盘事件：{event['plan']['execution_day']}，"
                              f"{event['status']}。{event.get('reason', '')}"
                              "已核验开盘事件先于本日收盘新目标；仅研究价格，不是账户成交。\n\n")
                short_pending = live.get("v14_short_put_open_pending")
                if short_pending:
                    msg.write(f"卖Put开盘计划待核验：{short_pending['execution_day']}，"
                              f"新腿{short_pending['new_contract']}、数量{short_pending['new_qty']:g}；"
                              "候选收盘价不作为入场成本，取得开盘证据前不启用衰减展期。\n\n")
                put_timing = (
                    f"{put_target_day}；盘尾复核，当天收盘维护（非T+1）" if monthly_put_today
                    else "预定维护日收盘模型记录（非T+1）" if live.get("option_monthly_reset_due")
                    else "T收盘预选 → T+1开盘" if profit_status == "scheduled_t_plus_1_open"
                    else "本交易日开盘纸面确认" if profit_status == "confirmed_open_research_price"
                    else "T收盘预选 → T+1开盘待确认" if live.get("v14_ordinary_put_plan_status") == "scheduled_t_plus_1_open"
                    else "本交易日开盘纸面确认" if ordinary_status == "confirmed_open_research_price"
                    else (
                        "持仓维持；新计划按T收盘预选 → T+1指定日开盘"
                        if live["market_date"] >= v14_policy.ORDINARY_PUT_OPEN_EFFECTIVE_SIGNAL_DATE
                        else "T收盘评估 → T+1收盘"
                    )
                )
                msg.write(
                    f"| 仓位腿 | 当前策略仓位 | {'目标仓位（时点见执行语义）' if monthly_put_today else '下一交易日目标'} | 变化 | 执行语义 |\n"
                    "|---|---|---|---|---|\n"
                )
                msg.write(
                    f"| 裸滚核心袖 | {live['core_units_current']:g}倍 `{live['core_current']}` | {live['core_units_target']:g}倍 `{live['core_target']}` | "
                    f"{ACTION_CN.get(live['core_action'], live['core_action'])} | 季度换仓：IC T-3 / IM T-1收盘 |\n"
                )
                msg.write(
                    f"| 动量指引袖 | {live['momentum_units_current']:g}倍（权重 {live['momentum_current_weight']:g}） | "
                    f"{live['momentum_units_target']:g}倍（权重 {live['momentum_next_weight']:g}） | "
                    f"{live['momentum_units_change']:+g}倍 | T收盘信号 → 下一交易日形成仓位 |\n"
                )
                grid_label = ("独立网格（估值/恐慌）" if live["market_date"] >= fear_grid.EFFECTIVE_SIGNAL_DATE
                              else "独立估值网格")
                if grid_confirmed:
                    msg.write(
                        f"| {grid_label} | {live['grid_current']}倍 | {live['grid_target']}倍 | "
                        f"{live['grid_target'] - live['grid_current']:+g}倍 | T收盘信号 → T+1开盘 |\n"
                    )
                    msg.write(
                        f"| **期货合计** | **{live['total_units_current']:g}倍** | "
                        f"**{live['total_units_target']:g}倍** | **{live['total_units_change']:+g}倍** | 三条期货腿相加 |\n"
                    )
                else:
                    msg.write(
                        f"| {grid_label} | {live['grid_current']}倍 | N/A（当日恐慌未核验） | N/A | 未确认 |\n"
                        f"| **期货合计** | **{live['total_units_current']:g}倍** | **N/A** | **N/A** | 网格目标未确认 |\n"
                    )
                msg.write(
                    f"| Put | {live['put_current']} | {put_target_day + '：' if monthly_put_today else ''}{live['put_target']} | "
                    f"{ACTION_CN.get(live['put_action'], live['put_action'])} | {put_timing} |\n"
                )
                msg.write(
                    f"| Call | {live['call_current']} | {live['call_target']} | "
                    f"{ACTION_CN.get(live['call_action'], live['call_action'])} | T收盘评估 → T+1收盘 |\n\n"
                )
                if live["market_date"] >= fear_grid.EFFECTIVE_SIGNAL_DATE:
                    fear_basis = (
                        f"沿用上一交易日 {live.get('fear_data_date')}（当日未发布；盘中预估）"
                        if live.get("fear_data_status") == fear_grid.INTRADAY_FALLBACK_STATUS
                        and grid_confirmed else
                        f"沿用上一交易日 {live.get('fear_data_date')}（当日未发布；收盘模型）"
                        if live.get("fear_data_status") == fear_grid.CLOSE_FALLBACK_STATUS
                        and grid_confirmed else
                        "当日读数" if live.get("fear_data_date") == live["market_date"].isoformat()
                        else "以数据日及状态为准"
                    )
                    msg.write(
                        f"- 恐贪读数：**{live.get('fear_greed_index') if live.get('fear_greed_index') is not None else 'N/A（未核验/未发布）'}**；"
                        f"数据日 `{live.get('fear_data_date') or '未发布'}`；"
                        f"数据状态 `{live.get('fear_data_status', 'N/A')}`；"
                        f"使用口径：**{fear_basis}**；"
                        f"网格来源 `{live.get('grid_entry_source_current', 'N/A')}` → "
                        f"`{live.get('grid_entry_source_target', 'N/A') if grid_confirmed else 'N/A（未确认）'}`。\n\n"
                    )
                    msg.write("- **百分位取数提示：" + fear_grid.source_disclosure(live) + "**\n\n")
                    msg.write("- " + fear_grid.reference_disclosure(live) + "\n\n")
                if product == "IM":
                    msg.write(
                        f"- **Call 独立维护**：当前 {live['call_current']}；目标 {live['call_target']}；"
                        f"动作 **{ACTION_CN.get(live['call_action'], live['call_action'])}**；{live['call_market']}。\n\n"
                    )
                else:
                    msg.write("- **Call**：IC 1.4 明确禁止，当前和目标均无。\n\n")
                abs_days = int(live.get("momentum_abs_days", 20))
                abs_value = float(live.get("momentum_abs", live["momentum_abs20"]))
                abs_rule_text = (
                    f"Abs{abs_days}>0即恢复满仓，不使用两日恢复防抖；Score保持即时规则。"
                    if product == "IC" and abs_days == 40 else
                    f"Abs{abs_days}恢复满仓须连续两日均>+1%；Score保持即时规则。"
                    if live.get("momentum_abs_debounce_active", True) else
                    f"Abs{abs_days}>0即恢复满仓；Score保持即时规则。"
                )
                msg.write(
                    "**动量袖为什么是这个仓位**\n\n"
                    f"- 动量 Score：**{live['momentum_score']:.3f}**（要求 >0）；"
                    f"Abs{abs_days}：**{abs_value:.2%}**。\n"
                    f"- 规则：Score≤0 → 权重0；Score>0且Abs{abs_days}≤0 → 权重0.5；"
                    f"{abs_rule_text}动量袖期货名义=0.5×权重。\n"
                    f"- 当前动量仓位来自 **{live['momentum_current_source_date']}** 收盘信号；"
                    f"本次 **{live['momentum_signal_date']}** 信号给出下一交易日权重 "
                    f"**{live['momentum_next_weight']:g}**。\n\n"
                )
                if product == "IC":
                    base_dd = live.get("momentum_base_dd")
                    dd_text = (
                        f"{float(base_dd):.2%}"
                        if base_dd is not None and np.isfinite(float(base_dd))
                        else "不可用"
                    )
                    msg.write(
                        f"- IC 1.3 NAV防守：基础NAV回撤 **{dd_text}**；"
                        f"6%门槛**{'触发' if live.get('momentum_nav_defense', False) else '未触发'}**。"
                        "触发时将当日信号目标减半，并在下一共同交易日执行；"
                        "成交量与高分清仓过滤均关闭。\n"
                    )
                if product == "IM":
                    volume_text = (
                        "盘中成交量不可验证，沿用上一已确认交易日过滤状态"
                        if live.get("momentum_volume_placeholder", False)
                        else f"Volume/MA160={live.get('momentum_volume_ratio', float('nan')):.3f}，"
                        f"{'通过' if live.get('momentum_volume_pass', True) else '未通过'}0.85门槛"
                    )
                    msg.write(
                        f"- IM 1.3过滤：**{volume_text}**；"
                        f"前一信号日Score>=150清仓：**{'触发' if live.get('momentum_score_hot', False) else '未触发'}**。"
                        "两项都只作用于下一共同交易日。\n"
                    )
                msg.write("**估值档位与Put决策链**\n\n")
                msg.write("**" + daily_valuation.disclosure(live.get("valuation_provenance")) + "**\n\n")
                if product == "IC":
                    msg.write(
                        f"- 当前估值分 **{live['score']:.3f}**，处于 **{live['valuation_tier_label']}**；"
                        f"该估值对应的Put Delta值为 **{live['valuation_put_delta']:.0%}**。\n"
                        f"- Put用的MOM120为 **{live['momentum_120']:.2%}**；"
                        f"对应下限是 **{live['mom120_floor_delta']:.0%} Delta**。\n"
                        f"- **核心袖**：估值目标 {live['valuation_put_delta']:.0%} 与MOM120下限 "
                        f"{live['mom120_floor_delta']:.0%} 取较大值；本次由 **{live['core_put_driver']}** "
                        f"决定完整目标，乘0.5倍核心袖后贡献 **{live['core_put_target_delta']:.1%} Delta**。\n"
                        f"- **动量袖**：先由Score+Abs{abs_days}决定权重 **{live['momentum_next_weight']:g}**；"
                        "空仓则Put为0，有仓时只套用估值档，不继承MOM120下限。"
                        f"本次由 **{live['momentum_put_driver']}** 决定，贡献 "
                        f"**{live['momentum_put_target_delta']:.1%} Delta**。\n"
                        f"- **组合Put最终目标**：核心 {live['core_put_target_delta']:.1%} + 动量 "
                        f"{live['momentum_put_target_delta']:.1%} = "
                        f"**{live['total_put_target_delta']:.1%} Delta**。网格不配Put；IC不卖Call。\n"
                    )
                else:
                    msg.write(
                        f"- 当前估值分 **{live['score']:.3f}**。绝对轴处于 "
                        f"**{live['absolute_valuation_tier_label']}**；57个月相对轴（阈值冻结于2026-08-14）处于 "
                        f"**{live['relative_valuation_tier_label']}**。两轴取较高档后，估值给出"
                        f"每1倍核心IM **{live['valuation_puts_per_full_core']}张Put**。\n"
                        f"- Put用的MOM120为 **{live['momentum_120']:.2%}**；"
                        f"对应每1倍核心IM最低 **{live['mom120_floor_puts_per_full_core']}张**。\n"
                        f"- 估值目标与MOM120下限取较大值；本次最终由 **{live['core_put_driver']}** 决定。"
                        f"固定0.5倍核心袖的规范化目标为 "
                        f"**{live['core_put_target_qty_normalized']:g}张**。\n"
                        f"- **Put政策**：{live.get('im_put_policy_description', im_put_policy.description(live['market_date']))}；动量Put本次为 "
                        f"**{live['momentum_put_target_qty_normalized']:g}张**。网格不配Put，"
                        "动量袖与网格均不卖Call。"
                        "第4张只能由估值第4档产生，MOM120下限本身最多给到每1倍3张。\n"
                    )
                if grid_confirmed:
                    msg.write(
                        f"- 注意：表格中的{grid_label} **{live['grid_target']}倍** 是网格仓位，"
                        "不是估值等级；估值等级以上述档位文字为准。\n"
                    )
                else:
                    msg.write("- 网格目标N/A：当日恐慌未核验，不能把参考计算值当作已确认目标。\n")
                msg.write("\n**Put按仓位来源拆分**\n\n")
                if product == "IC":
                    if live.get("put_target_total_qty") is not None:
                        msg.write(
                            f"| 来源 | 当前张数 | {'今日收盘候选张数' if monthly_put_today else '下一交易日张数'} | 为什么 |\n"
                            "|---|---:|---:|---|\n"
                            f"| 裸滚IC核心袖 | **{live['put_current_core_qty']}张** | "
                            f"**{live['put_target_core_qty']}张** | 当前由"
                            f"{live['current_core_put_driver']}决定；{put_target_day}由"
                            f"{live['core_put_driver']}决定，只覆盖固定0.5倍核心袖 |\n"
                            f"| IC动量指引袖 | **{live['put_current_momentum_qty']}张** | "
                            f"**{live['put_target_momentum_qty']}张** | 当前："
                            f"{live['current_momentum_put_driver']}；{put_target_day}："
                            f"{live['momentum_put_driver']} |\n"
                            f"| 独立估值网格 | **0张** | **0张** | 规则明确不配Put |\n"
                            f"| **合计** | **{live['put_current_total_qty']}张** | "
                            f"**{live['put_target_total_qty']}张** | 三部分严格相加 |\n\n"
                            f"所以，{put_target_day}共 **{live['put_target_total_qty']}张**："
                            f"裸滚核心袖 **{live['put_target_core_qty']}张**，"
                            f"动量指引袖 **{live['put_target_momentum_qty']}张**，"
                            "网格 **0张**。\n"
                        )
                        if live.get("put_sizing_expiry") is not None:
                            msg.write(
                                f"{'合约候选（盘尾复核）' if monthly_put_today else '合约选择'}：以 {live['put_sizing_signal_date']} 后约3个月为目标，"
                                "在实际挂牌月份中选最近到期月，并取约95%行权价；本次为"
                                f" **{live['put_sizing_expiry']}** 到期、行权价"
                                f" **{live['put_sizing_strike']:.4f}**。\n"
                            )
                        elif live.get("put_selection_note"):
                            msg.write(f"合约选择：{live['put_selection_note']}。\n")
                    else:
                        msg.write(
                            "当前期权行情无法得到有效IV/Delta，因此暂时只能拆出核心袖与"
                            "动量袖的保护Delta，不能可靠换成整数张数。\n"
                        )
                    msg.write(
                        "以上是每1倍组合规模的标准化研究张数，不是用户账户的实际持仓；"
                        "实际账户仍需按IC合约数量同比例映射并满足整数约束。\n"
                    )
                else:
                    msg.write(
                        f"| 来源 | 当前规范化张数 | {'今日收盘候选规范化张数' if monthly_put_today else '下一交易日规范化张数'} | 为什么 |\n"
                        "|---|---:|---:|---|\n"
                        f"| 裸滚IM核心袖 | **{live['core_put_current_qty_normalized']:g}张** | "
                        f"**{live['core_put_target_qty_normalized']:g}张** | "
                        f"最终由{live['core_put_driver']}决定，只覆盖固定0.5倍核心袖 |\n"
                        f"| IM动量指引袖 | **{live['momentum_put_current_qty_normalized']:g}张** | "
                        f"**{live['momentum_put_target_qty_normalized']:g}张** | {im_put_policy.description(live['market_date'])} |\n"
                        "| 独立估值网格 | **0张** | **0张** | 规则明确不配Put |\n"
                        f"| **合计** | **{live['total_put_current_qty_normalized']:g}张** | "
                        f"**{live['total_put_target_qty_normalized']:g}张** | 三部分严格相加 |\n\n"
                        f"这次估值档给每1倍核心IM {live['valuation_puts_per_full_core']}张，"
                        f"MOM120下限给{live['mom120_floor_puts_per_full_core']}张，最终由"
                        f" **{live['core_put_driver']}** 主导；动量指引袖按权重贡献"
                        f"{live['momentum_put_target_qty_normalized']:g}张，网格贡献0张。\n"
                    )
                    if live.get("put_sizing_expiry") is not None:
                        msg.write(
                            f"{'合约候选（盘尾复核）' if monthly_put_today else '合约选择'}：以 {live['put_sizing_signal_date']} 后约3个月为目标，"
                            f"在实际挂牌月份中选最近到期月，并取约{im_put_policy.moneyness(live['market_date']):.0%}行权价；最终选择到期日 "
                            f"**{live['put_sizing_expiry']}**、行权价 "
                            f"**{live['put_sizing_strike']:.0f}** 的MO Put。\n"
                        )
                    elif live.get("put_selection_note"):
                        msg.write(f"合约选择：{live['put_selection_note']}。\n")
                    msg.write(
                        f"动量Put合约选择：{live['momentum_put_selection_note']}。\n"
                    )
                    msg.write(
                        "规范化小数张数不是可直接成交的半张合约；实际账户必须按核心IM合约数"
                        "映射成整数，Poe不会替代账户规模映射。\n"
                    )
                msg.write(
                    f"- 指数 {live['index_price']:.2f}。\n"
                    f"- 市场阶段：**{live['market_phase']}**；"
                    f"抓取时间：**{live['fetch_time']} 北京时间**\n"
                )
                msg.write(
                    f"- `{live['core_target']}` 延时行情（{live.get('future_quote_source', '未知')}，"
                    f"as-of {live.get('future_quote_date', '未知')}）：最新 "
                    f"{_format_quote_number(live['future_last'])}，买/卖 "
                    f"{_format_quote_number(live['future_bid'])}/"
                    f"{_format_quote_number(live['future_ask'])}\n"
                )
                for spread_line in quarter_roll.format_spreads(live, product=product):
                    msg.write("- " + spread_line + "\n")
                if live["scheduled_roll_completed"]:
                    msg.write("- 本日期货展期已收盘确认；期权维护日程独立。\n")
                elif live["core_action"] == "ROLL" and live["roll_execution_date"]:
                    msg.write(
                        f"- 季度换仓执行日：**{live['roll_execution_date']} 收盘**；提前预告不代表已执行，期权维护独立\n"
                    )
                msg.write(f"- Put 行情：{live['put_market']}\n")
                if product == "IM":
                    if live.get("call_has_position"):
                        if live["market_date"] >= v14_policy.NO_CALL_EFFECTIVE_SIGNAL_DATE:
                            msg.write(f"- Call 行情：{live['call_market']}；fix6目标为平旧仓，不再救援或新开。\n")
                        else:
                            msg.write(
                                f"- Call 行情：{live['call_market']}；旧Call虚值度 **{live['call_otm']:.2%}**，"
                                f"5%救援阈值当前{'已触发' if live['call_otm'] <= 0.05 else '未触发'}\n"
                            )
                    else:
                        msg.write(
                            f"- Call 行情：{live['call_market']}；当前无旧Call，"
                            + ("fix6不再新开Call\n" if live["market_date"] >= v14_policy.NO_CALL_EFFECTIVE_SIGNAL_DATE
                               else "只评估新D10/IV26候选\n")
                        )
                if live["next_core"] and live["core_target"] != live["next_core"]:
                    msg.write(
                        (f"- 季度规则：{product} T-{quarter_roll.ROLL_DAYS[product]}；所持合约到期日 {live['roll_date']}；"
                         f"计划 {live['roll_execution_date']} 收盘转入 `{live['next_core']}`，Put维持独立维护\n")
                        if live.get("roll_policy", {}).get("tenor") == "strict_quarter"
                        else "- 本行情日早于r7生效日，以上是原月度规则历史续接；2026-09-04起按IM季度T-1、IC季度T-3。\n"
                    )
                msg.write("- 数据：中金所及已验证备用行情、上交所510500ETF/期权及指数行情；PE/PB来源见上述披露，MOM120为价格指数口径。\n")
                for note in live["data_notes"][2:]:
                    if monthly_put_today and note.startswith("账本下一交易日桥接："):
                        note = note.replace("行情只形成下一交易日目标", "行情形成期货下一交易日目标；月度Put为今日收盘候选，须盘尾复核")
                    msg.write(f"- 数据审计：{note}\n")
                msg.write("\n")

    def _handle_params(self, products: tuple[str, ...]) -> None:
        with _sm() as msg:
            msg.write("## IC / IM 正式研究信号 1.4 参数\n\n")
            msg.write(
                "共同结构：0.5倍固定核心策略袖 + 0.5×动量权重袖 + 0或0.5倍独立网格；"
                "固定核心通常持有期货，但可按1.4规则切换为卖Put或恢复路线；"
                "基础动量权重为0/0.5/1；IC NAV防守后还可为0.25。\n\n"
            )
            for product in products:
                if product == "IC":
                    msg.write("### IC 1.4（SC查询别名）\n\n")
                    msg.write(
                        "- 动量：2026-10-08信号日起 MA105 / Mom24 / W1.6、50% OFF + 50% Abs40>0；"
                        "IC Abs 恢复防抖关闭。此前沿用 MA110 / Mom24 / W2、Abs20 及当日有效防抖。\n"
                    )
                    msg.write(
                        "- 相对1.2新增：按同一基础信号策略的NAV计算回撤；回撤达到6%时，"
                        "信号目标减半并于下一共同交易日执行。基础NAV含2%年化闲置现金收益"
                        "与0.1%单边换手成本；成交量/高分清仓过滤关闭。\n"
                    )
                    msg.write("- 买Put：固定核心达到入场权利金3倍时，自2026-09-28信号日起T收盘预选合约、下一共同交易日开盘平旧买新；此前旧信号按T+1收盘旧规则。动量Put独立，不随核心兑现。\n")
                    msg.write("- 卖Put路由：2026-09-28及以前信号沿用原执行动量许可；自2026-09-29信号日起，固定核心处于估值0/1档、中证500价格指数MOM120非负且M+1约95%行权价Put IV严格>30%时，以q_delta05（每0.5倍核心袖初始总Delta 0.5，约合每1倍IC总Delta 0.25）切换；动量腿可为空仓，买Put两日防抖不作卖方准入条件。自2026-09-26信号日起，权利金衰减50%且新腿仍满足准入时可反复提前展期。\n")
                    msg.write("- 卖Put或恢复路线期间固定核心买Put暂停；到期输出模型条件分支，不要求账户成交或交割回执。\n")
                    msg.write("- 网格：≤0.500 加0.5倍，≥1.000 退出；新增腿不配Put。\n")
                    msg.write("- IC不卖Call。\n\n")
                else:
                    msg.write("### IM 1.4\n\n")
                    msg.write(
                        "- 动量：MA35 / Mom18 / W2.5；Score>0；50% OFF + 50% Abs20>0。\n"
                    )
                    msg.write(
                        "- 新过滤：信号日Score>=150则下一执行行清仓；"
                        "Volume/MA160>=0.85才保留信号，160日暖机期放行。\n"
                    )
                    msg.write(
                        f"- {im_put_policy.description(_now_beijing().date())}；约3个月，网格不配Put。\n"
                    )
                    msg.write("- 买Put：固定核心达到入场权利金3倍时，自2026-09-28信号日起T收盘预选合约、下一共同交易日开盘平旧买新；此前旧信号按T+1收盘旧规则。动量Put独立。\n")
                    msg.write("- 卖Put路由：固定核心处于估值0/1档、MOM120非负且M+1约95%行权价MO Put IV严格>35%时，切换为q3（规范化1.5张）；自2026-09-26信号日起，权利金衰减60%且新腿仍满足准入时可反复提前展期。\n")
                    msg.write("- 自2026-09-26信号日起IM不再卖Call；若旧模型腿仍在，目标为买回旧Call。此前信号仍按当时规则保留。\n")
                    msg.write("- IM父规则MOM120<0时最低3张；第4张只能由估值第4档产生。\n")
                    msg.write(
                        "- 网格：≤1.60 加0.5倍，≥2.00 退出；新增腿不加Put或Call。\n"
                    )
                    msg.write("- fix6不再执行D10/IV26开仓或5%救援。\n\n")
            msg.write(
                "2026-10-08信号日起：估值或恐慌≤25入场单个0.5倍网格；"
                "入场时冻结来源，不叠加、不在持有中改来源。估值来源按各产品估值退出线，"
                "恐慌来源按恐慌≥50退出；两者同时入场时任一对应退出条件触发即退出，"
                "退出信号当天不重新入场。此前信号沿用当日旧规则。\n\n"
            )
            msg.write(
                "本版本是正式研究信号，只发布策略参考路径；不生成订单，也不是实盘授权。实际成交、行权、结算、交割和账户持仓由用户自行处理。\n\n"
            )

    def _handle_performance(self, intent: QueryIntent) -> None:
        # Embedded curves remain immutable r6 reference, not r7 quarterly history.
        assert intent.start is not None and intent.end is not None
        with _sm() as msg:
            msg.write(
                f"## 1.3 历史表现：{intent.start} 至 {intent.end}\n\n"
                "以下为 r6 冻结历史参考，不是 r7 季度换仓规则的历史绩效。\n\n"
            )
            request_deadline = (
                time_module.monotonic() + PERFORMANCE_NETWORK_BUDGET_SECONDS
            )
            for product in intent.products:
                if product == "IM":
                    msg.write(
                        "### IM\n\n旧r6嵌入收益依赖未修正的Put月度执行，"
                        "已撤回有效绩效资格，暂停展示其收益数字和净值图。"
                        "修复后的模拟与真实结果见2026-09-07整轮复验报告；"
                        "该研究结果尚未接成当前持久账本的历史收益。\n\n"
                    )
                    continue
                degraded_reason: str | None = None
                try:
                    remaining = max(0.25, request_deadline - time_module.monotonic())
                    with _network_budget(remaining):
                        frame = performance_frame(
                            product, intent.start, intent.end, refresh_latest=True
                        )
                except (
                    ValueError,
                    RuntimeError,
                    requests.RequestException,
                    zipfile.BadZipFile,
                    KeyError,
                ) as exc:
                    if intent.end > DATA_CUTOFF:
                        try:
                            frame = performance_frame(
                                product,
                                intent.start,
                                min(intent.end, DATA_CUTOFF),
                                refresh_latest=False,
                            )
                            degraded_reason = f"{type(exc).__name__}: {exc}"
                        except (ValueError, RuntimeError, KeyError) as fallback_exc:
                            msg.write(
                                f"### {product}\n\n⚠️ 1.3绩效续接账本未启用，冻结历史也无法覆盖所选区间："
                                f"{fallback_exc}\n\n"
                            )
                            continue
                    else:
                        msg.write(f"### {product}\n\n⚠️ {exc}\n\n")
                        continue
                metrics = performance_metrics(frame)
                actual_end = frame.index[-1].date()
                chart = render_nav_drawdown_chart(product, frame, intent.start)
                msg.write(f"### {PRODUCT_NAMES[product]}\n\n")
                if degraded_reason is not None:
                    msg.write(
                        f"⚠️ 1.3绩效续接账本未启用，仅展示哈希校验的冻结历史终点 "
                        f"**{actual_end}**；未外推、未伪造后续收益。原因："
                        f"`{degraded_reason}`\n\n"
                    )
                benchmark_cn = "中证500价格指数" if product == "IC" else "中证1000价格指数"
                msg.attach_file(
                    name=f"{product.lower()}_nav_drawdown_{intent.start}_{actual_end}.png",
                    contents=chart,
                    content_type="image/png",
                    is_inline=True,
                )
                msg.write(f"本次仅展示冻结历史，区间数据截至 **{actual_end}**。\n\n")
                if actual_end < intent.end:
                    msg.write(
                        f"请求终点晚于当前可核验终点；{actual_end}之后暂无已纳入且完成"
                        "逐腿核验的交易日收益，未用假设仓位外推。\n\n"
                    )
                msg.write(
                    f"区间收益 **{metrics['return']:.2%}**｜年化 **{metrics['cagr']:.2%}**｜"
                    f"年化波动 **{metrics['volatility']:.2%}**｜夏普 **{metrics['sharpe']:.2f}**｜"
                    f"最大回撤 **{metrics['max_drawdown']:.2%}**\n\n"
                )
                msg.write(
                    f"净值图已叠加 **{benchmark_cn}** 收盘价格曲线；两条曲线均按查询区间首日归一为1。\n\n"
                )
            msg.write(
                f"绩效口径：以上来自截至{DATA_CUTOFF}的v1.3/r6冻结历史参考，"
                "未按当前v1.4信号规则重新回测。每1倍期货按30%保证金/缓冲、"
                "剩余现金3%；未另行加入滑点、冲击、涨跌停未成交、容量、动态保证金上调和税费。\n\n"
                "2015年至期权上市前包含理论/代理段；本结果是只读研究参考，不是实盘授权。\n\n"
            )
            if "IM" in intent.products:
                msg.write(
                    "特别披露：IM上市前模型段保留既有 **10.32%年化基差** 定值参考；"
                    "该数值来自上市后真实样本回填，含未来信息，只能用于参考曲线，"
                    "不得解释为样本外绩效或实盘依据。\n\n"
                )


_evidence_strategy = evidence_adapter.Namespace(globals())
evidence_adapter.install(_evidence_strategy)


if __name__ == "__main__":
    ICIMMainlinesBot().run()
